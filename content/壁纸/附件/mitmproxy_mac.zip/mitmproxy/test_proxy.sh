#!/bin/bash
# 测试 mitmproxy 代理是否工作的脚本 (Mac版本)
# 使用方法: ./test_proxy.sh

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}测试 mitmproxy 代理连接...${NC}"
echo ""

# 使用 curl 测试代理
response=$(curl -s -o /dev/null -w "%{http_code}" --proxy http://127.0.0.1:8080 --max-time 10 http://mitm.it 2>/dev/null)

if [ "$response" = "200" ]; then
    echo -e "${GREEN}✓ 代理工作正常! 流量正在通过 mitmproxy。${NC}"
    echo ""
    echo -e "${YELLOW}Web UI: http://127.0.0.1:8081${NC}"
    echo -e "${YELLOW}Proxy: 127.0.0.1:8080${NC}"
else
    echo -e "${RED}✗ 代理测试失败。请检查:${NC}"
    echo -e "${RED}  1. mitmproxy 是否正在运行 (./start_proxy.sh)${NC}"
    echo -e "${RED}  2. 端口 8080 是否可访问${NC}"
fi

echo ""
echo -e "${CYAN}关闭代理: ./stop_proxy.sh${NC}"
