#!/bin/bash
# 停止 mitmproxy 代理进程的脚本 (Mac版本)
# 使用方法: ./stop_proxy.sh

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

echo -e "${CYAN}=== 停止 Mitmproxy 代理 ===${NC}"
echo ""

# 方法1: 停止特定的 mitmproxy 进程
echo -e "${YELLOW}查找并停止 mitmproxy 进程...${NC}"

# 查找包含 mitm 的进程
mitm_pids=$(ps aux | grep -E 'mitm|mitmweb|mitmproxy' | grep -v grep | awk '{print $2}')
if [ -n "$mitm_pids" ]; then
    for pid in $mitm_pids; do
        echo -e "${YELLOW}停止进程 (PID: $pid)${NC}"
        kill -9 $pid 2>/dev/null && echo -e "${GREEN}✓ 已停止进程 $pid${NC}" || echo -e "${RED}✗ 停止进程 $pid 失败${NC}"
    done
else
    echo -e "${YELLOW}未找到正在运行的 mitmproxy 进程${NC}"
fi

# 方法2: 停止占用 8080 和 8081 端口的进程
echo ""
echo -e "${YELLOW}检查并停止占用代理端口的进程...${NC}"

for port in 8080 8081; do
    echo "检查端口 $port..."
    pid=$(lsof -ti:$port 2>/dev/null || true)
    if [ -n "$pid" ]; then
        process_name=$(ps -p $pid -o comm= 2>/dev/null || echo "unknown")
        echo -e "${YELLOW}停止占用端口 $port 的进程: $process_name (PID: $pid)${NC}"
        kill -9 $pid 2>/dev/null && echo -e "${GREEN}✓ 已停止进程 $pid${NC}" || echo -e "${RED}✗ 停止进程 $pid 失败${NC}"
    fi
done

# 方法3: 重置系统代理设置 (Mac)
echo ""
echo -e "${YELLOW}重置系统代理设置...${NC}"

# 获取当前网络服务名称
network_service=$(networksetup -listallnetworkservices | grep -E "Wi-Fi|Ethernet" | head -1)

if [ -n "$network_service" ]; then
    echo "网络服务: $network_service"
    networksetup -setwebproxystate "$network_service" off 2>/dev/null || true
    networksetup -setsecurewebproxystate "$network_service" off 2>/dev/null || true
    echo -e "${GREEN}✓ 系统代理已重置${NC}"
else
    echo -e "${YELLOW}未找到活动的网络服务，跳过代理重置${NC}"
fi

echo ""
echo -e "${GREEN}代理已停止，可以重新启动！${NC}"
echo -e "${CYAN}使用以下命令重新启动:${NC}"
echo "  ./start_proxy.sh"
