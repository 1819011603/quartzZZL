#!/bin/bash
# Mitmproxy 快速启动脚本 (Mac版本)
# 使用方法: ./start_proxy.sh

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo -e "${CYAN}=== 检查并清理现有进程 ===${NC}"
echo -e "${YELLOW}停止可能占用端口的进程...${NC}"

# 检查并清理占用端口的进程
for port in 8080 8081; do
    pid=$(lsof -ti:$port 2>/dev/null || true)
    if [ -n "$pid" ]; then
        echo -e "${YELLOW}停止占用端口 $port 的进程 (PID: $pid)${NC}"
        kill -9 $pid 2>/dev/null || true
    fi
done

# 检查 mitmproxy 是否安装
if ! command -v mitmweb &> /dev/null; then
    echo -e "${RED}错误: mitmproxy 未安装${NC}"
    echo -e "${YELLOW}请运行: brew install mitmproxy${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}mitmproxy 版本: $(mitmproxy --version | head -1)${NC}"
echo ""
echo -e "${GREEN}启动 mitmproxy web 界面...${NC}"
echo -e "${CYAN}Web UI: http://127.0.0.1:8081${NC}"
echo -e "${CYAN}Proxy: 127.0.0.1:8080${NC}"
echo -e "${YELLOW}按 Ctrl+C 停止${NC}"
echo ""

# 使用当前目录作为配置目录
mitmweb -s "$SCRIPT_DIR/cursor_rewrite.py" --set confdir="$SCRIPT_DIR"
