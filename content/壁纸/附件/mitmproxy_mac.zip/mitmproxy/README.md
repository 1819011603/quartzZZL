# Mitmproxy 请求拦截与重写工具

基于 mitmproxy 的 HTTP/HTTPS 请求拦截和重写工具，支持 Cursor 账号接口重写等功能。

## 环境要求

- macOS
- mitmproxy (通过 brew 安装)

## 快速开始

### 1. 安装 mitmproxy

```bash
brew install mitmproxy
```

### 2. 启动代理

```bash
cd /Users/gaotu/cursorProject/mitmproxy
./start_proxy.sh
```

启动后会显示：
- **Web UI**: http://127.0.0.1:8081 - 可视化查看所有请求
- **Proxy**: 127.0.0.1:8080 - 代理服务器地址

### 3. 配置系统代理

#### 方法1：命令行设置 (推荐)

```bash
# 设置 HTTP/HTTPS 代理 (Wi-Fi)
networksetup -setwebproxy "Wi-Fi" 127.0.0.1 8080
networksetup -setsecurewebproxy "Wi-Fi" 127.0.0.1 8080

# 关闭代理
networksetup -setwebproxystate "Wi-Fi" off
networksetup -setsecurewebproxystate "Wi-Fi" off
```

#### 方法2：手动设置

1. 打开 **系统设置** → **网络**
2. 选择当前网络连接 (Wi-Fi 或以太网)
3. 点击 **详细信息** → **代理**
4. 勾选 **Web 代理 (HTTP)** 和 **安全 Web 代理 (HTTPS)**
5. 服务器填写 `127.0.0.1`，端口填写 `8080`

#### 方法3：命令行工具临时代理

```bash
# curl 使用代理
curl --proxy http://127.0.0.1:8080 https://example.com

# 设置环境变量
export http_proxy=http://127.0.0.1:8080
export https_proxy=http://127.0.0.1:8080
```

### 4. 安装 HTTPS 证书

首次使用 HTTPS 拦截需要安装 CA 证书：

```bash
./install_cert.sh
```

**或手动安装**：
1. 启动代理后，浏览器访问 http://mitm.it
2. 下载 macOS 版本的证书
3. 双击安装到钥匙串
4. 在"钥匙串访问"中找到 mitmproxy 证书
5. 双击 → 信任 → 设置为"始终信任"

### 5. 测试代理

```bash
./test_proxy.sh
```

### 6. 停止代理

```bash
./stop_proxy.sh
```

## 统一操作命令速查

```bash
# 进入项目目录
cd /Users/gaotu/cursorProject/mitmproxy

# 启动代理
./start_proxy.sh

# 测试代理
./test_proxy.sh

# 停止代理
./stop_proxy.sh

# 安装证书
./install_cert.sh

# 开启系统代理
networksetup -setwebproxy "Wi-Fi" 127.0.0.1 8080
networksetup -setsecurewebproxy "Wi-Fi" 127.0.0.1 8080

# 关闭系统代理
networksetup -setwebproxystate "Wi-Fi" off
networksetup -setsecurewebproxystate "Wi-Fi" off
```

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `start_proxy.sh` | 启动 mitmproxy 代理服务 |
| `stop_proxy.sh` | 停止代理并清理端口占用 |
| `test_proxy.sh` | 测试代理是否正常工作 |
| `install_cert.sh` | 安装 CA 证书到系统 |

## 请求重写功能

### 配置文件说明

- **`rewrite_rules.json`**: 重写规则配置文件
- **`cursor_accounts.json`**: Cursor 账号数据
- **`cursor_rewrite.py`**: 核心重写逻辑脚本

### 当前重写规则

| 规则名称 | 匹配路径 | 说明 |
|---------|---------|------|
| 绑定账号接口 | `/cursor/user/bindToAccount` | 返回绑定成功响应 |
| 用户列表接口 | `/cursor/user/pagelist` | 返回用户列表数据 |
| 获取可用账号接口 | `getAvailableAccountsByUserName` | 返回自定义账号列表 |

### 添加新规则

编辑 `rewrite_rules.json` 文件：

```json
{
  "rules": [
    {
      "name": "规则名称",
      "path_match": "接口路径关键字",
      "response": {
        "code": 0,
        "data": "自定义响应数据",
        "msg": ""
      }
    }
  ]
}
```

修改规则后重启代理即可生效。

## 常见问题

### 端口被占用

```bash
./stop_proxy.sh

# 或手动查找并停止
lsof -i:8080
kill -9 <PID>
```

### 证书问题

如果浏览器提示证书不受信任：
1. 确保已安装证书
2. 在钥匙串中将证书设置为"始终信任"
3. 重启浏览器

## 高级用法

### 仅监控不修改

```bash
mitmweb --set confdir="$(pwd)"
```

### 命令行模式

```bash
mitmproxy -s cursor_rewrite.py --set confdir="$(pwd)"
```

### 过滤特定域名

```bash
mitmweb -s cursor_rewrite.py --set confdir="$(pwd)" -i "~d example.com"
```
