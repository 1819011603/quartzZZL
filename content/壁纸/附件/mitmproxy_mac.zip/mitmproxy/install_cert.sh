#!/bin/bash
# 安装 mitmproxy CA 证书到 Mac 系统信任库
# 使用方法: ./install_cert.sh

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CERT_FILE="$SCRIPT_DIR/mitmproxy-ca-cert.pem"

echo -e "${CYAN}=== 安装 mitmproxy CA 证书 ===${NC}"
echo ""

# 检查证书文件是否存在
if [ ! -f "$CERT_FILE" ]; then
    echo -e "${RED}错误: 找不到证书文件 mitmproxy-ca-cert.pem${NC}"
    echo -e "${YELLOW}请先启动代理生成证书文件${NC}"
    echo ""
    echo -e "${CYAN}操作步骤:${NC}"
    echo "  1. 运行 ./start_proxy.sh"
    echo "  2. 浏览器配置代理后访问 http://mitm.it"
    echo "  3. 下载 macOS 证书或等待自动生成"
    exit 1
fi

echo -e "${YELLOW}正在安装证书到系统信任库...${NC}"
echo -e "${YELLOW}(需要输入管理员密码)${NC}"
echo ""

# 使用 security 命令安装证书到系统钥匙串
sudo security add-trusted-cert -d -r trustRoot -k /Library/Keychains/System.keychain "$CERT_FILE"

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}✓ 证书安装成功！${NC}"
    echo ""
    echo -e "${CYAN}现在您可以正常使用 HTTPS 拦截功能了。${NC}"
    echo -e "${CYAN}如遇到证书问题，请重启浏览器或应用程序。${NC}"
else
    echo ""
    echo -e "${RED}✗ 证书安装失败！${NC}"
    echo -e "${YELLOW}请尝试手动安装:${NC}"
    echo "  1. 打开 '钥匙串访问' 应用"
    echo "  2. 选择 '系统' 钥匙串"
    echo "  3. 将 mitmproxy-ca-cert.pem 拖入或导入"
    echo "  4. 双击证书，展开 '信任' 部分"
    echo "  5. 将 'SSL' 设置为 '始终信任'"
fi

echo ""
echo "证书位置: $CERT_FILE"
