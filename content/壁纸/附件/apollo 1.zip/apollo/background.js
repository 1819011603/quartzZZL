// Background service worker for handling CORS requests
console.log('Apollo Helper background script loading...');

// 全局错误处理
self.addEventListener('error', (event) => {
  console.error('Background script error:', event.message, event.filename, event.lineno);
});

// 监听扩展安装/启动
chrome.runtime.onInstalled.addListener(() => {
  console.log('Apollo Helper extension installed/updated');
});

// 处理跨域请求的核心功能
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);
  
  if (request.action === 'fetchWithCORS') {
    console.log('Attempting CORS fetch to:', request.url);
    
    // 尝试多种 fetch 策略
    fetchWithMultipleStrategies(request.url, request.method || 'GET', request.headers || {})
      .then(data => {
        console.log('Background fetch success');
        sendResponse({ success: true, data: data });
      })
      .catch(error => {
        console.error('All fetch strategies failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    
    // 返回 true 表示将异步发送响应
    return true;
  }
});

// 使用多种策略尝试获取数据
async function fetchWithMultipleStrategies(url, method, headers) {
  const errors = [];
  
  // 策略1: 标准 fetch 带完整选项（CORS 模式）
  try {
    console.log('Strategy 1: Standard fetch with CORS');
    const response = await fetch(url, {
      method: method,
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        ...headers
      },
      mode: 'cors'
    });
    
    console.log('Strategy 1 response:', response.status, response.statusText);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const text = await response.text();
    console.log('Strategy 1 response text:', text.substring(0, 200));
    
    try {
      const data = JSON.parse(text);
      console.log('Strategy 1 success, parsed JSON');
      return data;
    } catch (e) {
      console.error('JSON parse error:', e);
      throw new Error(`Invalid JSON response: ${e.message}`);
    }
  } catch (error) {
    console.error('Strategy 1 failed:', error);
    errors.push(`Strategy 1: ${error.message}`);
  }
  
  // 策略2: 简化 fetch 无额外 headers
  try {
    console.log('Strategy 2: Simple fetch without custom headers');
    const response = await fetch(url, {
      method: method,
      mode: 'cors'
    });
    
    console.log('Strategy 2 response:', response.status, response.statusText);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('Strategy 2 success');
    return data;
  } catch (error) {
    console.error('Strategy 2 failed:', error);
    errors.push(`Strategy 2: ${error.message}`);
  }
  
  // 策略3: 带凭据的请求
  try {
    console.log('Strategy 3: Fetch with credentials');
    const response = await fetch(url, {
      method: method,
      headers: {
        'Accept': 'application/json',
        ...headers
      },
      credentials: 'include',
      mode: 'cors'
    });
    
    console.log('Strategy 3 response:', response.status, response.statusText);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const data = await response.json();
    console.log('Strategy 3 success');
    return data;
  } catch (error) {
    console.error('Strategy 3 failed:', error);
    errors.push(`Strategy 3: ${error.message}`);
  }
  
  // 所有策略都失败
  throw new Error(`All fetch strategies failed: ${errors.join('; ')}`);
}

console.log('Apollo Helper background script loaded'); 