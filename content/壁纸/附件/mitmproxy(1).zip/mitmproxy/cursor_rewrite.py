"""
Cursor 账号接口重写脚本 - JSON 配置模式
所有规则配置都在 rewrite_rules.json 文件中

使用方法：
1. 编辑 rewrite_rules.json 文件添加/修改规则
2. 重启 mitmproxy 使配置生效
"""

from mitmproxy import http
import json
import os

# ============================================================
# 📋 从 JSON 文件加载配置
# ============================================================
def load_rules_from_json():
    """从 JSON 文件加载重写规则"""
    config_file = os.path.join(os.path.dirname(__file__), "rewrite_rules.json")
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
            rules = config.get("rules", [])
            print(f"[CONFIG] 成功加载 {len(rules)} 条重写规则")
            return rules
    except FileNotFoundError:
        print(f"[CONFIG] 错误: 配置文件 {config_file} 不存在")
        return []
    except json.JSONDecodeError as e:
        print(f"[CONFIG] 错误: JSON 解析失败 - {e}")
        return []
    except Exception as e:
        print(f"[CONFIG] 错误: 加载配置失败 - {e}")
        return []

# 加载规则
REWRITE_RULES = load_rules_from_json()

# ============================================================
# 🔧 核心处理逻辑 - 通常不需要修改
# ============================================================

def request(flow: http.HTTPFlow) -> None:
    """
    处理请求拦截 - 直接返回响应，不请求原始服务器
    """
    # 加载规则
    REWRITE_RULES = load_rules_from_json()
    # 遍历所有规则，查找匹配
    for rule in REWRITE_RULES:
        if rule["path_match"] in flow.request.path:
            print(f"[INTERCEPT] *** 拦截到 [{rule['name']}] ***")
            print(f"[INTERCEPT] URL: {flow.request.url}")
            print(f"[INTERCEPT] Method: {flow.request.method}")
            
            try:
                # 获取响应数据
                if rule["response"] is None:
                    # 使用特殊处理函数（如获取账号列表）
                    modified_data = get_cursor_accounts_response()
                else:
                    # 直接使用配置的响应
                    modified_data = rule["response"]
                
                # 转换为 JSON 字符串
                response_content = json.dumps(modified_data, indent=2, ensure_ascii=False)
                
                # 直接创建响应，不请求原始服务器
                flow.response = http.Response.make(
                    200,  # 状态码
                    response_content.encode('utf-8'),  # 响应内容
                    {
                        "Content-Type": "application/json; charset=utf-8",
                        "X-Proxy-Intercepted": "true"
                    }
                )
                
                print(f"[INTERCEPT] 直接返回响应，内容长度: {len(response_content)} bytes")
                print(f"[INTERCEPT] *** [{rule['name']}] 拦截成功，未请求原始服务器! ***")
                
            except Exception as e:
                print(f"[INTERCEPT] 拦截 [{rule['name']}] 出错: {e}")
                # 出错时返回错误响应
                error_response = json.dumps({"code": -1, "msg": str(e), "data": None})
                flow.response = http.Response.make(
                    500,
                    error_response.encode('utf-8'),
                    {"Content-Type": "application/json; charset=utf-8"}
                )
            
            break  # 找到匹配规则后退出循环


def response(flow: http.HTTPFlow) -> None:
    """
    处理响应 - 由于在 request 阶段已拦截，这里通常不会执行
    保留此函数以便处理未被拦截的请求
    """
    pass


def get_cursor_accounts_response():
    """从 cursor_accounts.json 文件加载完整的响应数据"""
    accounts_file = os.path.join(os.path.dirname(__file__), "cursor_accounts.json")
    
    try:
        with open(accounts_file, 'r', encoding='utf-8') as f:
            response = json.load(f)
            account_count = len(response.get("data", []))
            print(f"[ACCOUNTS] 成功加载响应数据，包含 {account_count} 个账号")
            return response
    except FileNotFoundError:
        print(f"[ACCOUNTS] 错误: 账号文件 {accounts_file} 不存在")
        return {"code": -1, "data": [], "msg": "配置文件不存在"}
    except json.JSONDecodeError as e:
        print(f"[ACCOUNTS] 错误: JSON 解析失败 - {e}")
        return {"code": -1, "data": [], "msg": f"JSON解析错误: {e}"}
    except Exception as e:
        print(f"[ACCOUNTS] 错误: 加载账号失败 - {e}")
        return {"code": -1, "data": [], "msg": f"加载失败: {e}"}


# ============================================================
# 🚀 脚本加载提示
# ============================================================
print("=" * 60)
print("Cursor 接口重写脚本已加载!")
print("=" * 60)
print("已配置的重写规则:")
for i, rule in enumerate(REWRITE_RULES, 1):
    print(f"  {i}. {rule['name']} -> {rule['path_match']}")
print("=" * 60)