// Background service worker for handling CORS requests
console.log('Apollo Helper background script loading...');

// 全局错误处理
self.addEventListener('error', (event) => {
  console.error('Background script error:', event.message, event.filename, event.lineno);
});

// 监听扩展安装/启动
chrome.runtime.onInstalled.addListener(() => {
  console.log('Apollo Helper extension installed/updated');
});

// 处理跨域请求的核心功能
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request);
  
  if (request.action === 'fetchWithCORS') {
    console.log('Attempting CORS fetch to:', request.url);
    
    // 尝试多种 fetch 策略
    fetchWithMultipleStrategies(request.url, request.method || 'GET', request.headers || {})
      .then(data => {
        console.log('Background fetch success');
        sendResponse({ success: true, data: data });
      })
      .catch(error => {
        console.error('All fetch strategies failed:', error);
        sendResponse({ success: false, error: error.message });
      });
    
    // 返回 true 表示将异步发送响应
    return true;
  }
});

// 使用多种策略尝试获取数据
async function fetchWithMultipleStrategies(url, method, headers) {
  const errors = [];
  
  // 策略1: 标准 fetch 带完整选项
  try {
    console.log('Strategy 1: Standard fetch with full options');
    const response = await fetch(url, {
      method: method,
      headers: {
        'Accept': '*/*',
        'Origin': 'https://apollo-portal.baijia.com',
        'Referer': 'https://apollo-portal.baijia.com/',
        ...headers
      },
      credentials: 'include',
      mode: 'cors'
    });
    
    console.log('Strategy 1 response:', response.status, response.statusText);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch (e) {
      console.error('JSON parse error:', e);
      throw new Error(`Invalid JSON response: ${e.message}`);
    }
  } catch (error) {
    console.error('Strategy 1 failed:', error);
    errors.push(`Strategy 1: ${error.message}`);
  }
  
  // 策略2: 简化 fetch 无凭据
  try {
    console.log('Strategy 2: Simple fetch without credentials');
    const response = await fetch(url, {
      method: method,
      headers: {
        'Accept': 'application/json',
        ...headers
      },
      mode: 'cors'
    });
    
    console.log('Strategy 2 response:', response.status, response.statusText);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Strategy 2 failed:', error);
    errors.push(`Strategy 2: ${error.message}`);
  }
  
  // 策略3: 使用 no-cors 模式
  try {
    console.log('Strategy 3: Using no-cors mode');
    const response = await fetch(url, {
      method: 'GET', // no-cors 只支持 GET, HEAD 或 POST
      mode: 'no-cors'
    });
    
    console.log('Strategy 3 response type:', response.type);
    // no-cors 模式下无法读取响应内容，但可以检测连接是否成功
    if (response.type === 'opaque') {
      console.log('Connection successful, but content is opaque due to CORS');
      // 返回一个空的成功响应
      return { success: true, message: 'Connection successful, but content is opaque due to CORS' };
    } else {
      throw new Error('Failed to establish connection');
    }
  } catch (error) {
    console.error('Strategy 3 failed:', error);
    errors.push(`Strategy 3: ${error.message}`);
  }
  
  // 所有策略都失败
  throw new Error(`All fetch strategies failed: ${errors.join('; ')}`);
}

console.log('Apollo Helper background script loaded'); 