(function() {
  const OWNER = 'zhangzeling';
  const BASE = 'https://apollo-portal.baijia.com';

  const panelId = 'apollo-helper-panel';
  if (document.getElementById(panelId)) return;

  const style = document.createElement('style');
  style.textContent = `
    #apollo-helper-panel {
      position: fixed;
      top: 0px;
      right: 20px;
      width: 600px;
      background: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 15px;
      z-index: 10000;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
      max-height: 90vh;
      overflow-y: auto;
      transition: width 0.3s ease;
      cursor: move;
    }
    
    #apollo-helper-panel .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    
    #apollo-helper-panel .header h3 {
      margin: 0;
      color: #1890ff;
      cursor: move;
    }
    
    #apollo-helper-panel .close-btn {
      cursor: pointer;
      font-size: 18px;
      color: #999;
    }
    
    #apollo-helper-panel .close-btn:hover {
      color: #666;
    }
    
    #apollo-helper-panel label {
      display: block;
      margin-bottom: 5px;
    }
    
    #apollo-helper-panel input,
    #apollo-helper-panel select {
      width: 100%;
      padding: 5px;
      box-sizing: border-box;
      margin-bottom: 10px;
    }
    
    #apollo-key-dropdown,
    #apollo-value-dropdown {
      display: none;
      position: absolute;
      width: 100%;
      max-height: 200px;
      overflow-y: auto;
      background: white;
      border: 1px solid #ccc;
      border-top: none;
      z-index: 10001;
    }
    
    #apollo-key-dropdown div,
    #apollo-value-dropdown div {
      padding: 5px;
      cursor: pointer;
    }
    
    #apollo-key-dropdown div:hover,
    #apollo-value-dropdown div:hover {
      background: #f0f0f0;
    }
    
    #apollo-table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }
    
    #apollo-table th,
    #apollo-table td {
      text-align: left;
      padding: 8px;
      border-bottom: 1px solid #e8e8e8;
    }
    
    #apollo-table th {
      background: #fafafa;
    }
    
    #apollo-helper-toggle {
      position: fixed;
      top: 0px;
      right: 20px;
      background: #1890ff;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px 12px;
      cursor: move;
      z-index: 9999;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    }
    
    #apollo-helper-toggle:hover {
      background: #40a9ff;
    }
    
    .apollo-checkbox-container {
      display: flex;
      justify-content: center;
      margin-bottom: 15px;
      border: 1px solid #e8e8e8;
      border-radius: 4px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    
    .apollo-checkbox-wrapper {
      display: flex;
      align-items: center;
      padding: 5px;
    }
    
    .apollo-checkbox-wrapper input[type="checkbox"] {
      width: 16px;
      height: 16px;
      margin: 0;
      margin-right: 8px;
      flex-shrink: 0;
    }
    
    .apollo-checkbox-wrapper label {
      display: inline-block !important;
      margin: 0 !important;
      font-size: 14px;
      white-space: nowrap;
      text-align: center;
    }
    
    @media (max-width: 480px) {
      .apollo-checkbox-container {
        flex-direction: column;
      }
      
      .apollo-checkbox-wrapper:first-child {
        margin-right: 0;
        margin-bottom: 8px;
        border-right: none;
        border-bottom: 1px solid #e8e8e8;
        padding-bottom: 8px;
      }
    }
  `;
  document.head.appendChild(style);

  // 缓存过期时间常量
  const TTL_1H = 60 * 60 * 1000; // 1小时
  const TTL_1D = 24 * TTL_1H;    // 1天
  const TTL_7D = 7 * TTL_1D;     // 7天
  const TTL_30D = 30 * TTL_1D;   // 30天
  const TTL_1Y = 365 * TTL_1D;   // 1年

  // IndexedDB 缓存管理器
  class IndexedDBCache {
    constructor() {
      this.dbName = 'ApolloHelperCache';
      this.version = 1;
      this.storeName = 'cache';
      this.db = null;
    }

    async init() {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(this.dbName, this.version);
        
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          this.db = request.result;
          resolve(this.db);
        };
        
        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains(this.storeName)) {
            const store = db.createObjectStore(this.storeName, { keyPath: 'key' });
            store.createIndex('expiresAt', 'expiresAt', { unique: false });
          }
        };
      });
    }

    async get(key) {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readonly');
        const store = transaction.objectStore(this.storeName);
        const request = store.get(key);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => {
            const result = request.result;
            if (!result) {
              resolve(null);
              return;
            }
            
            // 检查过期时间
            if (result.expiresAt && Date.now() > result.expiresAt) {
              this.delete(key); // 异步删除过期项
              resolve(null);
              return;
            }
            
            resolve(result.value);
          };
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB get 错误:', e);
        return null;
      }
    }

    async set(key, value, ttlMs = null) {
      try {
        if (!this.db) await this.init();
        
        const data = {
          key,
          value,
          createdAt: Date.now(),
          expiresAt: ttlMs ? Date.now() + ttlMs : null
        };
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const request = store.put(data);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => resolve(true);
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB set 错误:', e);
        return false;
      }
    }

    async delete(key) {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const request = store.delete(key);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => resolve(true);
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB delete 错误:', e);
        return false;
      }
    }

    async cleanup() {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const index = store.index('expiresAt');
        const now = Date.now();
        
        const request = index.openCursor();
        let cleaned = 0;
        
        return new Promise((resolve, reject) => {
          request.onsuccess = (event) => {
            const cursor = event.target.result;
            if (cursor) {
              const data = cursor.value;
              if (data.expiresAt && now > data.expiresAt) {
                cursor.delete();
                cleaned++;
              }
              cursor.continue();
            } else {
              console.log('IndexedDB 清理完成，删除', cleaned, '个过期项');
              resolve(cleaned);
            }
          };
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB cleanup 错误:', e);
        return 0;
      }
    }
  }

  // 创建缓存实例
  const cache = new IndexedDBCache();

  // 兼容接口
  async function cacheGet(key) {
    const result = await cache.get(key);
    return result;
  }

  async function cacheSet(key, value, ttlMs) {
    const success = await cache.set(key, value, ttlMs);
    return success;
  }

  // 全局变量定义
  let appIds = [];
  // let selectedAppIds = ['reach-service','crm-app-service.gaotu100.com','fairy.gaotu100.com','linkup.gaotu100.com','student-center','student-data','teacher-basic.gaotu100.com','service-copilot','teacher-tool']; // 已选择的AppId列表
  let selectedAppIds = []; // 已选择的AppId列表
  let selectedEnvs = ['TEST', 'PROD']; // 已选择的环境列表，默认TEST和PROD
  let namespaces = []; // 所有可用的namespace列表
  let selectedNamespaces = []; // 已选择的Namespace列表
  let DEFAULT_OWNER = 'zhangzeling'; // 设置默认Owner
  
  // Fisher-Yates 洗牌算法，用于随机打乱数组
  function shuffleArray(array) {
    const result = [...array]; // 创建数组副本，不修改原数组
    for (let i = result.length - 1; i > 0; i--) {
      // 随机选择一个位置
      const j = Math.floor(Math.random() * (i + 1));
      // 交换元素
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  let keyPool = [];
  let valuePool = [];
  let isLoadingAppIds = false;
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let isDraggingToggle = false;
  let dragToggleOffsetX = 0;
  let dragToggleOffsetY = 0;
  let dragStartTime = 0;
  let isResizing = false;
  let initialWidth = 0;
  let initialX = 0;
  let initialPanelLeft = 0;
  let autoRefreshTimer = null; // 自动刷新定时器
  let isLoginPageOpened = false; // 防止多次打开登录页面的标识

    // DOM元素引用
  let ownerInput;
  let forceChk;
  let copyBtn;
  let envSelect;
  let appIdSelect;
  let namespaceSelect;
  let keyInput;
  let keyDropdown;
  let valueInput;
  let valueDropdown;
  let searchBtn;
  let exportBtn;
  let clearBtn;
  let tbody;
  let summary;
  let namespaceInput;
  let ttlSelect;
  let prodConfigIpInput; // PROD配置服务IP输入框
  let prodConfigPortInput; // PROD配置服务Port输入框

  // 非阻塞通知函数
  function showNotification(message, type = 'warning', duration = 5000) {
    const notification = document.createElement('div');
    notification.className = 'apollo-notification apollo-notification-' + type;
    notification.innerHTML = `
      <div class="apollo-notification-content">
        <div class="apollo-notification-icon">${type === 'warning' ? '⚠️' : 'ℹ️'}</div>
        <div class="apollo-notification-message">${message}</div>
        <button class="apollo-notification-close">✕</button>
      </div>
    `;
    
    // 添加样式
    if (!document.getElementById('apollo-notification-styles')) {
      const style = document.createElement('style');
      style.id = 'apollo-notification-styles';
      style.textContent = `
        .apollo-notification {
          position: fixed;
          top: 20px;
          right: 20px;
          min-width: 320px;
          max-width: 500px;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 999999;
          animation: slideInRight 0.3s ease-out;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        }
        .apollo-notification-warning {
          border-left: 4px solid #ff9800;
        }
        .apollo-notification-info {
          border-left: 4px solid #2196f3;
        }
        .apollo-notification-content {
          display: flex;
          align-items: flex-start;
          padding: 16px;
          gap: 12px;
        }
        .apollo-notification-icon {
          font-size: 24px;
          line-height: 1;
          flex-shrink: 0;
        }
        .apollo-notification-message {
          flex: 1;
          font-size: 14px;
          line-height: 1.6;
          color: #333;
          white-space: pre-line;
        }
        .apollo-notification-close {
          background: none;
          border: none;
          font-size: 18px;
          color: #999;
          cursor: pointer;
          padding: 0;
          width: 24px;
          height: 24px;
          line-height: 1;
          flex-shrink: 0;
          transition: color 0.2s;
        }
        .apollo-notification-close:hover {
          color: #333;
        }
        @keyframes slideInRight {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        @keyframes slideOutRight {
          from {
            transform: translateX(0);
            opacity: 1;
          }
          to {
            transform: translateX(400px);
            opacity: 0;
          }
        }
        .apollo-notification.closing {
          animation: slideOutRight 0.3s ease-out forwards;
        }
      `;
      document.head.appendChild(style);
    }
    
    // 关闭函数
    const closeNotification = () => {
      notification.classList.add('closing');
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    };
    
    // 关闭按钮事件
    notification.querySelector('.apollo-notification-close').addEventListener('click', closeNotification);
    
    // 添加到页面
    document.body.appendChild(notification);
    
    // 自动关闭
    if (duration > 0) {
      setTimeout(closeNotification, duration);
    }
    
    return notification;
  }

  // 面板拖动相关变量
  // 保存表单状态
  function saveFormState() {
    const panel = document.getElementById('apollo-helper-panel');
    const toggle = document.getElementById('apollo-helper-toggle');
    
    const state = {
      owner: DEFAULT_OWNER, // 使用默认Owner
      envs: selectedEnvs.length > 0 ? selectedEnvs : ['ALL'], // 保存选中的环境数组
      appId: selectedAppIds.length > 0 ? selectedAppIds : ['ALL'], // 保存选中的AppId数组
      namespaces: selectedNamespaces.length > 0 ? selectedNamespaces : ['ALL'], // 保存选中的Namespace数组
      keyPrefix: keyInput.value,
      valueFilter: valueInput.value,
      namespace: namespaceInput ? namespaceInput.value : '', // 保持兼容性
      ttl: ttlSelect.value,
      prodConfigIp: prodConfigIpInput ? prodConfigIpInput.value : '', // 保存PROD配置服务IP
      prodConfigPort: prodConfigPortInput ? prodConfigPortInput.value : '8000', // 保存PROD配置服务Port
      // 添加面板位置和大小保存
      panelPosition: {
        left: panel.style.left,
        top: panel.style.top,
        right: panel.style.right,
        width: panel.style.width
      },
      // 添加按钮位置保存
      togglePosition: {
        left: toggle.style.left,
        top: toggle.style.top,
        right: toggle.style.right
      }
    };
    
    localStorage.setItem('apollo_helper_form_state', JSON.stringify(state));
  }

  // 解析URL hash参数并自动选择
  function parseUrlHashAndSelect() {
    const hash = window.location.hash;
    if (!hash) return;
    
    try {
      // 解析 hash 格式: #/appid=student-center&env=PROD&cluster=default
      const params = {};
      const hashMatch = hash.match(/^#\/?(.*)$/);
      if (hashMatch && hashMatch[1]) {
        const pairs = hashMatch[1].split('&');
        for (const pair of pairs) {
          const [key, value] = pair.split('=');
          if (key && value) {
            params[key.trim()] = decodeURIComponent(value.trim());
          }
        }
      }
      
      let hasChanges = false;
      
      // 处理 appid 参数 - 替换而不是新增
      if (params.appid) {
        const appId = params.appid;
        // 如果URL中的appId与当前选择的不同，则替换
        if (selectedAppIds.length !== 1 || selectedAppIds[0] !== appId) {
          selectedAppIds = [appId]; // 替换为URL中的appId
          console.log(`从URL自动选择AppId: ${appId} (替换现有选择)`);
          hasChanges = true;
        }
      }
      
      // 处理 env 参数 - 替换而不是新增
      if (params.env) {
        const env = params.env.toUpperCase(); // 转换为大写
        // 如果URL中的env与当前选择的不同，则替换
        if (selectedEnvs.length !== 1 || selectedEnvs[0] !== env) {
          // 如果是PROD环境，跳过确认提示（因为是从URL自动选择的）
          selectedEnvs = [env]; // 替换为URL中的环境
          console.log(`从URL自动选择环境: ${env} (替换现有选择)`);
          hasChanges = true;
        }
      }
      
      // 如果有URL参数，更新显示并保存状态
      if (hasChanges) {
        // 确保UI元素已初始化
        if (appIdSelect && appIdSelect.selected) {
          updateSelectedAppIdsDisplay();
        }
        if (envSelect && envSelect.selected) {
          updateSelectedEnvsDisplay();
        }
        saveFormState();
      }
    } catch (e) {
      console.error('解析URL hash参数失败:', e);
    }
  }

  // 加载表单状态
  function loadFormState() {
    const stateJson = localStorage.getItem('apollo_helper_form_state');
    if (!stateJson) return;
    
    try {
      const state = JSON.parse(stateJson);
      
      // Owner已移除，不再需要设置
      if (state.envs && Array.isArray(state.envs)) {
        selectedEnvs = state.envs.filter(env => env !== 'ALL'); // 加载选中的环境
      }
      if (state.appId && Array.isArray(state.appId)) {
        selectedAppIds = state.appId.filter(id => id !== 'ALL'); // 加载选中的AppId
      }
      if (state.namespaces && Array.isArray(state.namespaces)) {
        selectedNamespaces = state.namespaces.filter(ns => ns !== 'ALL'); // 加载选中的Namespace
      }
      if (state.keyPrefix) keyInput.value = state.keyPrefix;
      if (state.valueFilter) valueInput.value = state.valueFilter;
      if (state.namespace && namespaceInput) namespaceInput.value = state.namespace; // 保持兼容性
      if (state.ttl) ttlSelect.value = state.ttl;
      if (state.prodConfigIp && prodConfigIpInput) prodConfigIpInput.value = state.prodConfigIp;
      if (state.prodConfigPort && prodConfigPortInput) {
        prodConfigPortInput.value = state.prodConfigPort;
      } else if (prodConfigPortInput && !prodConfigPortInput.value) {
        prodConfigPortInput.value = '8000'; // 默认端口
      }
      
      // 兼容旧版本的 prodConfigServer (格式: ip:port)
      if (state.prodConfigServer && !state.prodConfigIp && !state.prodConfigPort) {
        const parts = state.prodConfigServer.split(':');
        if (parts.length === 2 && prodConfigIpInput && prodConfigPortInput) {
          prodConfigIpInput.value = parts[0];
          prodConfigPortInput.value = parts[1];
        }
      }
      
      // 恢复面板位置和大小
      if (state.panelPosition) {
        const panel = document.getElementById('apollo-helper-panel');
        if (panel) {
          if (state.panelPosition.left) panel.style.left = state.panelPosition.left;
          if (state.panelPosition.top) panel.style.top = state.panelPosition.top;
          if (state.panelPosition.right) panel.style.right = state.panelPosition.right;
          if (state.panelPosition.width) panel.style.width = state.panelPosition.width;
        }
      }
      
      // 恢复按钮位置
      if (state.togglePosition) {
        const toggle = document.getElementById('apollo-helper-toggle');
        if (toggle) {
          if (state.togglePosition.left) toggle.style.left = state.togglePosition.left;
          if (state.togglePosition.top) toggle.style.top = state.togglePosition.top;
          if (state.togglePosition.right) toggle.style.right = state.togglePosition.right;
        }
      }
    } catch (e) {
      console.error('加载表单状态失败:', e);
    }
  }

  function updateKeyDropdown(prefix) {
    if (!keyInput || !keyDropdown) return;
    keyDropdown.innerHTML = '';
    const lower = (prefix || '').toLowerCase();
    const unique = Array.from(new Set(keyPool));
    const filtered = unique.filter(k => !lower || k.toLowerCase().startsWith(lower)).slice(0, 20);
    
    if (filtered.length === 0) {
      keyDropdown.classList.remove('show');
      return;
    }

    for (const k of filtered) {
      const item = document.createElement('div');
      item.className = 'key-dropdown-item';
      item.textContent = k;
      item.addEventListener('click', () => {
        keyInput.value = k;
        keyDropdown.classList.remove('show');
        saveFormState();
      });
      keyDropdown.appendChild(item);
    }
    keyDropdown.classList.add('show');
  }

  function hideKeyDropdown() {
    if (!keyDropdown) return;
    keyDropdown.classList.remove('show');
  }

  function updateValueDropdown(text) {
    if (!valueInput || !valueDropdown) return;
    valueDropdown.innerHTML = '';
    const lower = (text || '').toLowerCase();
    const unique = Array.from(new Set(valuePool));
    const filtered = unique.filter(v => !lower || v.toLowerCase().includes(lower)).slice(0, 20);
    
    if (filtered.length === 0) {
      valueDropdown.classList.remove('show');
      return;
    }

    for (const v of filtered) {
      const item = document.createElement('div');
      item.className = 'value-dropdown-item';
      item.textContent = v;
      item.addEventListener('click', () => {
        valueInput.value = v;
        valueDropdown.classList.remove('show');
        saveFormState();
      });
      valueDropdown.appendChild(item);
    }
    valueDropdown.classList.add('show');
  }

  function hideValueDropdown() {
    if (!valueDropdown) return;
    valueDropdown.classList.remove('show');
  }

  function downloadText(filename, text) {
    const blob = new Blob([text], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // 渲染结果行
  function renderRows(rows) {
    if (!tbody) return;
    
    const tableEl = document.getElementById('apollo-table');
    const loadingDiv = document.getElementById('apollo-loading');
    const summaryEl = document.getElementById('apollo-summary');
    
    tbody.innerHTML = '';
    
    if (rows.length === 0) {
      if (summaryEl) summaryEl.textContent = '没有找到匹配的配置';
      if (loadingDiv) loadingDiv.style.display = 'none';
      return;
    }
    
    // 创建一个文档片段，提高性能
    const fragment = document.createDocumentFragment();
    
    for (const row of rows) {
      const tr = document.createElement('tr');
      
      // 创建一个简单的文本复制函数
      const createCopyableCell = (text, maxWidth, isWordBreak = false) => {
        const td = document.createElement('td');
        
        // 添加文本内容
        td.textContent = text || '';
        
        // 设置样式
        td.style.maxWidth = maxWidth || 'auto';
        td.style.overflow = 'hidden';
        td.style.textOverflow = 'ellipsis';
        td.style.whiteSpace = isWordBreak ? 'normal' : 'nowrap';
        if (isWordBreak) {
          td.style.wordBreak = 'break-word';
        }
        
        // 添加title属性，方便查看完整内容
        td.title = text || '';
        
        // 添加双击复制功能
        td.addEventListener('dblclick', () => {
          // 获取完整的原始数据（如果存在）
          const originalData = td.getAttribute('data-original') || text || '';
          
          // 创建一个临时textarea用于复制
          const textarea = document.createElement('textarea');
          textarea.value = originalData;
          textarea.style.position = 'absolute';
          textarea.style.left = '-9999px';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          
          // 创建提示元素
          const tooltip = document.createElement('div');
          const isTruncated = originalData.length > 50;
          tooltip.textContent = isTruncated ? 
            `已复制完整内容 (${originalData.length} 字符)` : 
            '已复制';
          tooltip.style.cssText = `
            position: fixed;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 10002;
            pointer-events: none;
            transition: opacity 0.3s;
          `;
          
          // 定位提示元素在单元格附近
          const rect = td.getBoundingClientRect();
          tooltip.style.top = `${rect.bottom + 5}px`;
          tooltip.style.left = `${rect.left + rect.width / 2}px`;
          tooltip.style.transform = 'translateX(-50%)';
          
          document.body.appendChild(tooltip);
          
          // 提供复制成功的视觉反馈
          const originalBackground = td.style.backgroundColor;
          td.style.backgroundColor = '#e6f7ff';
          
          // 2秒后移除提示和恢复背景色
          setTimeout(() => {
            tooltip.style.opacity = '0';
            setTimeout(() => document.body.removeChild(tooltip), 300);
            td.style.backgroundColor = originalBackground;
          }, 2000);
        });
        
        return td;
      };
      
              // 使用创建的函数添加单元格
        // AppId、Env、Namespace 显示全部内容
    const appIdCell = createCopyableCell(row.appId, 'auto');
    appIdCell.setAttribute('data-original', row.appId);
    tr.appendChild(appIdCell);
    
    const envCell = createCopyableCell(row.environment, 'auto');
    envCell.setAttribute('data-original', row.environment);
    tr.appendChild(envCell);
    
    const namespaceCell = createCopyableCell(row.namespace, 'auto');
    namespaceCell.setAttribute('data-original', row.namespace);
    tr.appendChild(namespaceCell);
    
    // Key 显示全部内容
    const keyCell = createCopyableCell(row.key, 'auto');
    keyCell.setAttribute('data-original', row.key); // 存储完整的原始数据
    tr.appendChild(keyCell);
    
    // Value 最多50个字符，超出显示省略号
    const displayValue = row.value.length > 50 ? row.value.substring(0, 50) + '...' : row.value;
    const valueCell = createCopyableCell(displayValue, '300px', true);
    valueCell.setAttribute('data-original', row.value); // 存储完整的原始数据
    valueCell.title = row.value; // 完整内容显示在title中
    tr.appendChild(valueCell);
      
      fragment.appendChild(tr);
    }
    
    tbody.appendChild(fragment);
    
    if (summaryEl) summaryEl.textContent = `共找到 ${rows.length} 条配置`;
    if (loadingDiv) loadingDiv.style.display = 'none';
    if (tableEl) tableEl.style.display = 'table';
  }

  // 添加导出CSV的改进函数
  function toCsv(items) {
    const header = ['AppId','Environment','Namespace','Key','Value'];
    const lines = [];
    
    // 添加标题行
    lines.push(header.join(','));
    
    // 添加数据行
    for (const item of items) {
      const values = header.map(h => {
        const fieldName = h.charAt(0).toLowerCase() + h.slice(1);
        let value = item[fieldName] || '';
        
        // 处理包含逗号、换行符或双引号的值
        if (typeof value === 'string' && (value.includes(',') || value.includes('\n') || value.includes('"'))) {
          // 替换双引号为两个双引号（CSV标准）
          value = value.replace(/"/g, '""');
          // 用双引号包裹整个值
          value = `"${value}"`;
        }
        
        return value;
      });
      
      lines.push(values.join(','));
    }
    
    return lines.join('\n');
  }
  
  // 添加导出JSON的函数
  function toJson(items) {
    return JSON.stringify(items, null, 2);
  }
  
  // 显示导出格式选择对话框
  function showExportFormatDialog(rows) {
    // 创建对话框
    const dialog = document.createElement('div');
    dialog.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 20px;
      z-index: 10002;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      min-width: 300px;
    `;
    
    dialog.innerHTML = `
      <h3 style="margin-top: 0; color: #1890ff;">选择导出格式</h3>
      <div style="margin: 20px 0;">
        <p style="margin-bottom: 10px;">共 ${rows.length} 条配置数据</p>
        <button id="export-csv-btn" style="width: 100%; padding: 10px; margin-bottom: 10px; background: #52c41a; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px;">
          导出为 CSV
        </button>
        <button id="export-json-btn" style="width: 100%; padding: 10px; margin-bottom: 10px; background: #1890ff; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 14px;">
          导出为 JSON
        </button>
        <button id="export-cancel-btn" style="width: 100%; padding: 10px; background: #f5f5f5; border: 1px solid #d9d9d9; border-radius: 4px; cursor: pointer; font-size: 14px;">
          取消
        </button>
      </div>
    `;
    
    // 创建遮罩层
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.5);
      z-index: 10001;
    `;
    
    document.body.appendChild(overlay);
    document.body.appendChild(dialog);
    
    // 添加按钮事件
    const csvBtn = dialog.querySelector('#export-csv-btn');
    const jsonBtn = dialog.querySelector('#export-json-btn');
    const cancelBtn = dialog.querySelector('#export-cancel-btn');
    
    const cleanup = () => {
      document.body.removeChild(dialog);
      document.body.removeChild(overlay);
    };
    
    csvBtn.addEventListener('click', () => {
      const csv = toCsv(rows);
      downloadText(`apollo_config_${new Date().toISOString().split('T')[0]}.csv`, csv);
      cleanup();
    });
    
    jsonBtn.addEventListener('click', () => {
      const json = toJson(rows);
      downloadText(`apollo_config_${new Date().toISOString().split('T')[0]}.json`, json);
      cleanup();
    });
    
    cancelBtn.addEventListener('click', cleanup);
    overlay.addEventListener('click', cleanup);
  }

  async function safeFetchJson(url) {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
    const data = await res.json();
    
    // 处理特殊状态码
    if (data && data.code === 700 && data.location) {
      console.log('收到重定向请求，code=700，location=', data.location);
      
      // 只在第一次遇到重定向时打开登录页面
      if (!isLoginPageOpened) {
        isLoginPageOpened = true;
        // window.open(data.location, '_blank');
        console.log('已打开登录页面，后续重定向请求将被忽略');
        
        // 设置一个定时器，30秒后重置标识，允许再次打开登录页面
        setTimeout(() => {
          isLoginPageOpened = false;
          console.log('登录页面打开标识已重置');
        }, 30000);
      } else {
        console.log('登录页面已打开，跳过重复打开');
      }
      
      // 抛出错误，中断当前操作
      throw new Error('需要重新登录，已在新标签页打开登录页面');
    }
    
    return data;
  }

  async function getCurrentOwner() {
    const cacheKey = 'apollo_helper_current_user';
    const cached = await cacheGet(cacheKey);
    if (cached) return cached;
    try {
      const data = await safeFetchJson(`${BASE}/user`);
      const id = data?.userId || data?.username || data?.name || data?.loginName;
      if (id) {
        await cacheSet(cacheKey, id);
        return id;
      }
    } catch {}
    return null; 
  }

  async function loadAppIdsByOwner(owner, opts = { force: false }) {
    console.log('loadAppIdsByOwner 开始执行, owner:', owner, 'force:', opts.force);
    const cacheKey = `apollo_helper_appids_${owner}`;
    
    if (!opts.force) {
      const cached = await cacheGet(cacheKey);
      if (Array.isArray(cached) && cached.length > 0) {
        console.log('从缓存加载 appIds, 数量:', cached.length);
        appIds = cached; // 确保从缓存加载时也设置全局变量
        return shuffleArray(cached);
      }
    }
    
    console.log('从服务器加载 appIds...');
    const pageSize = 500;
    let page = 0;
    const ids = [];
    
    try {
      while (true) {
        const url = `${BASE}/apps/by-owner?owner=${encodeURIComponent(owner)}&page=${page}&size=${pageSize}`;
        
        const data = await safeFetchJson(url);
        let batch = [];
        
        if (Array.isArray(data)) {
          batch = data;
          console.log('数据是数组, 长度:', data.length);
        } else if (Array.isArray(data?.content)) {
          batch = data.content;
          console.log('数据是分页对象, 内容长度:', data.content.length);
        } else if (Array.isArray(data?.data)) {
          batch = data.data;
          console.log('数据包含data字段, 长度:', data.data.length);
        } else {
          console.log('未找到有效数据结构:', data);
          break;
        }
        
        for (const app of batch) {
          if (app?.appId) ids.push(app.appId);
        }
        
        if (Array.isArray(data)) break;
        if (data.last === true || batch.length === 0) break;
        
        page += 1;
        if (page > 100) {
          console.warn('达到最大页数限制 (100)');
          break;
        }
      }
      
      const unique = shuffleArray(Array.from(new Set(ids)));
      console.log('获取到的唯一appIds数量:', unique.length);
      
      // 设置全局变量
      appIds = unique;
      
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      
      // 缓存结果
      await cacheSet(cacheKey, unique, ttlValue);
      console.log(`appIds已缓存, key: ${cacheKey}, 过期时间: ${ttlValue}ms (${(ttlValue / (24*60*60*1000)).toFixed(1)}天)`);
      
      return unique;
    } catch (e) {
      console.error('加载appIds失败:', e);
      // 出错时返回空数组，但不缓存
      return [];
    }
  }

  // 批量获取namespaces的函数
  async function batchListNamespaces(appIdEnvPairs) {
    console.log(`批量获取namespaces，共 ${appIdEnvPairs.length} 个请求`);
    const startTime = Date.now();
    
    // 并发限制
    const MAX_CONCURRENT = 10;
    const results = {};
    const queue = [...appIdEnvPairs];
    
    // 处理队列中的请求
    async function processQueue() {
      if (queue.length === 0) return;
      
      const {appId, env} = queue.shift();
      const key = `${appId}:${env}`;
      
      try {
        const data = await listNamespaces(appId, env);
        results[key] = data;
      } catch (e) {
        console.error(`获取 ${appId}/${env} 的namespaces失败:`, e);
        results[key] = [];
      }
      
      await processQueue();
    }
    
    // 启动并发处理
    const workers = [];
    for (let i = 0; i < Math.min(MAX_CONCURRENT, queue.length); i++) {
      workers.push(processQueue());
    }
    
    await Promise.all(workers);
    
    const endTime = Date.now();
    console.log(`批量获取namespaces完成，耗时: ${endTime - startTime}ms`);
    return results;
  }

  async function listNamespaces(appId, env) {
    const cacheKey = `apollo_helper_ns_${appId}_${env}`;
    const cached = await cacheGet(cacheKey);
    if (!forceChk.checked && Array.isArray(cached)) return cached;
    
    const url = `${BASE}/apps/${encodeURIComponent(appId)}/envs/${encodeURIComponent(env)}/clusters/default/namespaces?debug=`;
    // console.log('listNamespaces url:', url);
    
    const data = await safeFetchJson(url);
    if (Array.isArray(data)) {
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      await cacheSet(cacheKey, data, ttlValue);
    }
    return data;
  }

  // 错误黑名单管理
  async function addToErrorBlacklist(appId, env, namespace, reason) {
    const blacklistKey = 'apollo_helper_error_blacklist';
    let blacklist = await cacheGet(blacklistKey) || {};
    
    const key = `${appId}:${env}:${namespace}`;
    blacklist[key] = {
      reason,
      timestamp: Date.now()
    };
    
    // 只保留最近1000个错误记录
    const keys = Object.keys(blacklist);
    if (keys.length > 1000) {
      // 按时间排序，删除最旧的记录
      const sortedKeys = keys.sort((a, b) => blacklist[a].timestamp - blacklist[b].timestamp);
      const keysToDelete = sortedKeys.slice(0, keys.length - 1000);
      keysToDelete.forEach(k => delete blacklist[k]);
    }
    
    // 使用较长的缓存时间
    await cacheSet(blacklistKey, blacklist, TTL_30D);
    console.log(`已将 ${key} 添加到错误黑名单，原因: ${reason}`);
  }
  
  // 检查是否在错误黑名单中
  async function isInErrorBlacklist(appId, env, namespace) {
    const blacklistKey = 'apollo_helper_error_blacklist';
    const blacklist = await cacheGet(blacklistKey) || {};
    const key = `${appId}:${env}:${namespace}`;
    return !!blacklist[key];
  }

  async function listNamespacesTest(appId, env, namespace) {
    const cacheKey = `apollo_helper_test_ns_${appId}_${env}_${namespace}`;
    const cached = await cacheGet(cacheKey);
    if (!forceChk.checked && cached) return cached;
    
    // 检查是否在黑名单中
    if (!forceChk.checked && await isInErrorBlacklist(appId, env, namespace)) {
      console.log(`${appId}/${env}/${namespace} 在错误黑名单中，跳过请求`);
      return { configurations: {}, error: { status: 404, message: "在错误黑名单中" } };
    }
    
    const url = `https://${env.toLowerCase()}-apollo-meta.baijia.com/configs/${appId}/${env}/${namespace}`;
    
    try {
      const response = await new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          reject(new Error('请求超时（15秒）'));
        }, 15000);
        
        chrome.runtime.sendMessage({
          action: 'fetchWithCORS',
          url: url,
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        }, (response) => {
          clearTimeout(timeoutId);
          
          if (!response) {
            reject(new Error('未收到响应'));
          } else if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.success) {
            
            // 处理 no-cors 模式下的特殊响应
            if (response.data && response.data.message && response.data.message.includes('opaque due to CORS')) {
              console.log('收到 no-cors 响应，回退到 portal 接口');
              throw new Error('需要回退到 portal 接口');
            }
            
            // 检查是否是404错误
            if (response.data && response.data.status === 404) {
              console.log('收到404错误响应，缓存空结果');
              resolve({ configurations: {}, error: response.data });
            } else {
              resolve(response.data);
            }
          } else if (response && response.error) {
            console.error('请求失败:', response.error);
            
            // 检查是否是404错误
            if (response.error.includes('404') || response.error.includes('Not Found')) {
              console.log('请求失败(404)，缓存空结果');
              resolve({ configurations: {}, error: { status: 404, message: response.error } });
            } else {
              reject(new Error(response.error));
            }
          } else {
            console.error('未知响应格式:', response);
            reject(new Error('未知响应格式'));
          }
        });
      });
      
      // 如果是404错误，添加到黑名单并使用更长的缓存时间
      if (response.error && response.error.status === 404) {
        console.log(`${appId}/${env}/${namespace} 返回404，添加到黑名单 url: ${url}`);
        await addToErrorBlacklist(appId, env, namespace, '404 Not Found');
        await cacheSet(cacheKey, response, TTL_30D);
      } else {
        // 正常响应使用用户设置的缓存时间
        const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
        await cacheSet(cacheKey, response, ttlValue);
      }
      
      return response;
    } catch (e) {
      console.error(`请求失败: ${e.message}, url: ${url}`);
      
      // 检查错误是否包含404
      const is404Error = e.message && (
        e.message.includes('404') || 
        e.message.includes('Not Found') || 
        e.message.toLowerCase().includes('could not load')
      );
      
      if (is404Error) {
        console.log(`检测到404错误: ${e.message}`);
        const errorResponse = { 
          configurations: {}, 
          error: { 
            status: 404, 
            message: e.message 
          } 
        };
        
        // 添加到黑名单并使用更长的缓存时间
        await addToErrorBlacklist(appId, env, namespace, '404 Not Found');
        await cacheSet(cacheKey, errorResponse, TTL_30D);
        
        return errorResponse;
      }
    }
    
    // 所有策略都失败，返回空配置
    console.log('请求失败，返回空配置');
    return { configurations: {} };
  }
  
  // 使用自定义PROD配置服务获取配置
  async function fetchFromProdConfigServer(appId, env, namespace, serverAddress, failedServers) {
    const cacheKey = `apollo_helper_prod_custom_${appId}_${env}_${namespace}_${serverAddress}`;
    const cached = await cacheGet(cacheKey);
    if (!forceChk.checked && cached) {
      console.log(`使用缓存的PROD配置服务数据: ${appId}/${env}/${namespace}`);
      return cached;
    }
    
    // 检查服务器是否已标记为失败
    if (failedServers && failedServers.has(serverAddress)) {
      console.log(`⚠️ PROD配置服务 ${serverAddress} 已标记为不可用，跳过请求: ${appId}/${env}/${namespace}`);
      return { 
        configurations: {}, 
        error: { message: '服务不可用' },
        serverFailed: true 
      };
    }
    
    // 构建URL
    const url = `http://${serverAddress}/configs/${appId}/${env}/${namespace}`;
    console.log(`使用自定义PROD配置服务获取: ${url}`);
    
    try {
      const response = await new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          reject(new Error('请求超时（15秒）'));
        }, 15000);
        
        chrome.runtime.sendMessage({
          action: 'fetchWithCORS',
          url: url,
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        }, (response) => {
          clearTimeout(timeoutId);
          
          if (!response) {
            reject(new Error('未收到响应'));
          } else if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.success) {
            resolve(response.data);
          } else if (response && response.error) {
            reject(new Error(response.error));
          } else {
            reject(new Error('未知响应格式'));
          }
        });
      });
      
      // 新接口返回格式：
      // {
      //   'appId': 'coupon-management.gaotu100.com',
      //   'cluster': 'default',
      //   'namespaceName': 'redis',
      //   'configurations': { 'key': 'value', ... },
      //   'releaseKey': '20210629145602-c18b0f2306a16f97'
      // }
      
      // 调试：输出完整的响应数据
      console.log(`[调试] PROD配置服务返回数据:`, JSON.stringify(response, null, 2));
      
      // 标准化返回格式，确保有 configurations 字段
      let normalizedResponse;
      if (response && typeof response === 'object') {
        // 检查是否有 configurations 字段（使用 hasOwnProperty 更可靠）
        const hasConfigurations = Object.prototype.hasOwnProperty.call(response, 'configurations');
        console.log(`[调试] response 是否有 configurations 属性: ${hasConfigurations}`);
        
        if (hasConfigurations && response.configurations !== null && typeof response.configurations === 'object') {
          const configCount = Object.keys(response.configurations).length;
          normalizedResponse = {
            configurations: response.configurations,
            appId: response.appId || appId,
            namespaceName: response.namespaceName || namespace,
            cluster: response.cluster || 'default',
            releaseKey: response.releaseKey || ''
          };
          console.log(`✅ 成功从PROD配置服务获取: ${appId}/${env}/${namespace}, 配置项数: ${configCount}`);
        } else {
          // 如果没有 configurations 字段，返回空配置
          console.warn(`❌ PROD配置服务返回数据中没有 configurations 字段: ${appId}/${env}/${namespace}`);
          console.warn(`[调试] response 的所有键:`, Object.keys(response || {}));
          console.warn(`[调试] hasConfigurations: ${hasConfigurations}`);
          console.warn(`[调试] configurations 值:`, response.configurations);
          console.warn(`[调试] configurations 类型:`, typeof response.configurations);
          normalizedResponse = { configurations: {} };
        }
      } else {
        console.warn(`❌ PROD配置服务返回格式异常: ${appId}/${env}/${namespace}`);
        console.warn(`[调试] response 类型: ${typeof response}, 值:`, response);
        normalizedResponse = { configurations: {} };
      }
      
      // 缓存结果
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      await cacheSet(cacheKey, normalizedResponse, ttlValue);
      console.log(`PROD配置服务数据已缓存: ${appId}/${env}/${namespace}, TTL: ${ttlValue}ms`);
      
      return normalizedResponse;
    } catch (e) {
      console.error(`❌ 从自定义PROD配置服务获取失败: ${e.message}, url: ${url}`);
      console.error(`❌ 错误详情:`, e);
      
      // 检查是否是连接失败或拒绝访问的错误（放宽匹配条件）
      const isConnectionError = e.message && (
        e.message.includes('Failed to fetch') ||
        e.message.includes('fetch') ||
        e.message.includes('ERR_CONNECTION') ||
        e.message.includes('ERR_REFUSED') ||
        e.message.includes('Network request failed') ||
        e.message.includes('network') ||
        e.message.includes('请求超时') ||
        e.message.includes('超时') ||
        e.message.includes('refused') ||
        e.message.includes('拒绝') ||
        e.message.includes('All fetch strategies failed')
      );
      
      console.log(`[调试] 是否判断为连接错误: ${isConnectionError}, 错误消息: "${e.message}"`);
      
      if (isConnectionError && failedServers) {
        // 将服务器标记为失败
        failedServers.add(serverAddress);
        console.error(`🚫 PROD配置服务 ${serverAddress} 连接失败，已标记为不可用，本次搜索将跳过后续请求`);
      }
      
      return { 
        configurations: {}, 
        error: { message: e.message },
        serverFailed: isConnectionError 
      };
    }
  }

  // AppId多选功能
  function addAppId(appId) {
    if (!appId || selectedAppIds.includes(appId)) return;
    selectedAppIds.push(appId);
    updateSelectedAppIdsDisplay();
    appIdSelect.input.value = '';
    hideAppIdDropdown();
    saveFormState();
  }
  
  function removeAppId(appId) {
    selectedAppIds = selectedAppIds.filter(id => id !== appId);
    updateSelectedAppIdsDisplay();
    saveFormState();
  }
  
  function updateSelectedAppIdsDisplay() {
    const container = appIdSelect.selected;
    // 清除现有的选中项（保留输入框）
    const children = Array.from(container.children);
    children.forEach(child => {
      if (child !== appIdSelect.input) {
        container.removeChild(child);
      }
    });
    
    // 添加选中的AppId标签
    selectedAppIds.forEach(appId => {
      const tag = document.createElement('span');
      tag.style.cssText = 'background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; padding: 2px 6px; font-size: 11px; display: flex; align-items: center; gap: 3px;';
      
      const text = document.createElement('span');
      text.textContent = appId;
      
      const removeBtn = document.createElement('span');
      removeBtn.textContent = '×';
      removeBtn.style.cssText = 'cursor: pointer; color: #666; font-weight: bold;';
      removeBtn.onclick = (e) => {
        e.stopPropagation();
        removeAppId(appId);
      };
      
      tag.appendChild(text);
      tag.appendChild(removeBtn);
      container.insertBefore(tag, appIdSelect.input);
    });
  }
  
  function showAppIdDropdown() {
    if (!appIds.length) return;
    
    const inputValue = appIdSelect.input.value.toLowerCase();
    const filteredAppIds = appIds.filter(id => 
      id.toLowerCase().includes(inputValue) && 
      !selectedAppIds.includes(id)
    ).slice(0, 20);
    
    const dropdown = appIdSelect.dropdown;
    dropdown.innerHTML = '';
    
    if (filteredAppIds.length === 0) {
      dropdown.style.display = 'none';
      return;
    }
    
    filteredAppIds.forEach(id => {
      const option = document.createElement('div');
      option.style.cssText = 'padding: 5px; cursor: pointer; border-bottom: 1px solid #eee;';
      option.textContent = id;
      option.onclick = () => addAppId(id);
      option.onmouseover = () => option.style.background = '#f0f0f0';
      option.onmouseout = () => option.style.background = 'white';
      dropdown.appendChild(option);
    });
    
    dropdown.style.display = 'block';
  }
  
  function hideAppIdDropdown() {
    appIdSelect.dropdown.style.display = 'none';
  }
  
  // 环境多选功能
  function addEnv(env) {
    if (!env || selectedEnvs.includes(env)) return;
    
    // 如果选择PROD环境，添加友好提示
    if (env === 'PROD') {
      const confirmMsg = '注意: PROD环境需要对应权限才能访问配置。\n\n确定要添加PROD环境吗？';
      if (!confirm(confirmMsg)) {
        return;
      }
    }
    
    selectedEnvs.push(env);
    updateSelectedEnvsDisplay();
    envSelect.input.value = '';
    hideEnvDropdown();
    saveFormState();
  }
  
  function removeEnv(env) {
    selectedEnvs = selectedEnvs.filter(e => e !== env);
    updateSelectedEnvsDisplay();
    saveFormState();
  }
  
  function updateSelectedEnvsDisplay() {
    const container = envSelect.selected;
    // 清除现有的选中项（保留输入框）
    const children = Array.from(container.children);
    children.forEach(child => {
      if (child !== envSelect.input) {
        container.removeChild(child);
      }
    });
    
    // 添加选中的环境标签
    selectedEnvs.forEach(env => {
      const tag = document.createElement('span');
      tag.style.cssText = 'background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; padding: 2px 6px; font-size: 11px; display: flex; align-items: center; gap: 3px;';
      
      const text = document.createElement('span');
      text.textContent = env;
      
      const removeBtn = document.createElement('span');
      removeBtn.textContent = '×';
      removeBtn.style.cssText = 'cursor: pointer; color: #666; font-weight: bold;';
      removeBtn.onclick = (e) => {
        e.stopPropagation();
        removeEnv(env);
      };
      
      tag.appendChild(text);
      tag.appendChild(removeBtn);
      container.insertBefore(tag, envSelect.input);
    });
  }
  
  function showEnvDropdown() {
    const dropdown = envSelect.dropdown;
    dropdown.style.display = 'block';
    
    // 高亮已选择的环境
    const items = dropdown.querySelectorAll('.env-dropdown-item');
    items.forEach(item => {
      const env = item.getAttribute('data-env');
      if (selectedEnvs.includes(env)) {
        item.style.background = '#e6f7ff';
        // 添加选中标记
        const firstChild = item.querySelector('div:first-child');
        if (firstChild && !firstChild.querySelector('.selected-mark')) {
          const mark = document.createElement('span');
          mark.className = 'selected-mark';
          mark.textContent = ' ✓';
          mark.style.color = '#1890ff';
          firstChild.appendChild(mark);
        }
      } else {
        item.style.background = 'white';
        // 移除选中标记
        const mark = item.querySelector('.selected-mark');
        if (mark) {
          mark.remove();
        }
      }
    });
  }
  
  function hideEnvDropdown() {
    envSelect.dropdown.style.display = 'none';
  }
  
  // Namespace多选功能
  function addNamespace(namespace) {
    if (!namespace || selectedNamespaces.includes(namespace)) return;
    selectedNamespaces.push(namespace);
    updateSelectedNamespacesDisplay();
    namespaceSelect.input.value = '';
    hideNamespaceDropdown();
    saveFormState();
  }
  
  function removeNamespace(namespace) {
    selectedNamespaces = selectedNamespaces.filter(ns => ns !== namespace);
    updateSelectedNamespacesDisplay();
    saveFormState();
  }
  
  function updateSelectedNamespacesDisplay() {
    const container = namespaceSelect.selected;
    // 清除现有的选中项（保留输入框）
    const children = Array.from(container.children);
    children.forEach(child => {
      if (child !== namespaceSelect.input) {
        container.removeChild(child);
      }
    });
    
    // 添加选中的Namespace标签
    selectedNamespaces.forEach(namespace => {
      const tag = document.createElement('span');
      tag.style.cssText = 'background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; padding: 2px 6px; font-size: 11px; display: flex; align-items: center; gap: 3px;';
      
      const text = document.createElement('span');
      text.textContent = namespace;
      
      const removeBtn = document.createElement('span');
      removeBtn.textContent = '×';
      removeBtn.style.cssText = 'cursor: pointer; color: #666; font-weight: bold;';
      removeBtn.onclick = (e) => {
        e.stopPropagation();
        removeNamespace(namespace);
      };
      
      tag.appendChild(text);
      tag.appendChild(removeBtn);
      container.insertBefore(tag, namespaceSelect.input);
    });
  }
  
  function showNamespaceDropdown() {
    if (!namespaces.length) return;
    
    const inputValue = namespaceSelect.input.value.toLowerCase();
    const filteredNamespaces = namespaces.filter(ns => 
      ns.toLowerCase().includes(inputValue) && 
      !selectedNamespaces.includes(ns)
    ).slice(0, 20);
    
    const dropdown = namespaceSelect.dropdown;
    dropdown.innerHTML = '';
    
    if (filteredNamespaces.length === 0) {
      dropdown.style.display = 'none';
      return;
    }
    
    filteredNamespaces.forEach(ns => {
      const option = document.createElement('div');
      option.style.cssText = 'padding: 5px; cursor: pointer; border-bottom: 1px solid #eee;';
      option.textContent = ns;
      option.onclick = () => addNamespace(ns);
      option.onmouseover = () => option.style.background = '#f0f0f0';
      option.onmouseout = () => option.style.background = 'white';
      dropdown.appendChild(option);
    });
    
    dropdown.style.display = 'block';
  }
  
  function hideNamespaceDropdown() {
    namespaceSelect.dropdown.style.display = 'none';
  }
  
  // 初始化环境多选事件
  function setupEnvEvents() {
    // 点击输入框显示下拉
    envSelect.input.addEventListener('focus', () => {
      showEnvDropdown();
    });
    
    // 添加提示图标
    const helpIcon = document.createElement('span');
    helpIcon.innerHTML = ' ℹ️';
    helpIcon.style.cssText = 'cursor: pointer; margin-left: 5px; font-size: 14px;';
    helpIcon.title = '提示: TEST和DEV环境无需特殊权限，PROD环境需要对应权限才能访问配置';
    
    // 将提示图标添加到标签旁边
    const envLabel = document.querySelector('label[for="apollo-env-container"]');
    if (envLabel) {
      envLabel.appendChild(helpIcon);
    }
    
    // 点击提示图标显示帮助信息
    helpIcon.addEventListener('click', (e) => {
      e.stopPropagation();
      alert('环境权限说明:\n\n' + 
            '• DEV: 开发环境，无需特殊权限\n' +
            '• TEST: 测试环境，无需特殊权限\n' + 
            '• PROD: 生产环境，需要对应权限才能访问\n\n' +
            '默认选择TEST和PROD环境，可根据需要调整。');
    });
    
    // 点击外部隐藏下拉框
    document.addEventListener('click', (e) => {
      if (!envSelect.selected.contains(e.target) && !envSelect.dropdown.contains(e.target)) {
        hideEnvDropdown();
      }
    });
    
    // 点击下拉项添加环境
    const items = envSelect.dropdown.querySelectorAll('.env-dropdown-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        const env = item.getAttribute('data-env');
        if (env === 'ALL') {
          // 如果选择ALL，清空其他选择
          selectedEnvs = [];
          updateSelectedEnvsDisplay();
          hideEnvDropdown();
        } else {
          // 从selectedEnvs中移除ALL（如果存在）
          selectedEnvs = selectedEnvs.filter(e => e !== 'ALL');
          // 切换选中状态
          if (selectedEnvs.includes(env)) {
            removeEnv(env);
          } else {
            addEnv(env);
          }
        }
        saveFormState();
      });
      
      // 添加鼠标悬停效果
      item.addEventListener('mouseover', () => {
        if (!selectedEnvs.includes(item.getAttribute('data-env'))) {
          item.style.background = '#f0f0f0';
        }
      });
      
      item.addEventListener('mouseout', () => {
        if (!selectedEnvs.includes(item.getAttribute('data-env'))) {
          item.style.background = 'white';
        }
      });
    });
    
    // 点击容器也显示下拉框
    envSelect.selected.addEventListener('click', (e) => {
      if (e.target === envSelect.selected) {
        envSelect.input.focus();
      }
    });
  }
  
  // 复制键值对功能
  function copyKeyValuePairs() {
    const tbody = document.getElementById('apollo-tbody');
    if (!tbody || tbody.children.length === 0) {
      alert('没有数据可复制，请先搜索配置');
      return;
    }
    
    const pairs = [];
    const rows = tbody.querySelectorAll('tr');
    
    for (const row of rows) {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 5) {
        // 优先使用存储的原始数据，如果没有则使用显示文本
        const key = cells[3].getAttribute('data-original') || cells[3].textContent.trim();
        const value = (cells[4].getAttribute('data-original') || cells[4].textContent.trim()).replace(/[\r\n]/g, ''); // 去掉换行符
        pairs.push(`${key}=${value}`);
      }
    }
    
    if (pairs.length === 0) {
      alert('没有有效的键值对数据');
      return;
    }
    
    // 使用系统换行符
    const lineBreak = navigator.platform.indexOf('Win') !== -1 ? '\r\n' : '\n';
    const content = pairs.join(lineBreak);
    
    // 复制到剪贴板
    if (navigator.clipboard && window.isSecureContext) {
      // 使用现代 API
      navigator.clipboard.writeText(content).then(() => {
        alert(`已复制 ${pairs.length} 个键值对到剪贴板, 注意: 会去掉换行!!!!`);
      }).catch(err => {
        console.error('复制失败:', err);
        fallbackCopyTextToClipboard(content, pairs.length);
      });
    } else {
      // 降级方案
      fallbackCopyTextToClipboard(content, pairs.length);
    }
  }
  
  // 降级复制方案
  function fallbackCopyTextToClipboard(text, count) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      const successful = document.execCommand('copy');
      if (successful) {
        alert(`已复制 ${count} 个键值对到剪贴板`);
      } else {
        alert('复制失败，请手动复制');
      }
    } catch (err) {
      console.error('降级复制失败:', err);
      alert('复制失败，请手动复制');
    } finally {
      document.body.removeChild(textArea);
    }
  }
  
  // 兼容性函数，保持原有接口
  function populateAppIdSelect(ids) {
    // 不需要实现，appIds已在全局变量中
    console.log('AppId列表已更新，共', ids.length, '个应用');
  }

  async function fetchAllItems(owner, envFilters, keyPrefix, selectedAppId, valueFilter, namespaceValue) {
    console.log('fetchAllItems 开始执行, appIds长度:', appIds.length);
    
    // 如果appIds为空，先尝试加载
    if (appIds.length === 0) {
      console.log('appIds为空，尝试加载...');
      try {
        await loadAppIdsByOwner(owner);
        console.log('加载完成，appIds长度:', appIds.length);
      } catch (e) {
        console.error('加载appIds失败:', e);
      }
    }
    
    // 如果仍然为空，返回空结果
    if (appIds.length === 0) {
      console.warn('无法获取appIds，返回空结果');
      return [];
    }
    
    // 处理环境过滤
    let environments;
    if (Array.isArray(envFilters)) {
      if (envFilters.length === 0 || envFilters.includes('ALL')) {
        environments = ['DEV', 'TEST', 'PROD'];
      } else {
        environments = envFilters;
      }
    } else {
      environments = envFilters === 'ALL' ? ['DEV', 'TEST', 'PROD'] : [envFilters];
    }
    console.log('使用环境过滤:', environments);
    
    // 处理 namespace 过滤
    let targetNamespaces = [];
    if (namespaceValue && namespaceValue !== 'ALL') {
      targetNamespaces = namespaceValue.split(',').map(ns => ns.trim()).filter(ns => ns);
    }
    console.log('使用 namespace 过滤:', targetNamespaces);
    
    // 根据选择的AppId进行筛选
    let filteredAppIds;
    if (selectedAppIds.length > 0) {
      appIds = [...new Set([...appIds, ...selectedAppIds])];
      filteredAppIds = appIds.filter(id => selectedAppIds.includes(id));
    } else {
      filteredAppIds = appIds; // 如果没有选择，使用所有AppId
    }
    filteredAppIds = shuffleArray(filteredAppIds)
    console.log('过滤后的appIds:', filteredAppIds);
    const result = [];
    
    // 构建需要请求的appId和env对
    const appIdEnvPairs = [];
    for (const appId of filteredAppIds) {
      for (const env of environments) {
        appIdEnvPairs.push({ appId, env });
      }
    }
    
    // 批量获取namespaces
    console.log('开始批量获取namespaces...');
    const batchStartTime = Date.now();
    const namespacesMap = await batchListNamespaces(appIdEnvPairs);
    const batchEndTime = Date.now();
    console.log(`批量获取完成，共 ${Object.keys(namespacesMap).length} 个结果，耗时: ${batchEndTime - batchStartTime}ms`);
    
    // 处理获取到的namespaces
    const processStartTime = Date.now();
    
    // 获取PROD配置服务地址（只有IP不为空时才启用）
    const prodConfigIp = prodConfigIpInput ? prodConfigIpInput.value.trim() : '';
    const prodConfigPort = prodConfigPortInput ? prodConfigPortInput.value.trim() : '8000';
    const prodConfigServer = prodConfigIp && prodConfigPort ? `${prodConfigIp}:${prodConfigPort}` : '';
    const hasProdEnv = environments.includes('PROD');
    const useProdConfigServer = hasProdEnv && prodConfigIp && prodConfigServer; // IP必须不为空
    
    console.log('========== PROD配置服务检查 ==========');
    console.log(`环境列表: ${environments.join(', ')}`);
    console.log(`包含PROD环境: ${hasProdEnv}`);
    if (prodConfigIp) {
      console.log(`配置服务IP: ${prodConfigIp}`);
      console.log(`配置服务Port: ${prodConfigPort}`);
      console.log(`完整地址: ${prodConfigServer}`);
      console.log(`启用PROD配置服务: ${useProdConfigServer}`);
    } else {
      console.log('配置服务: 未配置（IP为空）');
    }
    console.log('=====================================');
    
    if (useProdConfigServer) {
      console.log(`✅ 检测到PROD环境且配置了自定义配置服务: ${prodConfigServer}`);
    } else if (hasProdEnv && !prodConfigIp) {
      console.log('ℹ️ 检测到PROD环境但未配置自定义配置服务IP，将仅使用标准Apollo API');
    }
    
    // 收集所有 namespace 名称
    const foundNamespaces = new Set();
    
    // 并发处理隐藏配置
    const hiddenConfigTasks = [];
    const hiddenConfigResults = {};
    
    // 检查是否有需要跳过的配置（在黑名单中的）
    const blacklistCheckPromises = [];
    
    // 收集需要从PROD配置服务获取的namespace
    const prodConfigServerTasks = [];
    const prodConfigServerResults = {};
    
    // 创建一个 Set 用于记录本次搜索中失败的服务器
    const failedServers = new Set();
    
    // 用于记录是否已经弹窗提示过
    let hasAlertedServerFailure = false;
    
    for (const [key, namespaces] of Object.entries(namespacesMap)) {
      if (!Array.isArray(namespaces)) continue;
      
      const [appId, env] = key.split(':');
      
      for (const ns of namespaces) {
        const namespaceName = ns?.baseInfo?.namespaceName || ns?.namespaceName || ns?.name || 'application';
        const isConfigHidden = ns?.isConfigHidden || false;
        const items = ns?.items || ns?.baseInfo?.items || [];
        
        // 收集 namespace 名称
        foundNamespaces.add(namespaceName);
        
        // 如果设置了namespace过滤，检查是否匹配
        if (targetNamespaces.length > 0 && !targetNamespaces.includes(namespaceName)) continue;
        
        // 调试信息：显示当前处理的namespace和items数量
        const itemsCount = items.length;
        if (env === 'PROD') {
          console.log(`[PROD] ${appId}/${env}/${namespaceName}: items数量=${itemsCount}, 配置服务=${useProdConfigServer ? prodConfigServer : '未配置'}`);
        }
        
        // 检查items是否为空，如果为空且是PROD环境且配置了服务地址，使用自定义服务
        if (items.length === 0 && env === 'PROD' && useProdConfigServer && !failedServers.has(prodConfigServer)) {
          const taskKey = `${appId}:${env}:${namespaceName}`;
          console.log(`✅ ${taskKey} 的items为空，将使用自定义PROD配置服务获取: http://${prodConfigServer}/configs/${appId}/${env}/${namespaceName}`);
          
          prodConfigServerTasks.push(
            (async () => {
              try {
                console.log(`[任务开始] 获取 ${taskKey}`);
                const result = await fetchFromProdConfigServer(appId, env, namespaceName, prodConfigServer, failedServers);
                prodConfigServerResults[taskKey] = result;
                console.log(`[任务完成] ${taskKey}, serverFailed=${result.serverFailed}`);
                
                // 如果服务器失败且还未弹窗提示过，且代理地址仍然有效（用户没有删除）
                const currentProdIp = prodConfigIpInput ? prodConfigIpInput.value.trim() : '';
                if (result.serverFailed && !hasAlertedServerFailure && currentProdIp) {
                  hasAlertedServerFailure = true;
                  console.error(`🚫 检测到服务器连接失败，准备显示通知`);
                  
                  // 使用非阻塞通知代替 alert
                  setTimeout(() => {
                    // 再次检查代理地址是否还存在（用户可能在等待期间删除了）
                    const stillHasIp = prodConfigIpInput ? prodConfigIpInput.value.trim() : '';
                    if (stillHasIp) {
                      console.log(`[通知] 显示服务不可用提示`);
                      const message = `PROD配置代理服务不可用

服务地址: ${prodConfigServer}
错误信息: ${result.error?.message || '连接失败'}

后续请求将跳过此服务。

请检查：
1. Pod 机器上的代理脚本是否正在运行
2. IP 地址和端口是否正确
3. 网络连接是否正常`;
                      showNotification(message, 'warning', 3000); // 8秒后自动关闭
                    } else {
                      console.log(`[通知] 用户已删除代理地址，跳过通知`);
                    }
                  }, 100);
                }
              } catch (e) {
                console.error(`从PROD配置服务获取失败 ${taskKey}:`, e);
                prodConfigServerResults[taskKey] = { configurations: {} };
              }
            })()
          );
          continue;
        } else if (items.length === 0 && env === 'PROD' && useProdConfigServer && failedServers.has(prodConfigServer)) {
          console.log(`⏭️ ${appId}/${env}/${namespaceName} 的items为空，但PROD配置服务已不可用，跳过`);
          continue;
        }
        
        // 处理隐藏配置 - 收集需要请求的配置
        if (isConfigHidden && env !== 'PROD') {
          const taskKey = `${appId}:${env}:${namespaceName}`;
          
          // 先检查是否在黑名单中
          blacklistCheckPromises.push(
            (async () => {
              const inBlacklist = await isInErrorBlacklist(appId, env, namespaceName);
              if (inBlacklist && !forceChk.checked) {
                console.log(`${appId}/${env}/${namespaceName} 在错误黑名单中，跳过请求`);
                hiddenConfigResults[taskKey] = { 
                  configurations: {}, 
                  error: { status: 404, message: "在错误黑名单中" } 
                };
                return true; // 在黑名单中
              }
              return false; // 不在黑名单中
            })()
          );
          
          hiddenConfigTasks.push(
            (async () => {
              try {
                // 检查是否已经在黑名单检查中添加了结果
                if (hiddenConfigResults[taskKey]) {
                  return;
                }
                hiddenConfigResults[taskKey] = await listNamespacesTest(appId, env, namespaceName);
              } catch (e) {
                console.error(`获取隐藏配置失败 ${taskKey}:`, e);
                hiddenConfigResults[taskKey] = { configurations: {} };
              }
            })()
          );
          continue;
        }
        
        // 处理普通配置
        for (const it of items) {
          const k = it?.item?.key ?? it?.key;
          const isModified = it?.isModified || false;
          const isDeleted = it?.isDeleted || false;
          const v = isModified || isDeleted ? it?.oldValue : it?.item?.value;
          if (!k) continue;
          if (keyPrefix && !k.toLowerCase().includes(keyPrefix.toLowerCase())) continue;
          if (valueFilter && !String(v || '').toLowerCase().includes(valueFilter.toLowerCase())) continue;
          result.push({ appId, environment: env, namespace: namespaceName, key: k, value: v ?? '' });
        }
      }
    }
    
    // 等待黑名单检查完成
    if (blacklistCheckPromises.length > 0) {
      console.log(`检查 ${blacklistCheckPromises.length} 个配置是否在黑名单中...`);
      await Promise.all(blacklistCheckPromises);
      console.log('黑名单检查完成');
    }
    
    // 等待PROD配置服务请求完成
    if (prodConfigServerTasks.length > 0) {
      console.log(`从PROD配置服务获取 ${prodConfigServerTasks.length} 个namespace...`);
      await Promise.all(prodConfigServerTasks);
      console.log('PROD配置服务请求完成');
      
      // 统计失败的服务器
      if (failedServers.size > 0) {
        console.error(`🚫 PROD配置服务失败统计: ${failedServers.size} 个服务器不可用`);
        failedServers.forEach(server => {
          console.error(`   - ${server}`);
        });
      }
      
      // 处理PROD配置服务结果
      let successCount = 0;
      let failedCount = 0;
      
      for (const [taskKey, itemsResponse] of Object.entries(prodConfigServerResults)) {
        const [appId, env, namespaceName] = taskKey.split(':');
        const configurations = itemsResponse?.configurations || null;
        
        if (configurations && typeof configurations === 'object' && Object.keys(configurations).length > 0) {
          successCount++;
          const configEntries = Object.entries(configurations);
          for (const [k, v] of configEntries) {
            if (!k) continue;
            if (keyPrefix && !k.toLowerCase().includes(keyPrefix.toLowerCase())) continue;
            if (valueFilter && !String(v || '').toLowerCase().includes(valueFilter.toLowerCase())) continue;
            result.push({ appId, environment: env, namespace: namespaceName, key: k, value: v ?? '' });
          }
        } else {
          failedCount++;
        }
      }
      
      console.log(`PROD配置服务结果统计: 成功 ${successCount} 个, 失败/空 ${failedCount} 个`);
    }
    
    // 等待所有隐藏配置请求完成
    if (hiddenConfigTasks.length > 0) {
      console.log(`处理 ${hiddenConfigTasks.length} 个隐藏配置请求...`);
      await Promise.all(hiddenConfigTasks);
      console.log('隐藏配置请求完成');
      
      // 处理隐藏配置结果
      for (const [taskKey, itemsResponse] of Object.entries(hiddenConfigResults)) {
        const [appId, env, namespaceName] = taskKey.split(':');
        const configurations = itemsResponse?.configurations || null;
        
        if (configurations && typeof configurations === 'object') {
          const configEntries = Object.entries(configurations);
          for (const [k, v] of configEntries) {
            if (!k) continue;
            if (keyPrefix && !k.toLowerCase().includes(keyPrefix.toLowerCase())) continue;
            if (valueFilter && !String(v || '').toLowerCase().includes(valueFilter.toLowerCase())) continue;
            result.push({ appId, environment: env, namespace: namespaceName, key: k, value: v ?? '' });
          }
        }
      }
    }
    
    const processEndTime = Date.now();
    console.log(`处理namespaces完成，耗时: ${processEndTime - processStartTime}ms`);
    
    // 更新全局 namespaces 列表
    const newNamespaces = Array.from(foundNamespaces).sort();
    if (newNamespaces.length > 0) {
      namespaces = [...new Set([...namespaces, ...newNamespaces])].sort();
      console.log(`更新 namespaces 列表，共 ${namespaces.length} 个:`, namespaces.slice(0, 10));
    }
    
    console.log('fetchAllItems 完成, 结果数量:', result.length);
    return result;
  }

  // 初始化UI
  function initUI() {
    const panelId = 'apollo-helper-panel';
    if (document.getElementById(panelId)) return;

    // 创建样式
    const style = document.createElement('style');
    style.textContent = `
      #apollo-helper-panel {
        position: fixed;
        top: 0px;
        right: 20px;
        width: 900px;
        background: white;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 15px;
        z-index: 10000;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        max-height: 90vh;
        overflow-y: auto;
        transition: none;
        cursor: move;
      }
      
      #apollo-helper-panel .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
      }
      
      #apollo-helper-panel .header h3 {
        margin: 0;
        color: #1890ff;
        cursor: move;
      }
      
      #apollo-helper-panel .close-btn {
        cursor: pointer;
        font-size: 18px;
        color: #999;
      }
      
      #apollo-helper-panel .close-btn:hover {
        color: #666;
      }
      
      #apollo-helper-panel .resize-handle {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 5px;
        cursor: ew-resize;
        background: transparent;
      }
      
      #apollo-helper-panel .resize-handle:hover {
        background: rgba(24, 144, 255, 0.1);
      }
      
      #apollo-helper-panel label {
        display: block;
        margin-bottom: 5px;
      }
      
      #apollo-helper-panel input,
      #apollo-helper-panel select {
        width: 100%;
        padding: 5px;
        box-sizing: border-box;
        margin-bottom: 10px;
      }
      
      #apollo-key-dropdown,
      #apollo-value-dropdown {
        display: none;
        position: absolute;
        width: 100%;
        max-height: 200px;
        overflow-y: auto;
        background: white;
        border: 1px solid #ccc;
        border-top: none;
        z-index: 10001;
      }
      
      #apollo-key-dropdown div,
      #apollo-value-dropdown div {
        padding: 5px;
        cursor: pointer;
      }
      
      #apollo-key-dropdown div:hover,
      #apollo-value-dropdown div:hover {
        background: #f0f0f0;
      }
      
      #apollo-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
      }
      
      #apollo-table th,
      #apollo-table td {
        text-align: left;
        padding: 8px;
        border-bottom: 1px solid #e8e8e8;
        word-wrap: break-word;
        overflow: hidden;
      }
      
      #apollo-table td:nth-child(4),
      #apollo-table td:nth-child(5) {
        white-space: pre-wrap;
        word-break: break-all;
      }
      
      #apollo-table th {
        background: #fafafa;
      }
      
      #apollo-helper-toggle {
        position: fixed;
        top: 0px;
        right: 20px;
        background: #1890ff;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 8px 12px;
        cursor: move;
        z-index: 9999;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      }
      
      #apollo-helper-toggle:hover {
        background: #40a9ff;
      }
      
      .apollo-checkbox-container {
        display: flex;
        justify-content: center;
        margin-bottom: 15px;
        border: 1px solid #e8e8e8;
        border-radius: 4px;
        padding: 10px;
        background-color: #f9f9f9;
      }
      
      .apollo-checkbox-wrapper {
        display: flex;
        align-items: center;
        padding: 5px;
      }
      
      .apollo-checkbox-wrapper input[type="checkbox"] {
        width: 16px;
        height: 16px;
        margin: 0;
        margin-right: 8px;
        flex-shrink: 0;
      }
      
      .apollo-checkbox-wrapper label {
        display: inline-block !important;
        margin: 0 !important;
        font-size: 14px;
        white-space: nowrap;
        text-align: center;
      }
      
      .prod-config-collapse {
        margin-bottom: 15px;
        border: 1px solid #d9d9d9;
        border-radius: 4px;
        overflow: hidden;
      }
      
      .prod-config-collapse-header {
        padding: 10px 12px;
        background: #fafafa;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        user-select: none;
      }
      
      .prod-config-collapse-header:hover {
        background: #f0f0f0;
      }
      
      .prod-config-collapse-title {
        font-size: 13px;
        font-weight: 500;
        color: #666;
      }
      
      .prod-config-collapse-arrow {
        font-size: 12px;
        color: #999;
        transition: transform 0.3s;
      }
      
      .prod-config-collapse-arrow.expanded {
        transform: rotate(90deg);
      }
      
      .prod-config-collapse-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease;
        padding: 0 12px;
      }
      
      .prod-config-collapse-content.expanded {
        max-height: 500px;
        padding: 12px;
      }
      
      @media (max-width: 480px) {
        .apollo-checkbox-container {
          flex-direction: column;
        }
        
        .apollo-checkbox-wrapper:first-child {
          margin-right: 0;
          margin-bottom: 8px;
          border-right: none;
          border-bottom: 1px solid #e8e8e8;
          padding-bottom: 8px;
        }
      }
    `;
    document.head.appendChild(style);
    
    // 创建悬浮开关按钮
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'apollo-helper-toggle';
    toggleBtn.textContent = 'Apollo 助手';
    toggleBtn.style.display = 'block';
    document.body.appendChild(toggleBtn);
    
    // 创建面板
    const panel = document.createElement('div');
    panel.id = panelId;
    panel.style.display = 'none';
    panel.innerHTML = `
      <div class="resize-handle"></div>
      <div class="header">
        <h3>Apollo 配置搜索助手</h3>
        <span class="close-btn">&times;</span>
      </div>
      
      <!-- PROD配置服务地址（可折叠，置顶） -->
      <div class="prod-config-collapse">
        <div class="prod-config-collapse-header" id="prod-config-collapse-toggle">
          <span class="prod-config-collapse-title">🔧 PROD配置代理服务 <span style="font-size: 11px; color: #999;">(可选，用于获取items为空的配置)</span></span>
          <span class="prod-config-collapse-arrow">▶</span>
        </div>
        <div class="prod-config-collapse-content" id="prod-config-collapse-content">
          <div style="margin-bottom: 10px;">
            <label style="font-size: 12px; color: #666;">代理服务地址:</label>
            <div style="display: flex; gap: 10px; align-items: center; margin-top: 5px;">
              <div style="flex: 1;">
                <input id="apollo-prod-config-ip" type="text" placeholder="Pod IP 地址" style="width: 100%; padding: 5px; box-sizing: border-box;">
              </div>
              <div style="width: 15px; text-align: center; color: #999;">:</div>
              <div style="width: 100px;">
                <input id="apollo-prod-config-port" type="text" value="8000" placeholder="端口" style="width: 100%; padding: 5px; box-sizing: border-box;">
              </div>
            </div>
          </div>
          <div style="padding: 8px 10px; background: #fffbe6; border-left: 3px solid #faad14; border-radius: 3px; font-size: 12px; color: #666; margin-bottom: 8px;">
            <strong>使用步骤：</strong><br>
            ① 在 Pod 机器上执行下方命令<br>
            ② 将 Pod 的 IP 地址填入上方输入框
          </div>
          <button id="apollo-copy-proxy-script-btn" style="padding: 8px 12px; background: #1890ff; color: white; border: none; border-radius: 3px; cursor: pointer; font-size: 12px; width: 100%; font-weight: 500;">
            📋 一键复制部署命令
          </button>
        </div>
      </div>
      
      <!-- Owner选项已移除 -->
      
      <div>
        <label for="apollo-env-container">Environment: <span style="font-weight: normal; font-size: 12px; color: #999;">(可多选，PROD需要权限)</span></label>
        <div id="apollo-env-container" style="position: relative;">
          <div id="apollo-env-selected" style="border: 1px solid #ccc; padding: 5px; min-height: 30px; background: white; display: flex; flex-wrap: wrap; gap: 3px; align-items: center;">
            <input id="apollo-env-input" type="text" placeholder="点击选择环境" style="border: none; outline: none; flex: 1; min-width: 100px;">
          </div>
          <div id="apollo-env-dropdown" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #ccc; border-top: none; max-height: 150px; overflow-y: auto; z-index: 10001;">
            <div class="env-dropdown-item" data-env="ALL" style="padding: 8px; border-bottom: 1px solid #eee;">
              <div style="font-weight: bold;">ALL</div>
              <div style="font-size: 11px; color: #666;">所有环境 (需要对应权限)</div>
            </div>
            <div class="env-dropdown-item" data-env="DEV" style="padding: 8px; border-bottom: 1px solid #eee;">
              <div style="font-weight: bold;">DEV</div>
              <div style="font-size: 11px; color: #666;">开发环境 (无需特殊权限)</div>
            </div>
            <div class="env-dropdown-item" data-env="TEST" style="padding: 8px; border-bottom: 1px solid #eee;">
              <div style="font-weight: bold;">TEST</div>
              <div style="font-size: 11px; color: #666;">测试环境 (无需特殊权限)</div>
            </div>
            <div class="env-dropdown-item" data-env="PROD" style="padding: 8px;">
              <div style="font-weight: bold;">PROD</div>
              <div style="font-size: 11px; color: #666;">生产环境 (需要对应权限)</div>
            </div>
          </div>
        </div>
        <div style="margin-top: 3px; font-size: 12px; color: #999;">默认选择TEST和PROD环境，可根据需要调整</div>
      </div>
      
      <div>
        <label for="apollo-appid-input">AppId:</label>
        <div id="apollo-appid-container" style="position: relative;">
          <div id="apollo-appid-selected" style="border: 1px solid #ccc; padding: 5px; min-height: 30px; background: white; display: flex; flex-wrap: wrap; gap: 3px; align-items: center;">
            <input id="apollo-appid-input" type="text" placeholder="输入AppId按Enter添加" style="border: none; outline: none; flex: 1; min-width: 100px;">
          </div>
          <div id="apollo-appid-dropdown" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #ccc; border-top: none; max-height: 150px; overflow-y: auto; z-index: 10001;"></div>
        </div>
        <div style="margin-top: 3px; font-size: 12px; color: #999;">
          💡 不填写时，将搜索当前登录用户 Owner 下的所有应用
        </div>
      </div>
      
      <div>
        <label for="apollo-namespace-container">Namespace: <span style="font-weight: normal; font-size: 12px; color: #999;">(可多选)</span></label>
        <div id="apollo-namespace-container" style="position: relative;">
          <div id="apollo-namespace-selected" style="border: 1px solid #ccc; padding: 5px; min-height: 30px; background: white; display: flex; flex-wrap: wrap; gap: 3px; align-items: center;">
            <input id="apollo-namespace-input" type="text" placeholder="输入Namespace按Enter添加" style="border: none; outline: none; flex: 1; min-width: 100px;">
          </div>
          <div id="apollo-namespace-dropdown" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #ccc; border-top: none; max-height: 150px; overflow-y: auto; z-index: 10001;"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-key-input">Key 包含:</label>
        <div style="position: relative;">
          <input id="apollo-key-input" type="text" placeholder="输入 key 关键字 (可选)">
          <div id="apollo-key-dropdown"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-value-input">Value 包含:</label>
        <div style="position: relative;">
          <input id="apollo-value-input" type="text" placeholder="输入 value 关键字 (可选)">
          <div id="apollo-value-dropdown"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-ttl-select">缓存过期时间:</label>
        <select id="apollo-ttl-select">
          <option value="${TTL_1H}">1小时</option>
          <option value="${TTL_1D}">1天</option>
          <option value="${TTL_7D}" selected>7天</option>
          <option value="${TTL_30D}">30天</option>
        </select>
      </div>
      
      <div class="apollo-checkbox-container">
        <div class="apollo-checkbox-wrapper">
          <input id="apollo-force-chk" type="checkbox">
          <label for="apollo-force-chk">强制刷新</label>
        </div>
      </div>
      
      <div style="margin-bottom: 15px; display: flex; gap: 10px;">
        <button id="apollo-copy-btn" style="flex: 1; padding: 5px; background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; cursor: pointer;">复制键值对</button>
        <button id="apollo-search-btn" style="flex: 1; padding: 5px; background: #1890ff; color: white; border: none; border-radius: 3px; cursor: pointer;">搜索</button>
      </div>
      
      <div style="margin-bottom: 15px; display: flex; gap: 10px;">
        <button id="apollo-export-btn" style="flex: 1; padding: 5px; background: #52c41a; color: white; border: none; border-radius: 3px; cursor: pointer;">导出数据</button>
        <button id="apollo-clear-btn" style="flex: 1; padding: 5px; background: #f5f5f5; border: 1px solid #d9d9d9; border-radius: 3px; cursor: pointer;">清空</button>
      </div>
      
      <div id="apollo-results">
        <div id="apollo-loading" style="display: none; text-align: center; padding: 20px;">加载中...</div>
        <div id="apollo-error" style="display: none; color: red; padding: 10px;"></div>
        <div id="apollo-summary" style="margin: 10px 0;"></div>
        <table id="apollo-table" style="display: none;">
          <thead>
            <tr>
              <th style="width: 15%; max-width: 150px;">AppId</th>
              <th style="width: 8%; max-width: 80px;">Env</th>
              <th style="width: 15%; max-width: 120px;">Namespace</th>
              <th style="width: 30%; min-width: 200px;">Key</th>
              <th style="width: 32%; min-width: 250px;">Value</th>
            </tr>
          </thead>
          <tbody id="apollo-tbody"></tbody>
        </table>
      </div>
    `;
    
    document.body.appendChild(panel);
    
    // 获取元素引用
    // ownerInput已移除
    forceChk = document.getElementById('apollo-force-chk');
    copyBtn = document.getElementById('apollo-copy-btn');
    
    // 环境多选相关元素
    const envInput = document.getElementById('apollo-env-input');
    const envSelected = document.getElementById('apollo-env-selected');
    const envDropdown = document.getElementById('apollo-env-dropdown');
    envSelect = { input: envInput, selected: envSelected, dropdown: envDropdown };
    // AppId多选相关元素
    const appIdInput = document.getElementById('apollo-appid-input');
    const appIdSelected = document.getElementById('apollo-appid-selected');
    const appIdDropdown = document.getElementById('apollo-appid-dropdown');
    appIdSelect = { input: appIdInput, selected: appIdSelected, dropdown: appIdDropdown }; // 保持兼容性
    
    // Namespace多选相关元素
    const namespaceInput = document.getElementById('apollo-namespace-input');
    const namespaceSelected = document.getElementById('apollo-namespace-selected');
    const namespaceDropdown = document.getElementById('apollo-namespace-dropdown');
    namespaceSelect = { input: namespaceInput, selected: namespaceSelected, dropdown: namespaceDropdown };
    
    keyInput = document.getElementById('apollo-key-input');
    keyDropdown = document.getElementById('apollo-key-dropdown');
    valueInput = document.getElementById('apollo-value-input');
    valueDropdown = document.getElementById('apollo-value-dropdown');
    searchBtn = document.getElementById('apollo-search-btn');
    exportBtn = document.getElementById('apollo-export-btn');
    clearBtn = document.getElementById('apollo-clear-btn');
    tbody = document.getElementById('apollo-tbody');
    summary = document.getElementById('apollo-summary');
    ttlSelect = document.getElementById('apollo-ttl-select');
    prodConfigIpInput = document.getElementById('apollo-prod-config-ip');
    prodConfigPortInput = document.getElementById('apollo-prod-config-port');
    
    // Owner已移除，不再需要设置初始值
    
    // 处理关闭按钮
    const closeBtn = panel.querySelector('.close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        panel.style.display = 'none';
        toggleBtn.style.display = 'block';
      });
    }
    
    // PROD配置服务折叠/展开功能
    const prodCollapseToggle = document.getElementById('prod-config-collapse-toggle');
    const prodCollapseContent = document.getElementById('prod-config-collapse-content');
    const prodCollapseArrow = prodCollapseToggle ? prodCollapseToggle.querySelector('.prod-config-collapse-arrow') : null;
    
    if (prodCollapseToggle && prodCollapseContent && prodCollapseArrow) {
      prodCollapseToggle.addEventListener('click', () => {
        const isExpanded = prodCollapseContent.classList.contains('expanded');
        
        if (isExpanded) {
          // 收起
          prodCollapseContent.classList.remove('expanded');
          prodCollapseArrow.classList.remove('expanded');
        } else {
          // 展开
          prodCollapseContent.classList.add('expanded');
          prodCollapseArrow.classList.add('expanded');
        }
      });
    }
    
    // 处理开关按钮
    toggleBtn.addEventListener('click', (e) => {
      // 如果是拖动，不要触发显示面板
      if (isDraggingToggle) return;
      
      panel.style.display = 'block';
      toggleBtn.style.display = 'none';
    });
    
    // 添加面板拖动功能
    const header = panel.querySelector('.header');
    if (header) {
      header.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('close-btn')) return;
        
        isDragging = true;
        const rect = panel.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        
        panel.style.cursor = 'grabbing';
      });
      
      document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const x = e.clientX - dragOffsetX;
        const y = e.clientY - dragOffsetY;
        
        // 确保面板不会移出视口
        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        
        const boundedX = Math.max(0, Math.min(x, maxX));
        const boundedY = Math.max(0, Math.min(y, maxY));
        
        panel.style.left = `${boundedX}px`;
        panel.style.top = `${boundedY}px`;
        panel.style.right = 'auto';
        
        saveFormState();
      });
      
      document.addEventListener('mouseup', () => {
        if (isDragging) {
          isDragging = false;
          panel.style.cursor = 'move';
        }
      });
    }
    
    // 添加面板大小调整功能
    const resizeHandle = panel.querySelector('.resize-handle');
    if (resizeHandle) {
      resizeHandle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        isResizing = true;
        initialWidth = panel.offsetWidth;
        initialX = e.clientX;
        
        // 获取面板的初始左侧位置
        const rect = panel.getBoundingClientRect();
        initialPanelLeft = rect.left;
        
        document.body.style.cursor = 'ew-resize';
        panel.style.transition = 'none';
      });
      
      document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        
        // 计算鼠标移动的距离
        const deltaX = e.clientX - initialX;
        
        // 向左拖动(deltaX为负)时，面板宽度增加，同时左侧位置向左移动
        // 向右拖动(deltaX为正)时，面板宽度减少，同时左侧位置向右移动
        const newWidth = Math.max(500, initialWidth - deltaX);
        const newLeft = initialPanelLeft + deltaX;
        
        // 确保面板宽度不超过视口宽度的80%
        const maxWidth = window.innerWidth * 0.8;
        const boundedWidth = Math.min(newWidth, maxWidth);
        
        // 确保面板不会移出视口左侧
        const boundedLeft = Math.max(0, newLeft);
        
        panel.style.width = `${boundedWidth}px`;
        panel.style.left = `${boundedLeft}px`;
        panel.style.right = 'auto';
        
        saveFormState();
      });
      
      document.addEventListener('mouseup', () => {
        if (isResizing) {
          isResizing = false;
          document.body.style.cursor = '';
          
          // 保存面板大小
          saveFormState();
        }
      });
    }
    
    // 添加悬浮按钮拖动功能
    toggleBtn.addEventListener('mousedown', (e) => {
      e.preventDefault(); // 防止文本选择
      
      isDraggingToggle = true;
      const rect = toggleBtn.getBoundingClientRect();
      dragToggleOffsetX = e.clientX - rect.left;
      dragToggleOffsetY = e.clientY - rect.top;
      
      toggleBtn.style.cursor = 'grabbing';
      dragStartTime = Date.now();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDraggingToggle) return;
      
      const x = e.clientX - dragToggleOffsetX;
      const y = e.clientY - dragToggleOffsetY;
      
      // 确保按钮不会移出视口
      const maxX = window.innerWidth - toggleBtn.offsetWidth;
      const maxY = window.innerHeight - toggleBtn.offsetHeight;
      
      const boundedX = Math.max(0, Math.min(x, maxX));
      const boundedY = Math.max(0, Math.min(y, maxY));
      
      toggleBtn.style.left = `${boundedX}px`;
      toggleBtn.style.top = `${boundedY}px`;
      toggleBtn.style.right = 'auto';
      
      saveFormState();
    });
    
    document.addEventListener('mouseup', () => {
      if (isDraggingToggle) {
        isDraggingToggle = false;
        toggleBtn.style.cursor = 'move';
        
        // 如果拖动后立即释放，可能是点击意图
        if (Date.now() - dragStartTime < 200) {
          panel.style.display = 'block';
          toggleBtn.style.display = 'none';
        }
      }
    });
    
    // 设置事件监听
    setupEventListeners();
  }

  // 自动预加载数据
  async function preloadData() {
    const startTime = Date.now(); // 记录开始时间
    try {
      console.log('开始预加载数据...');
      
      // 使用默认Owner
      DEFAULT_OWNER = await getCurrentOwner();
      const owner = DEFAULT_OWNER;
      console.log(`使用Owner: ${owner}`);
      
      // 2. 加载appIds
      const appIdsStartTime = Date.now();
      await loadAppIdsByOwner(owner, { force: false });
      const appIdsEndTime = Date.now();
      console.log(`加载appIds完成，数量: ${appIds.length} (耗时: ${appIdsEndTime - appIdsStartTime}ms)`);
      
      // 3. 根据初始化状态确定要加载的AppId
      let targetAppIds = 'ALL';
      if (selectedAppIds.length > 0) {
        console.log('使用已选择的AppId进行预加载:', selectedAppIds);
        targetAppIds = selectedAppIds.join(',');
      } else {
        console.log('没有选择AppId，使用ALL进行预加载');
      }
      
      // 4. 预加载配置
      const configStartTime = Date.now();
      const result = await fetchAllItems(owner, selectedEnvs, "", targetAppIds, "", "");
      const configEndTime = Date.now();
      console.log(`预加载配置完成，数量: ${result.length} (耗时: ${configEndTime - configStartTime}ms)`);
      
      const totalTime = Date.now() - startTime;
      console.log(`🎉 预加载数据完成！总耗时: ${totalTime}ms (${(totalTime / 1000).toFixed(2)}秒)`);
      return result;
    } catch (error) {
      const totalTime = Date.now() - startTime;
      console.error(`❌ 预加载数据失败，耗时: ${totalTime}ms:`, error);
      return [];
    }
  }

  // 设置自动刷新
  function setupAutoRefresh() {
    // 清除之前的定时器
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
      autoRefreshTimer = null;
    }
    
    // 获取当前配置的过期时间
    const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
    
    // 设置新的定时器，过期时间的一半时刷新一次
    const refreshInterval = Math.max(ttlValue / 2 + 5000, TTL_1H); // 至少1小时刷新一次
    
    console.log(`设置自动刷新，间隔: ${refreshInterval}毫秒 (${refreshInterval / 3600000}小时)`);
    
    autoRefreshTimer = setTimeout(async () => {
      console.log('执行自动刷新...');
      
      // 如果面板可见，不执行自动刷新以避免干扰用户操作
      // const panel = document.getElementById('apollo-helper-panel');
      // if (panel && panel.style.display !== 'none') {
      //   console.log('面板可见，跳过自动刷新');
      //   setupAutoRefresh(); // 重新设置定时器
      //   return;
      // }
      
      // 执行预加载
      await preloadData();
      
      // 重新设置定时器
      setupAutoRefresh();
    }, refreshInterval);
  }

  // 监听过期时间变化
  function setupTTLChangeListener() {
    if (!ttlSelect) return;
    
    ttlSelect.addEventListener('change', () => {
      console.log('过期时间已更改，重新设置自动刷新');
      setupAutoRefresh();
    });
  }

  (async () => {
    console.log('Apollo 助手初始化...');
    await cache.init();
    await cache.cleanup();
    console.log('IndexedDB 初始化完成');
    
    // 初始化UI
    initUI();
    
    // Owner已移除，不再需要获取当前用户
    
    // 加载表单状态
    loadFormState();
    
    // 解析URL hash参数并自动选择（在加载表单状态之后，URL参数优先）
    parseUrlHashAndSelect();
    
    // 初始化AppId、环境和Namespace显示
    updateSelectedAppIdsDisplay();
    updateSelectedEnvsDisplay();
    updateSelectedNamespacesDisplay();
    
    // 监听hash变化，以便在URL变化时自动更新选择
    window.addEventListener('hashchange', () => {
      parseUrlHashAndSelect();
      updateSelectedAppIdsDisplay();
      updateSelectedEnvsDisplay();
    });
    
    // 设置过期时间变化监听
    setupTTLChangeListener();
    
    // 启动自动刷新
    setupAutoRefresh();
    
    // 预加载数据
    preloadData().then(result => {
      console.log('预加载完成，可用数据条数:', result.length);
    });
  })();

  // 初始化UI完成后的事件处理
  function setupEventListeners() {
    if (!searchBtn) return;
    
    // Owner已移除，不再需要加载
    
    // 复制键值对
    copyBtn.addEventListener('click', () => {
      copyKeyValuePairs();
    });
    
    // AppId多选功能事件监听
    appIdSelect.input.addEventListener('input', () => {
      showAppIdDropdown();
    });
    
    appIdSelect.input.addEventListener('focus', () => {
      showAppIdDropdown();
    });
    
    appIdSelect.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && appIdSelect.input.value.trim()) {
        e.preventDefault();
        addAppId(appIdSelect.input.value.trim());
      }
    });
    
    appIdSelect.selected.addEventListener('click', (e) => {
      if (e.target === appIdSelect.selected) {
        appIdSelect.input.focus();
      }
    });
    
    // 点击外部隐藏下拉框
    document.addEventListener('click', (e) => {
      if (!appIdSelect.selected.contains(e.target) && !appIdSelect.dropdown.contains(e.target)) {
        hideAppIdDropdown();
      }
    });
    
    // Key 输入框事件
    keyInput.addEventListener('input', () => {
      updateKeyDropdown(keyInput.value);
    });
    
    keyInput.addEventListener('focus', () => {
      updateKeyDropdown(keyInput.value);
    });
    
    keyInput.addEventListener('blur', () => {
      setTimeout(() => {
        hideKeyDropdown();
      }, 200);
    });
    
    // PROD配置服务IP和Port输入框事件 - 保存状态
    if (prodConfigIpInput) {
      prodConfigIpInput.addEventListener('input', saveFormState);
      prodConfigIpInput.addEventListener('blur', saveFormState);
    }
    if (prodConfigPortInput) {
      prodConfigPortInput.addEventListener('input', saveFormState);
      prodConfigPortInput.addEventListener('blur', saveFormState);
    }
    
    // Value 输入框事件
    valueInput.addEventListener('input', () => {
      updateValueDropdown(valueInput.value);
    });
    
    valueInput.addEventListener('focus', () => {
      updateValueDropdown(valueInput.value);
    });
    
    valueInput.addEventListener('blur', () => {
      setTimeout(() => {
        hideValueDropdown();
      }, 200);
    });
    
    // 环境多选事件监听
    setupEnvEvents();
    
    // Namespace多选功能事件监听
    namespaceSelect.input.addEventListener('input', () => {
      showNamespaceDropdown();
    });
    
    namespaceSelect.input.addEventListener('focus', () => {
      showNamespaceDropdown();
    });
    
    namespaceSelect.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && namespaceSelect.input.value.trim()) {
        e.preventDefault();
        addNamespace(namespaceSelect.input.value.trim());
      }
    });
    
    namespaceSelect.selected.addEventListener('click', (e) => {
      if (e.target === namespaceSelect.selected) {
        namespaceSelect.input.focus();
      }
    });
    
    // 点击外部隐藏下拉框
    document.addEventListener('click', (e) => {
      if (!namespaceSelect.selected.contains(e.target) && !namespaceSelect.dropdown.contains(e.target)) {
        hideNamespaceDropdown();
      }
    });

    // 添加按Enter键触发搜索的功能
    const handleEnterKey = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchBtn.click();
      }
    };
    
    // 为各个输入框添加Enter键监听
    keyInput.addEventListener('keydown', handleEnterKey);
    valueInput.addEventListener('keydown', handleEnterKey);
    // namespace 的 Enter 键监听已在上面的多选功能中添加
    
    // 复制代理脚本部署命令按钮事件
    const copyProxyScriptBtn = document.getElementById('apollo-copy-proxy-script-btn');
    if (copyProxyScriptBtn) {
      copyProxyScriptBtn.addEventListener('click', () => {
        const scriptUrl = 'http://genshuixue-public.oss-cn-beijing.aliyuncs.com/origin_test/2026-02-09/70765e8eadc28708743c61556e0bc0f2/%E7%AE%80%E5%8D%95%E4%BB%A3%E7%90%86%E8%AF%B7%E6%B1%82%E8%BD%AC%E5%8F%91.py';
        
        // 一键部署命令（下载并运行）
        const deployCommand = `curl -o proxy.py "${scriptUrl}" && python proxy.py`;

        // 复制到剪贴板
        if (navigator.clipboard && window.isSecureContext) {
          navigator.clipboard.writeText(deployCommand).then(() => {
            // 显示成功提示
            const originalText = copyProxyScriptBtn.textContent;
            copyProxyScriptBtn.textContent = '✅ 已复制命令';
            copyProxyScriptBtn.style.background = '#52c41a';
            
            setTimeout(() => {
              copyProxyScriptBtn.textContent = originalText;
              copyProxyScriptBtn.style.background = '#1890ff';
            }, 2000);
          }).catch(err => {
            console.error('复制失败:', err);
            alert('复制失败，请手动复制命令:\n' + deployCommand);
          });
        } else {
          // 降级方案
          const textArea = document.createElement('textarea');
          textArea.value = deployCommand;
          textArea.style.position = 'fixed';
          textArea.style.left = '-999999px';
          textArea.style.top = '-999999px';
          document.body.appendChild(textArea);
          textArea.focus();
          textArea.select();
          
          try {
            document.execCommand('copy');
            const originalText = copyProxyScriptBtn.textContent;
            copyProxyScriptBtn.textContent = '✅ 已复制命令';
            copyProxyScriptBtn.style.background = '#52c41a';
            
            setTimeout(() => {
              copyProxyScriptBtn.textContent = originalText;
              copyProxyScriptBtn.style.background = '#1890ff';
            }, 2000);
          } catch (err) {
            alert('复制失败，请手动复制命令:\n' + deployCommand);
          } finally {
            document.body.removeChild(textArea);
          }
        }
      });
    }
    
    // 搜索按钮事件
    searchBtn.addEventListener('click', async () => {
      const owner = DEFAULT_OWNER; // 使用默认Owner
      // 环境使用多选值
      const keyPrefix = keyInput.value.trim();
      const appIdValue = selectedAppIds.length > 0 ? selectedAppIds.join(',') : 'ALL';
      const valueFilter = valueInput.value.trim();
      const namespaceValue = selectedNamespaces.length > 0 ? selectedNamespaces.join(',') : 'ALL';
      const ttlValue = parseInt(ttlSelect.value, 10);
      
      // 保存表单状态
      saveFormState();
      
      const loadingDiv = document.getElementById('apollo-loading');
      const tableEl = document.getElementById('apollo-table');
      const errorDiv = document.getElementById('apollo-error');
      
      if (loadingDiv) loadingDiv.style.display = 'block';
      if (tableEl) tableEl.style.display = 'none';
      if (errorDiv) errorDiv.style.display = 'none';
      
      try {
        // 构建环境字符串用于缓存key
        const envKey = selectedEnvs.length > 0 ? selectedEnvs.sort().join('-') : 'ALL';
        
        // 使用缓存
        const namespaceKey = selectedNamespaces.length > 0 ? selectedNamespaces.sort().join('-') : 'ALL';
        const cacheKey = `apollo_helper_rows_${owner}_${envKey}_${appIdValue}_${keyPrefix}_${valueFilter}_${namespaceKey}`;
        let rows = null;
        
        if (!forceChk.checked) {
          rows = await cacheGet(cacheKey);
        }
        
        if (!rows) {
          console.log(`获取新数据: ${cacheKey}`);
          
          // 确保appIds已加载
          if (appIds.length === 0) {
            console.log('先加载appIds...');
            await loadAppIdsByOwner(owner);
            console.log('appIds加载完成, 长度:', appIds.length);
          }
          
          // 获取数据
          rows = await fetchAllItems(owner, selectedEnvs, keyPrefix, appIdValue, valueFilter, namespaceValue);
  
          // 设置缓存
          await cacheSet(cacheKey, rows, ttlValue);
          console.log(`缓存已设置: ${cacheKey}, 数量: ${rows.length}, 过期时间: ${ttlValue}ms (${(ttlValue / (24*60*60*1000)).toFixed(1)}天)`);
        } else {
          console.log(`使用缓存数据: ${cacheKey}`, rows.length);
        }
        
        // 渲染结果
        renderRows(rows);
        
      } catch (error) {
        console.error('搜索失败:', error);
        if (errorDiv) {
          errorDiv.textContent = `搜索失败: ${error.message}`;
          errorDiv.style.display = 'block';
        }
        if (loadingDiv) loadingDiv.style.display = 'none';
      }
    });

    // 导出按钮事件处理
    exportBtn.addEventListener('click', () => {
      if (!tbody) return;
      
      // 收集表格数据 - 使用 data-original 属性获取完整内容
      const rows = [];
      const trs = tbody.querySelectorAll('tr');
      
      for (const tr of trs) {
        const cells = tr.querySelectorAll('td');
        const row = {
          appId: cells[0].getAttribute('data-original') || cells[0].textContent,
          environment: cells[1].getAttribute('data-original') || cells[1].textContent,
          namespace: cells[2].getAttribute('data-original') || cells[2].textContent,
          key: cells[3].getAttribute('data-original') || cells[3].textContent,
          value: cells[4].getAttribute('data-original') || cells[4].textContent
        };
        rows.push(row);
      }
      
      if (rows.length === 0) {
        alert('没有数据可导出');
        return;
      }
      
      // 显示格式选择对话框
      showExportFormatDialog(rows);
    });
    
    // 清空按钮事件处理
    clearBtn.addEventListener('click', () => {
      // 清空 Namespace、Key 和 Value 输入框的内容
      selectedNamespaces = [];
      updateSelectedNamespacesDisplay();
      if (keyInput) keyInput.value = '';
      if (valueInput) valueInput.value = '';
      
      // 隐藏下拉框
      hideNamespaceDropdown();
      hideKeyDropdown();
      hideValueDropdown();
      
      // 保存表单状态
      saveFormState();
      
      console.log('已清空 Namespace、Key 和 Value 输入框');
    });
    
    // 添加点击页面外部收起面板的功能
    document.addEventListener('click', (e) => {
      const panel = document.getElementById('apollo-helper-panel');
      const toggleBtn = document.getElementById('apollo-helper-toggle');
      
      // 如果面板存在且显示中，且点击不在面板内，也不是面板的调整手柄，也不是切换按钮
      if (panel && 
          panel.style.display !== 'none' && 
          !panel.contains(e.target) && 
          e.target !== toggleBtn &&
          !toggleBtn.contains(e.target) &&
          !isResizing && 
          !isDragging) {
        
        // 收起面板
        panel.style.display = 'none';
        toggleBtn.style.display = 'block';
        
        console.log('点击页面外部，收起面板');
      }
    }, true); // 使用捕获阶段，确保在其他点击事件之前处理
  }
})();