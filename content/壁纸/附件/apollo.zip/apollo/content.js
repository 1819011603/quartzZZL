(function() {
  const OWNER = 'zhangzeling';
  const BASE = 'https://apollo-portal.baijia.com';

  const panelId = 'apollo-helper-panel';
  if (document.getElementById(panelId)) return;

  const style = document.createElement('style');
  style.textContent = `
    #apollo-helper-panel {
      position: fixed;
      top: 0px;
      right: 20px;
      width: 600px;
      background: white;
      border: 1px solid #ccc;
      border-radius: 5px;
      padding: 15px;
      z-index: 10000;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
      max-height: 90vh;
      overflow-y: auto;
      transition: width 0.3s ease;
      cursor: move;
    }
    
    #apollo-helper-panel .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    
    #apollo-helper-panel .header h3 {
      margin: 0;
      color: #1890ff;
      cursor: move;
    }
    
    #apollo-helper-panel .close-btn {
      cursor: pointer;
      font-size: 18px;
      color: #999;
    }
    
    #apollo-helper-panel .close-btn:hover {
      color: #666;
    }
    
    #apollo-helper-panel label {
      display: block;
      margin-bottom: 5px;
    }
    
    #apollo-helper-panel input,
    #apollo-helper-panel select {
      width: 100%;
      padding: 5px;
      box-sizing: border-box;
      margin-bottom: 10px;
    }
    
    #apollo-key-dropdown,
    #apollo-value-dropdown {
      display: none;
      position: absolute;
      width: 100%;
      max-height: 200px;
      overflow-y: auto;
      background: white;
      border: 1px solid #ccc;
      border-top: none;
      z-index: 10001;
    }
    
    #apollo-key-dropdown div,
    #apollo-value-dropdown div {
      padding: 5px;
      cursor: pointer;
    }
    
    #apollo-key-dropdown div:hover,
    #apollo-value-dropdown div:hover {
      background: #f0f0f0;
    }
    
    #apollo-table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }
    
    #apollo-table th,
    #apollo-table td {
      text-align: left;
      padding: 8px;
      border-bottom: 1px solid #e8e8e8;
    }
    
    #apollo-table th {
      background: #fafafa;
    }
    
    #apollo-helper-toggle {
      position: fixed;
      top: 0px;
      right: 20px;
      background: #1890ff;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px 12px;
      cursor: move;
      z-index: 9999;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    }
    
    #apollo-helper-toggle:hover {
      background: #40a9ff;
    }
    
    .apollo-checkbox-container {
      display: flex;
      justify-content: center;
      margin-bottom: 15px;
      border: 1px solid #e8e8e8;
      border-radius: 4px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    
    .apollo-checkbox-wrapper {
      display: flex;
      align-items: center;
      padding: 5px;
    }
    
    .apollo-checkbox-wrapper input[type="checkbox"] {
      width: 16px;
      height: 16px;
      margin: 0;
      margin-right: 8px;
      flex-shrink: 0;
    }
    
    .apollo-checkbox-wrapper label {
      display: inline-block !important;
      margin: 0 !important;
      font-size: 14px;
      white-space: nowrap;
      text-align: center;
    }
    
    @media (max-width: 480px) {
      .apollo-checkbox-container {
        flex-direction: column;
      }
      
      .apollo-checkbox-wrapper:first-child {
        margin-right: 0;
        margin-bottom: 8px;
        border-right: none;
        border-bottom: 1px solid #e8e8e8;
        padding-bottom: 8px;
      }
    }
  `;
  document.head.appendChild(style);

  // 缓存过期时间常量
  const TTL_1H = 60 * 60 * 1000; // 1小时
  const TTL_1D = 24 * TTL_1H;    // 1天
  const TTL_7D = 7 * TTL_1D;     // 7天
  const TTL_30D = 30 * TTL_1D;   // 30天
  const TTL_1Y = 365 * TTL_1D;   // 1年

  // IndexedDB 缓存管理器
  class IndexedDBCache {
    constructor() {
      this.dbName = 'ApolloHelperCache';
      this.version = 1;
      this.storeName = 'cache';
      this.db = null;
    }

    async init() {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(this.dbName, this.version);
        
        request.onerror = () => reject(request.error);
        request.onsuccess = () => {
          this.db = request.result;
          resolve(this.db);
        };
        
        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains(this.storeName)) {
            const store = db.createObjectStore(this.storeName, { keyPath: 'key' });
            store.createIndex('expiresAt', 'expiresAt', { unique: false });
          }
        };
      });
    }

    async get(key) {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readonly');
        const store = transaction.objectStore(this.storeName);
        const request = store.get(key);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => {
            const result = request.result;
            if (!result) {
              resolve(null);
              return;
            }
            
            // 检查过期时间
            if (result.expiresAt && Date.now() > result.expiresAt) {
              this.delete(key); // 异步删除过期项
              resolve(null);
              return;
            }
            
            resolve(result.value);
          };
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB get 错误:', e);
        return null;
      }
    }

    async set(key, value, ttlMs = null) {
      try {
        if (!this.db) await this.init();
        
        const data = {
          key,
          value,
          createdAt: Date.now(),
          expiresAt: ttlMs ? Date.now() + ttlMs : null
        };
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const request = store.put(data);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => resolve(true);
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB set 错误:', e);
        return false;
      }
    }

    async delete(key) {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const request = store.delete(key);
        
        return new Promise((resolve, reject) => {
          request.onsuccess = () => resolve(true);
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB delete 错误:', e);
        return false;
      }
    }

    async cleanup() {
      try {
        if (!this.db) await this.init();
        
        const transaction = this.db.transaction([this.storeName], 'readwrite');
        const store = transaction.objectStore(this.storeName);
        const index = store.index('expiresAt');
        const now = Date.now();
        
        const request = index.openCursor();
        let cleaned = 0;
        
        return new Promise((resolve, reject) => {
          request.onsuccess = (event) => {
            const cursor = event.target.result;
            if (cursor) {
              const data = cursor.value;
              if (data.expiresAt && now > data.expiresAt) {
                cursor.delete();
                cleaned++;
              }
              cursor.continue();
            } else {
              console.log('IndexedDB 清理完成，删除', cleaned, '个过期项');
              resolve(cleaned);
            }
          };
          request.onerror = () => reject(request.error);
        });
      } catch (e) {
        console.error('IndexedDB cleanup 错误:', e);
        return 0;
      }
    }
  }

  // 创建缓存实例
  const cache = new IndexedDBCache();

  // 兼容接口
  async function cacheGet(key) {
    const result = await cache.get(key);
    return result;
  }

  async function cacheSet(key, value, ttlMs) {
    const success = await cache.set(key, value, ttlMs);
    return success;
  }

  // 全局变量定义
  let appIds = [];
  // let selectedAppIds = ['reach-service','crm-app-service.gaotu100.com','fairy.gaotu100.com','linkup.gaotu100.com','student-center','student-data','teacher-basic.gaotu100.com','service-copilot','teacher-tool']; // 已选择的AppId列表
  let selectedAppIds = []; // 已选择的AppId列表
  let selectedEnvs = ['TEST', 'PROD']; // 已选择的环境列表，默认TEST和PROD
  
  // Fisher-Yates 洗牌算法，用于随机打乱数组
  function shuffleArray(array) {
    const result = [...array]; // 创建数组副本，不修改原数组
    for (let i = result.length - 1; i > 0; i--) {
      // 随机选择一个位置
      const j = Math.floor(Math.random() * (i + 1));
      // 交换元素
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }

  let keyPool = [];
  let valuePool = [];
  let isLoadingAppIds = false;
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let isDraggingToggle = false;
  let dragToggleOffsetX = 0;
  let dragToggleOffsetY = 0;
  let dragStartTime = 0;
  let isResizing = false;
  let initialWidth = 0;
  let initialX = 0;
  let initialPanelLeft = 0;
  let autoRefreshTimer = null; // 自动刷新定时器
  let isLoginPageOpened = false; // 防止多次打开登录页面的标识

    // DOM元素引用
  let ownerInput;
  let forceChk;
  let copyBtn;
  let envSelect;
  let appIdSelect;
  let keyInput;
  let keyDropdown;
  let valueInput;
  let valueDropdown;
  let searchBtn;
  let exportBtn;
  let clearBtn;
  let tbody;
  let summary;
  let namespaceInput;
  let ttlSelect;

  // 面板拖动相关变量
  // 保存表单状态
  function saveFormState() {
    if (!ownerInput) return;
    
    const panel = document.getElementById('apollo-helper-panel');
    const toggle = document.getElementById('apollo-helper-toggle');
    
    const state = {
      owner: ownerInput.value,
      envs: selectedEnvs.length > 0 ? selectedEnvs : ['ALL'], // 保存选中的环境数组
      appId: selectedAppIds.length > 0 ? selectedAppIds : ['ALL'], // 保存选中的AppId数组
      keyPrefix: keyInput.value,
      valueFilter: valueInput.value,
      namespace: namespaceInput.value,
      ttl: ttlSelect.value,
      // 添加面板位置和大小保存
      panelPosition: {
        left: panel.style.left,
        top: panel.style.top,
        right: panel.style.right,
        width: panel.style.width
      },
      // 添加按钮位置保存
      togglePosition: {
        left: toggle.style.left,
        top: toggle.style.top,
        right: toggle.style.right
      }
    };
    
    localStorage.setItem('apollo_helper_form_state', JSON.stringify(state));
  }

  // 加载表单状态
  function loadFormState() {
    if (!ownerInput) return;
    
    const stateJson = localStorage.getItem('apollo_helper_form_state');
    if (!stateJson) return;
    
    try {
      const state = JSON.parse(stateJson);
      
      if (state.owner) ownerInput.value = state.owner;
      if (state.envs && Array.isArray(state.envs)) {
        selectedEnvs = state.envs.filter(env => env !== 'ALL'); // 加载选中的环境
      }
      if (state.appId && Array.isArray(state.appId)) {
        selectedAppIds = state.appId.filter(id => id !== 'ALL'); // 加载选中的AppId
      }
      if (state.keyPrefix) keyInput.value = state.keyPrefix;
      if (state.valueFilter) valueInput.value = state.valueFilter;
      if (state.namespace) namespaceInput.value = state.namespace;
      if (state.ttl) ttlSelect.value = state.ttl;
      
      // 恢复面板位置和大小
      if (state.panelPosition) {
        const panel = document.getElementById('apollo-helper-panel');
        if (panel) {
          if (state.panelPosition.left) panel.style.left = state.panelPosition.left;
          if (state.panelPosition.top) panel.style.top = state.panelPosition.top;
          if (state.panelPosition.right) panel.style.right = state.panelPosition.right;
          if (state.panelPosition.width) panel.style.width = state.panelPosition.width;
        }
      }
      
      // 恢复按钮位置
      if (state.togglePosition) {
        const toggle = document.getElementById('apollo-helper-toggle');
        if (toggle) {
          if (state.togglePosition.left) toggle.style.left = state.togglePosition.left;
          if (state.togglePosition.top) toggle.style.top = state.togglePosition.top;
          if (state.togglePosition.right) toggle.style.right = state.togglePosition.right;
        }
      }
    } catch (e) {
      console.error('加载表单状态失败:', e);
    }
  }

  function updateKeyDropdown(prefix) {
    if (!keyInput || !keyDropdown) return;
    keyDropdown.innerHTML = '';
    const lower = (prefix || '').toLowerCase();
    const unique = Array.from(new Set(keyPool));
    const filtered = unique.filter(k => !lower || k.toLowerCase().startsWith(lower)).slice(0, 20);
    
    if (filtered.length === 0) {
      keyDropdown.classList.remove('show');
      return;
    }

    for (const k of filtered) {
      const item = document.createElement('div');
      item.className = 'key-dropdown-item';
      item.textContent = k;
      item.addEventListener('click', () => {
        keyInput.value = k;
        keyDropdown.classList.remove('show');
        saveFormState();
      });
      keyDropdown.appendChild(item);
    }
    keyDropdown.classList.add('show');
  }

  function hideKeyDropdown() {
    if (!keyDropdown) return;
    keyDropdown.classList.remove('show');
  }

  function updateValueDropdown(text) {
    if (!valueInput || !valueDropdown) return;
    valueDropdown.innerHTML = '';
    const lower = (text || '').toLowerCase();
    const unique = Array.from(new Set(valuePool));
    const filtered = unique.filter(v => !lower || v.toLowerCase().includes(lower)).slice(0, 20);
    
    if (filtered.length === 0) {
      valueDropdown.classList.remove('show');
      return;
    }

    for (const v of filtered) {
      const item = document.createElement('div');
      item.className = 'value-dropdown-item';
      item.textContent = v;
      item.addEventListener('click', () => {
        valueInput.value = v;
        valueDropdown.classList.remove('show');
        saveFormState();
      });
      valueDropdown.appendChild(item);
    }
    valueDropdown.classList.add('show');
  }

  function hideValueDropdown() {
    if (!valueDropdown) return;
    valueDropdown.classList.remove('show');
  }

  function downloadText(filename, text) {
    const blob = new Blob([text], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // 渲染结果行
  function renderRows(rows) {
    if (!tbody) return;
    
    const tableEl = document.getElementById('apollo-table');
    const loadingDiv = document.getElementById('apollo-loading');
    const summaryEl = document.getElementById('apollo-summary');
    
    tbody.innerHTML = '';
    
    if (rows.length === 0) {
      if (summaryEl) summaryEl.textContent = '没有找到匹配的配置';
      if (loadingDiv) loadingDiv.style.display = 'none';
      return;
    }
    
    // 创建一个文档片段，提高性能
    const fragment = document.createDocumentFragment();
    
    for (const row of rows) {
      const tr = document.createElement('tr');
      
      // 创建一个简单的文本复制函数
      const createCopyableCell = (text, maxWidth, isWordBreak = false) => {
        const td = document.createElement('td');
        
        // 添加文本内容
        td.textContent = text || '';
        
        // 设置样式
        td.style.maxWidth = maxWidth || 'auto';
        td.style.overflow = 'hidden';
        td.style.textOverflow = 'ellipsis';
        td.style.whiteSpace = isWordBreak ? 'normal' : 'nowrap';
        if (isWordBreak) {
          td.style.wordBreak = 'break-word';
        }
        
        // 添加title属性，方便查看完整内容
        td.title = text || '';
        
        // 添加双击复制功能
        td.addEventListener('dblclick', () => {
          // 获取完整的原始数据（如果存在）
          const originalData = td.getAttribute('data-original') || text || '';
          
          // 创建一个临时textarea用于复制
          const textarea = document.createElement('textarea');
          textarea.value = originalData;
          textarea.style.position = 'absolute';
          textarea.style.left = '-9999px';
          document.body.appendChild(textarea);
          textarea.select();
          document.execCommand('copy');
          document.body.removeChild(textarea);
          
          // 创建提示元素
          const tooltip = document.createElement('div');
          const isTruncated = originalData.length > 50;
          tooltip.textContent = isTruncated ? 
            `已复制完整内容 (${originalData.length} 字符)` : 
            '已复制';
          tooltip.style.cssText = `
            position: fixed;
            background: rgba(0, 0, 0, 0.7);
            color: white;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 12px;
            z-index: 10002;
            pointer-events: none;
            transition: opacity 0.3s;
          `;
          
          // 定位提示元素在单元格附近
          const rect = td.getBoundingClientRect();
          tooltip.style.top = `${rect.bottom + 5}px`;
          tooltip.style.left = `${rect.left + rect.width / 2}px`;
          tooltip.style.transform = 'translateX(-50%)';
          
          document.body.appendChild(tooltip);
          
          // 提供复制成功的视觉反馈
          const originalBackground = td.style.backgroundColor;
          td.style.backgroundColor = '#e6f7ff';
          
          // 2秒后移除提示和恢复背景色
          setTimeout(() => {
            tooltip.style.opacity = '0';
            setTimeout(() => document.body.removeChild(tooltip), 300);
            td.style.backgroundColor = originalBackground;
          }, 2000);
        });
        
        return td;
      };
      
              // 使用创建的函数添加单元格
        // AppId、Env、Namespace 显示全部内容
    const appIdCell = createCopyableCell(row.appId, 'auto');
    appIdCell.setAttribute('data-original', row.appId);
    tr.appendChild(appIdCell);
    
    const envCell = createCopyableCell(row.environment, 'auto');
    envCell.setAttribute('data-original', row.environment);
    tr.appendChild(envCell);
    
    const namespaceCell = createCopyableCell(row.namespace, 'auto');
    namespaceCell.setAttribute('data-original', row.namespace);
    tr.appendChild(namespaceCell);
    
    // Key 显示全部内容
    const keyCell = createCopyableCell(row.key, 'auto');
    keyCell.setAttribute('data-original', row.key); // 存储完整的原始数据
    tr.appendChild(keyCell);
    
    // Value 最多50个字符，超出显示省略号
    const displayValue = row.value.length > 50 ? row.value.substring(0, 50) + '...' : row.value;
    const valueCell = createCopyableCell(displayValue, '300px', true);
    valueCell.setAttribute('data-original', row.value); // 存储完整的原始数据
    valueCell.title = row.value; // 完整内容显示在title中
    tr.appendChild(valueCell);
      
      fragment.appendChild(tr);
    }
    
    tbody.appendChild(fragment);
    
    if (summaryEl) summaryEl.textContent = `共找到 ${rows.length} 条配置`;
    if (loadingDiv) loadingDiv.style.display = 'none';
    if (tableEl) tableEl.style.display = 'table';
  }

  // 添加导出CSV的改进函数
  function toCsv(items) {
    const header = ['AppId','Environment','Namespace','Key','Value'];
    const lines = [];
    
    // 添加标题行
    lines.push(header.join(','));
    
    // 添加数据行
    for (const item of items) {
      const values = header.map(h => {
        const fieldName = h.charAt(0).toLowerCase() + h.slice(1);
        let value = item[fieldName] || '';
        
        // 处理包含逗号、换行符或双引号的值
        if (typeof value === 'string' && (value.includes(',') || value.includes('\n') || value.includes('"'))) {
          // 替换双引号为两个双引号（CSV标准）
          value = value.replace(/"/g, '""');
          // 用双引号包裹整个值
          value = `"${value}"`;
        }
        
        return value;
      });
      
      lines.push(values.join(','));
    }
    
    return lines.join('\n');
  }

  async function safeFetchJson(url) {
    const res = await fetch(url, { credentials: 'include' });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
    const data = await res.json();
    
    // 处理特殊状态码
    if (data && data.code === 700 && data.location) {
      console.log('收到重定向请求，code=700，location=', data.location);
      
      // 只在第一次遇到重定向时打开登录页面
      if (!isLoginPageOpened) {
        isLoginPageOpened = true;
        // window.open(data.location, '_blank');
        console.log('已打开登录页面，后续重定向请求将被忽略');
        
        // 设置一个定时器，30秒后重置标识，允许再次打开登录页面
        setTimeout(() => {
          isLoginPageOpened = false;
          console.log('登录页面打开标识已重置');
        }, 30000);
      } else {
        console.log('登录页面已打开，跳过重复打开');
      }
      
      // 抛出错误，中断当前操作
      throw new Error('需要重新登录，已在新标签页打开登录页面');
    }
    
    return data;
  }

  async function getCurrentOwner() {
    const cacheKey = 'apollo_helper_current_user';
    const cached = await cacheGet(cacheKey);
    if (cached) return cached;
    try {
      const data = await safeFetchJson(`${BASE}/user`);
      const id = data?.userId || data?.username || data?.name || data?.loginName;
      if (id) {
        await cacheSet(cacheKey, id);
        return id;
      }
    } catch {}
    return null; 
  }

  async function loadAppIdsByOwner(owner, opts = { force: false }) {
    console.log('loadAppIdsByOwner 开始执行, owner:', owner, 'force:', opts.force);
    const cacheKey = `apollo_helper_appids_${owner}`;
    
    if (!opts.force) {
      const cached = await cacheGet(cacheKey);
      if (Array.isArray(cached) && cached.length > 0) {
        console.log('从缓存加载 appIds, 数量:', cached.length);
        appIds = cached; // 确保从缓存加载时也设置全局变量
        return shuffleArray(cached);
      }
    }
    
    console.log('从服务器加载 appIds...');
    const pageSize = 500;
    let page = 0;
    const ids = [];
    
    try {
      while (true) {
        const url = `${BASE}/apps/by-owner?owner=${encodeURIComponent(owner)}&page=${page}&size=${pageSize}`;
        console.log('请求URL:', url);
        
        const data = await safeFetchJson(url);
        let batch = [];
        
        if (Array.isArray(data)) {
          batch = data;
          console.log('数据是数组, 长度:', data.length);
        } else if (Array.isArray(data?.content)) {
          batch = data.content;
          console.log('数据是分页对象, 内容长度:', data.content.length);
        } else if (Array.isArray(data?.data)) {
          batch = data.data;
          console.log('数据包含data字段, 长度:', data.data.length);
        } else {
          console.log('未找到有效数据结构:', data);
          break;
        }
        
        for (const app of batch) {
          if (app?.appId) ids.push(app.appId);
        }
        
        if (Array.isArray(data)) break;
        if (data.last === true || batch.length === 0) break;
        
        page += 1;
        if (page > 100) {
          console.warn('达到最大页数限制 (100)');
          break;
        }
      }
      
      const unique = shuffleArray(Array.from(new Set(ids)));
      console.log('获取到的唯一appIds数量:', unique.length);
      
      // 设置全局变量
      appIds = unique;
      
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      
      // 缓存结果
      await cacheSet(cacheKey, unique, ttlValue);
      console.log(`appIds已缓存, key: ${cacheKey}, 过期时间: ${ttlValue}ms (${(ttlValue / (24*60*60*1000)).toFixed(1)}天)`);
      
      return unique;
    } catch (e) {
      console.error('加载appIds失败:', e);
      // 出错时返回空数组，但不缓存
      return [];
    }
  }

  async function listNamespaces(appId, env) {
    const cacheKey = `apollo_helper_ns_${appId}_${env}`;
    const cached = await cacheGet(cacheKey);
    if (!forceChk.checked && Array.isArray(cached)) return cached;
    const url = `${BASE}/apps/${encodeURIComponent(appId)}/envs/${encodeURIComponent(env)}/clusters/default/namespaces?debug=`;
    const data = await safeFetchJson(url);
    if (Array.isArray(data)) {
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      await cacheSet(cacheKey, data, ttlValue);
    }
    return data;
  }

  async function listNamespacesTest(appId, env, namespace) {
    const cacheKey = `apollo_helper_test_ns_${appId}_${env}_${namespace}`;
    const cached = await cacheGet(cacheKey);
    if (!forceChk.checked && cached) return cached;
    
    console.log(`正在请求 ${env}-apollo-meta 配置: ${appId}/${namespace}`);
    const url = `https://${env.toLowerCase()}-apollo-meta.baijia.com/configs/${appId}/${env}/${namespace}`;
    
    try {
      console.log(`发送消息到 background script: ${url}`);
      const response = await new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          reject(new Error('请求超时（15秒）'));
        }, 15000);
        
        chrome.runtime.sendMessage({
          action: 'fetchWithCORS',
          url: url,
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          }
        }, (response) => {
          clearTimeout(timeoutId);
          console.log('收到 background 响应:', response);
          
          if (!response) {
            reject(new Error('未收到响应'));
          } else if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.success) {
            console.log('请求成功，数据类型:', typeof response.data);
            // 处理 no-cors 模式下的特殊响应
            if (response.data && response.data.message && response.data.message.includes('opaque due to CORS')) {
              console.log('收到 no-cors 响应，回退到 portal 接口');
              throw new Error('需要回退到 portal 接口');
            }
            resolve(response.data);
          } else if (response && response.error) {
            console.error('请求失败:', response.error);
            reject(new Error(response.error));
          } else {
            console.error('未知响应格式:', response);
            reject(new Error('未知响应格式'));
          }
        });
      });
      
      console.log('请求成功，设置缓存');
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      await cacheSet(cacheKey, response, ttlValue);
      return response;
    } catch (e) {
      console.error(`请求失败: ${e.message}`);
      console.error('错误详情:', e);
     
     // 回退到 apollo-portal 接口
     console.log(`尝试回退到 apollo-portal 接口`);
     try {
       // 从 namespaces 获取配置
       const portalNamespaces = await listNamespaces(appId, env);
       if (!Array.isArray(portalNamespaces)) {
         throw new Error('无法获取 namespaces');
       }
       
       // 找到匹配的 namespace
       const targetNs = portalNamespaces.find(ns => {
         const nsName = ns?.baseInfo?.namespaceName || ns?.namespaceName || ns?.name;
         return nsName === namespace;
       });
       
       if (!targetNs) {
         throw new Error(`找不到 namespace: ${namespace}`);
       }
       
       // 从 portal 接口构建 configurations 对象
       const items = targetNs?.items || targetNs?.baseInfo?.items || [];
       const configurations = {};
       
       for (const it of items) {
         const k = it?.item?.key ?? it?.key;
         const v = it?.item?.value ?? it?.value;
         if (k) configurations[k] = v;
       }
       
       const response = { configurations };
             console.log('回退成功，设置缓存');
      // 获取用户选择的缓存过期时间
      const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
      await cacheSet(cacheKey, response, ttlValue);
      return response;
     } catch (fallbackError) {
       console.error(`回退失败: ${fallbackError.message}`);
     }
    }
    
    // 所有策略都失败，返回空配置
    console.log('请求失败，返回空配置');
    return { configurations: {} };
  }

  // AppId多选功能
  function addAppId(appId) {
    if (!appId || selectedAppIds.includes(appId)) return;
    selectedAppIds.push(appId);
    updateSelectedAppIdsDisplay();
    appIdSelect.input.value = '';
    hideAppIdDropdown();
    saveFormState();
  }
  
  function removeAppId(appId) {
    selectedAppIds = selectedAppIds.filter(id => id !== appId);
    updateSelectedAppIdsDisplay();
    saveFormState();
  }
  
  function updateSelectedAppIdsDisplay() {
    const container = appIdSelect.selected;
    // 清除现有的选中项（保留输入框）
    const children = Array.from(container.children);
    children.forEach(child => {
      if (child !== appIdSelect.input) {
        container.removeChild(child);
      }
    });
    
    // 添加选中的AppId标签
    selectedAppIds.forEach(appId => {
      const tag = document.createElement('span');
      tag.style.cssText = 'background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; padding: 2px 6px; font-size: 11px; display: flex; align-items: center; gap: 3px;';
      
      const text = document.createElement('span');
      text.textContent = appId;
      
      const removeBtn = document.createElement('span');
      removeBtn.textContent = '×';
      removeBtn.style.cssText = 'cursor: pointer; color: #666; font-weight: bold;';
      removeBtn.onclick = (e) => {
        e.stopPropagation();
        removeAppId(appId);
      };
      
      tag.appendChild(text);
      tag.appendChild(removeBtn);
      container.insertBefore(tag, appIdSelect.input);
    });
  }
  
  function showAppIdDropdown() {
    if (!appIds.length) return;
    
    const inputValue = appIdSelect.input.value.toLowerCase();
    const filteredAppIds = appIds.filter(id => 
      id.toLowerCase().includes(inputValue) && 
      !selectedAppIds.includes(id)
    ).slice(0, 20);
    
    const dropdown = appIdSelect.dropdown;
    dropdown.innerHTML = '';
    
    if (filteredAppIds.length === 0) {
      dropdown.style.display = 'none';
      return;
    }
    
    filteredAppIds.forEach(id => {
      const option = document.createElement('div');
      option.style.cssText = 'padding: 5px; cursor: pointer; border-bottom: 1px solid #eee;';
      option.textContent = id;
      option.onclick = () => addAppId(id);
      option.onmouseover = () => option.style.background = '#f0f0f0';
      option.onmouseout = () => option.style.background = 'white';
      dropdown.appendChild(option);
    });
    
    dropdown.style.display = 'block';
  }
  
  function hideAppIdDropdown() {
    appIdSelect.dropdown.style.display = 'none';
  }
  
  // 环境多选功能
  function addEnv(env) {
    if (!env || selectedEnvs.includes(env)) return;
    selectedEnvs.push(env);
    updateSelectedEnvsDisplay();
    envSelect.input.value = '';
    hideEnvDropdown();
    saveFormState();
  }
  
  function removeEnv(env) {
    selectedEnvs = selectedEnvs.filter(e => e !== env);
    updateSelectedEnvsDisplay();
    saveFormState();
  }
  
  function updateSelectedEnvsDisplay() {
    const container = envSelect.selected;
    // 清除现有的选中项（保留输入框）
    const children = Array.from(container.children);
    children.forEach(child => {
      if (child !== envSelect.input) {
        container.removeChild(child);
      }
    });
    
    // 添加选中的环境标签
    selectedEnvs.forEach(env => {
      const tag = document.createElement('span');
      tag.style.cssText = 'background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; padding: 2px 6px; font-size: 11px; display: flex; align-items: center; gap: 3px;';
      
      const text = document.createElement('span');
      text.textContent = env;
      
      const removeBtn = document.createElement('span');
      removeBtn.textContent = '×';
      removeBtn.style.cssText = 'cursor: pointer; color: #666; font-weight: bold;';
      removeBtn.onclick = (e) => {
        e.stopPropagation();
        removeEnv(env);
      };
      
      tag.appendChild(text);
      tag.appendChild(removeBtn);
      container.insertBefore(tag, envSelect.input);
    });
  }
  
  function showEnvDropdown() {
    const dropdown = envSelect.dropdown;
    dropdown.style.display = 'block';
    
    // 高亮已选择的环境
    const items = dropdown.querySelectorAll('.env-dropdown-item');
    items.forEach(item => {
      const env = item.getAttribute('data-env');
      if (selectedEnvs.includes(env)) {
        item.style.background = '#e6f7ff';
      } else {
        item.style.background = 'white';
      }
    });
  }
  
  function hideEnvDropdown() {
    envSelect.dropdown.style.display = 'none';
  }
  
  // 初始化环境多选事件
  function setupEnvEvents() {
    // 点击输入框显示下拉
    envSelect.input.addEventListener('focus', () => {
      showEnvDropdown();
    });
    
    // 点击外部隐藏下拉框
    document.addEventListener('click', (e) => {
      if (!envSelect.selected.contains(e.target) && !envSelect.dropdown.contains(e.target)) {
        hideEnvDropdown();
      }
    });
    
    // 点击下拉项添加环境
    const items = envSelect.dropdown.querySelectorAll('.env-dropdown-item');
    items.forEach(item => {
      item.addEventListener('click', () => {
        const env = item.getAttribute('data-env');
        if (env === 'ALL') {
          // 如果选择ALL，清空其他选择
          selectedEnvs = [];
          updateSelectedEnvsDisplay();
          hideEnvDropdown();
        } else {
          // 从selectedEnvs中移除ALL（如果存在）
          selectedEnvs = selectedEnvs.filter(e => e !== 'ALL');
          // 切换选中状态
          if (selectedEnvs.includes(env)) {
            removeEnv(env);
          } else {
            addEnv(env);
          }
        }
        saveFormState();
      });
      
      // 添加鼠标悬停效果
      item.addEventListener('mouseover', () => {
        if (!selectedEnvs.includes(item.getAttribute('data-env'))) {
          item.style.background = '#f0f0f0';
        }
      });
      
      item.addEventListener('mouseout', () => {
        if (!selectedEnvs.includes(item.getAttribute('data-env'))) {
          item.style.background = 'white';
        }
      });
    });
    
    // 点击容器也显示下拉框
    envSelect.selected.addEventListener('click', (e) => {
      if (e.target === envSelect.selected) {
        envSelect.input.focus();
      }
    });
  }
  
  // 复制键值对功能
  function copyKeyValuePairs() {
    const tbody = document.getElementById('apollo-tbody');
    if (!tbody || tbody.children.length === 0) {
      alert('没有数据可复制，请先搜索配置');
      return;
    }
    
    const pairs = [];
    const rows = tbody.querySelectorAll('tr');
    
    for (const row of rows) {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 5) {
        // 优先使用存储的原始数据，如果没有则使用显示文本
        const key = cells[3].getAttribute('data-original') || cells[3].textContent.trim();
        const value = (cells[4].getAttribute('data-original') || cells[4].textContent.trim()).replace(/[\r\n]/g, ''); // 去掉换行符
        pairs.push(`${key}=${value}`);
      }
    }
    
    if (pairs.length === 0) {
      alert('没有有效的键值对数据');
      return;
    }
    
    // 使用系统换行符
    const lineBreak = navigator.platform.indexOf('Win') !== -1 ? '\r\n' : '\n';
    const content = pairs.join(lineBreak);
    
    // 复制到剪贴板
    if (navigator.clipboard && window.isSecureContext) {
      // 使用现代 API
      navigator.clipboard.writeText(content).then(() => {
        alert(`已复制 ${pairs.length} 个键值对到剪贴板, 注意: 会去掉换行!!!!`);
      }).catch(err => {
        console.error('复制失败:', err);
        fallbackCopyTextToClipboard(content, pairs.length);
      });
    } else {
      // 降级方案
      fallbackCopyTextToClipboard(content, pairs.length);
    }
  }
  
  // 降级复制方案
  function fallbackCopyTextToClipboard(text, count) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    
    try {
      const successful = document.execCommand('copy');
      if (successful) {
        alert(`已复制 ${count} 个键值对到剪贴板`);
      } else {
        alert('复制失败，请手动复制');
      }
    } catch (err) {
      console.error('降级复制失败:', err);
      alert('复制失败，请手动复制');
    } finally {
      document.body.removeChild(textArea);
    }
  }
  
  // 兼容性函数，保持原有接口
  function populateAppIdSelect(ids) {
    // 不需要实现，appIds已在全局变量中
    console.log('AppId列表已更新，共', ids.length, '个应用');
  }

  async function fetchAllItems(owner, envFilters, keyPrefix, selectedAppId, valueFilter, namespaceFilter) {
    console.log('fetchAllItems 开始执行, appIds长度:', appIds.length);
    
    // 如果appIds为空，先尝试加载
    if (appIds.length === 0) {
      console.log('appIds为空，尝试加载...');
      try {
        await loadAppIdsByOwner(owner);
        console.log('加载完成，appIds长度:', appIds.length);
      } catch (e) {
        console.error('加载appIds失败:', e);
      }
    }
    
    // 如果仍然为空，返回空结果
    if (appIds.length === 0) {
      console.warn('无法获取appIds，返回空结果');
      return [];
    }
    
    // 处理环境过滤
    let environments;
    if (Array.isArray(envFilters)) {
      if (envFilters.length === 0 || envFilters.includes('ALL')) {
        environments = ['DEV', 'TEST', 'PROD'];
      } else {
        environments = envFilters;
      }
    } else {
      environments = envFilters === 'ALL' ? ['DEV', 'TEST', 'PROD'] : [envFilters];
    }
    console.log('使用环境过滤:', environments);
    
    // 根据选择的AppId进行筛选
    let filteredAppIds;
    if (selectedAppIds.length > 0) {
      filteredAppIds = appIds.filter(id => selectedAppIds.includes(id));
    } else {
      filteredAppIds = appIds; // 如果没有选择，使用所有AppId
    }
    filteredAppIds = shuffleArray(filteredAppIds)
    console.log('过滤后的appIds:', filteredAppIds);
    const result = [];
    for (const appId of filteredAppIds) {
      for (const env of environments) {
        try {
          const namespaces = await listNamespaces(appId, env);
          if (!Array.isArray(namespaces)) continue;
          for (const ns of namespaces) {
            const namespaceName = ns?.baseInfo?.namespaceName || ns?.namespaceName || ns?.name || 'application';
            const isConfigHidden = ns?.baseInfo?.isConfigHidden || false;
            const items = ns?.items || ns?.baseInfo?.items || [];
              // 如果设置了namespace过滤，检查是否匹配
            if (namespaceFilter && !namespaceName.toLowerCase().includes(namespaceFilter.toLowerCase())) continue;
            if (isConfigHidden) {
              const itemsResponse = await listNamespacesTest(appId, env, namespaceName);
              // 检查 configurations 是否有效
              const configurations = itemsResponse?.configurations || null;
              if (configurations && typeof configurations === 'object' ) {
                const configEntries = Object.entries(configurations);
                for (const [k, v] of configEntries) {
                  if (!k) continue;
                  if (keyPrefix && !k.toLowerCase().includes(keyPrefix.toLowerCase())) continue;
                  if (valueFilter && !String(v || '').toLowerCase().includes(valueFilter.toLowerCase())) continue;
                  result.push({ appId, environment: env, namespace: namespaceName, key: k, value: v ?? '' });
                }
                continue;
              } 
            }
                
            for (const it of items) {
              const k = it?.item?.key ?? it?.key;
              const v = it?.item?.value ?? it?.value;
              if (!k) continue;
              if (keyPrefix && !k.toLowerCase().includes(keyPrefix.toLowerCase())) continue;
              if (valueFilter && !String(v || '').toLowerCase().includes(valueFilter.toLowerCase())) continue;
              result.push({ appId, environment: env, namespace: namespaceName, key: k, value: v ?? '' });
            }
      
          }
          

        } catch (e) {
          console.error(`处理 ${appId}/${env} 时出错:`, e);
        }
      }
    }
    
    console.log('fetchAllItems 完成, 结果数量:', result.length);
    return result;
  }

  // 初始化UI
  function initUI() {
    const panelId = 'apollo-helper-panel';
    if (document.getElementById(panelId)) return;

    // 创建样式
    const style = document.createElement('style');
    style.textContent = `
      #apollo-helper-panel {
        position: fixed;
        top: 0px;
        right: 20px;
        width: 900px;
        background: white;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 15px;
        z-index: 10000;
        box-shadow: 0 0 10px rgba(0,0,0,0.2);
        max-height: 90vh;
        overflow-y: auto;
        transition: none;
        cursor: move;
      }
      
      #apollo-helper-panel .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
      }
      
      #apollo-helper-panel .header h3 {
        margin: 0;
        color: #1890ff;
        cursor: move;
      }
      
      #apollo-helper-panel .close-btn {
        cursor: pointer;
        font-size: 18px;
        color: #999;
      }
      
      #apollo-helper-panel .close-btn:hover {
        color: #666;
      }
      
      #apollo-helper-panel .resize-handle {
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        width: 5px;
        cursor: ew-resize;
        background: transparent;
      }
      
      #apollo-helper-panel .resize-handle:hover {
        background: rgba(24, 144, 255, 0.1);
      }
      
      #apollo-helper-panel label {
        display: block;
        margin-bottom: 5px;
      }
      
      #apollo-helper-panel input,
      #apollo-helper-panel select {
        width: 100%;
        padding: 5px;
        box-sizing: border-box;
        margin-bottom: 10px;
      }
      
      #apollo-key-dropdown,
      #apollo-value-dropdown {
        display: none;
        position: absolute;
        width: 100%;
        max-height: 200px;
        overflow-y: auto;
        background: white;
        border: 1px solid #ccc;
        border-top: none;
        z-index: 10001;
      }
      
      #apollo-key-dropdown div,
      #apollo-value-dropdown div {
        padding: 5px;
        cursor: pointer;
      }
      
      #apollo-key-dropdown div:hover,
      #apollo-value-dropdown div:hover {
        background: #f0f0f0;
      }
      
      #apollo-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
      }
      
      #apollo-table th,
      #apollo-table td {
        text-align: left;
        padding: 8px;
        border-bottom: 1px solid #e8e8e8;
        word-wrap: break-word;
        overflow: hidden;
      }
      
      #apollo-table td:nth-child(4),
      #apollo-table td:nth-child(5) {
        white-space: pre-wrap;
        word-break: break-all;
      }
      
      #apollo-table th {
        background: #fafafa;
      }
      
      #apollo-helper-toggle {
        position: fixed;
        top: 0px;
        right: 20px;
        background: #1890ff;
        color: white;
        border: none;
        border-radius: 4px;
        padding: 8px 12px;
        cursor: move;
        z-index: 9999;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      }
      
      #apollo-helper-toggle:hover {
        background: #40a9ff;
      }
      
      .apollo-checkbox-container {
        display: flex;
        justify-content: center;
        margin-bottom: 15px;
        border: 1px solid #e8e8e8;
        border-radius: 4px;
        padding: 10px;
        background-color: #f9f9f9;
      }
      
      .apollo-checkbox-wrapper {
        display: flex;
        align-items: center;
        padding: 5px;
      }
      
      .apollo-checkbox-wrapper input[type="checkbox"] {
        width: 16px;
        height: 16px;
        margin: 0;
        margin-right: 8px;
        flex-shrink: 0;
      }
      
      .apollo-checkbox-wrapper label {
        display: inline-block !important;
        margin: 0 !important;
        font-size: 14px;
        white-space: nowrap;
        text-align: center;
      }
      
      @media (max-width: 480px) {
        .apollo-checkbox-container {
          flex-direction: column;
        }
        
        .apollo-checkbox-wrapper:first-child {
          margin-right: 0;
          margin-bottom: 8px;
          border-right: none;
          border-bottom: 1px solid #e8e8e8;
          padding-bottom: 8px;
        }
      }
    `;
    document.head.appendChild(style);
    
    // 创建悬浮开关按钮
    const toggleBtn = document.createElement('button');
    toggleBtn.id = 'apollo-helper-toggle';
    toggleBtn.textContent = 'Apollo 助手';
    toggleBtn.style.display = 'block';
    document.body.appendChild(toggleBtn);
    
    // 创建面板
    const panel = document.createElement('div');
    panel.id = panelId;
    panel.style.display = 'none';
    panel.innerHTML = `
      <div class="resize-handle"></div>
      <div class="header">
        <h3>Apollo 配置搜索助手</h3>
        <span class="close-btn">&times;</span>
      </div>
      
      <div>
        <label for="apollo-owner-input">Owner:</label>
        <input id="apollo-owner-input" type="text" placeholder="输入 owner">
      </div>
      
      <div>
        <label for="apollo-env-container">Environment:</label>
        <div id="apollo-env-container" style="position: relative;">
          <div id="apollo-env-selected" style="border: 1px solid #ccc; padding: 5px; min-height: 30px; background: white; display: flex; flex-wrap: wrap; gap: 3px; align-items: center;">
            <input id="apollo-env-input" type="text" placeholder="选择环境" style="border: none; outline: none; flex: 1; min-width: 100px;">
          </div>
          <div id="apollo-env-dropdown" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #ccc; border-top: none; max-height: 150px; overflow-y: auto; z-index: 10001;">
            <div class="env-dropdown-item" data-env="ALL">ALL</div>
            <div class="env-dropdown-item" data-env="DEV">DEV</div>
            <div class="env-dropdown-item" data-env="TEST">TEST</div>
            <div class="env-dropdown-item" data-env="PROD">PROD</div>
          </div>
        </div>
      </div>
      
      <div>
        <label for="apollo-appid-input">AppId:</label>
        <div id="apollo-appid-container" style="position: relative;">
          <div id="apollo-appid-selected" style="border: 1px solid #ccc; padding: 5px; min-height: 30px; background: white; display: flex; flex-wrap: wrap; gap: 3px; align-items: center;">
            <input id="apollo-appid-input" type="text" placeholder="输入AppId按Enter添加" style="border: none; outline: none; flex: 1; min-width: 100px;">
          </div>
          <div id="apollo-appid-dropdown" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: white; border: 1px solid #ccc; border-top: none; max-height: 150px; overflow-y: auto; z-index: 10001;"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-namespace-input">Namespace:</label>
        <input id="apollo-namespace-input" type="text" placeholder="输入 namespace (可选)">
      </div>
      
      <div>
        <label for="apollo-key-input">Key 包含:</label>
        <div style="position: relative;">
          <input id="apollo-key-input" type="text" placeholder="输入 key 关键字">
          <div id="apollo-key-dropdown"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-value-input">Value 包含:</label>
        <div style="position: relative;">
          <input id="apollo-value-input" type="text" placeholder="输入 value 关键字 (可选)">
          <div id="apollo-value-dropdown"></div>
        </div>
      </div>
      
      <div>
        <label for="apollo-ttl-select">缓存过期时间:</label>
        <select id="apollo-ttl-select">
          <option value="${TTL_1H}">1小时</option>
          <option value="${TTL_1D}" selected>1天</option>
          <option value="${TTL_7D}">7天</option>
          <option value="${TTL_30D}">30天</option>
          <option value="${TTL_1Y}">1年</option>
        </select>
      </div>
      
      <div class="apollo-checkbox-container">
        <div class="apollo-checkbox-wrapper">
          <input id="apollo-force-chk" type="checkbox">
          <label for="apollo-force-chk">强制刷新</label>
        </div>
      </div>
      
      <div style="margin-bottom: 15px; display: flex; gap: 10px;">
        <button id="apollo-copy-btn" style="flex: 1; padding: 5px; background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 3px; cursor: pointer;">复制键值对</button>
        <button id="apollo-search-btn" style="flex: 1; padding: 5px; background: #1890ff; color: white; border: none; border-radius: 3px; cursor: pointer;">搜索</button>
      </div>
      
      <div style="margin-bottom: 15px; display: flex; gap: 10px;">
        <button id="apollo-export-btn" style="flex: 1; padding: 5px; background: #52c41a; color: white; border: none; border-radius: 3px; cursor: pointer;">导出 CSV</button>
        <button id="apollo-clear-btn" style="flex: 1; padding: 5px; background: #f5f5f5; border: 1px solid #d9d9d9; border-radius: 3px; cursor: pointer;">清空</button>
      </div>
      
      <div id="apollo-results">
        <div id="apollo-loading" style="display: none; text-align: center; padding: 20px;">加载中...</div>
        <div id="apollo-error" style="display: none; color: red; padding: 10px;"></div>
        <div id="apollo-summary" style="margin: 10px 0;"></div>
        <table id="apollo-table" style="display: none;">
          <thead>
            <tr>
              <th style="width: 15%; max-width: 150px;">AppId</th>
              <th style="width: 8%; max-width: 80px;">Env</th>
              <th style="width: 15%; max-width: 120px;">Namespace</th>
              <th style="width: 30%; min-width: 200px;">Key</th>
              <th style="width: 32%; min-width: 250px;">Value</th>
            </tr>
          </thead>
          <tbody id="apollo-tbody"></tbody>
        </table>
      </div>
    `;
    
    document.body.appendChild(panel);
    
    // 获取元素引用
    ownerInput = document.getElementById('apollo-owner-input');
    forceChk = document.getElementById('apollo-force-chk');
    copyBtn = document.getElementById('apollo-copy-btn');
    
    // 环境多选相关元素
    const envInput = document.getElementById('apollo-env-input');
    const envSelected = document.getElementById('apollo-env-selected');
    const envDropdown = document.getElementById('apollo-env-dropdown');
    envSelect = { input: envInput, selected: envSelected, dropdown: envDropdown };
    // AppId多选相关元素
    const appIdInput = document.getElementById('apollo-appid-input');
    const appIdSelected = document.getElementById('apollo-appid-selected');
    const appIdDropdown = document.getElementById('apollo-appid-dropdown');
    appIdSelect = { input: appIdInput, selected: appIdSelected, dropdown: appIdDropdown }; // 保持兼容性
    keyInput = document.getElementById('apollo-key-input');
    keyDropdown = document.getElementById('apollo-key-dropdown');
    valueInput = document.getElementById('apollo-value-input');
    valueDropdown = document.getElementById('apollo-value-dropdown');
    searchBtn = document.getElementById('apollo-search-btn');
    exportBtn = document.getElementById('apollo-export-btn');
    clearBtn = document.getElementById('apollo-clear-btn');
    tbody = document.getElementById('apollo-tbody');
    summary = document.getElementById('apollo-summary');
    namespaceInput = document.getElementById('apollo-namespace-input');
    ttlSelect = document.getElementById('apollo-ttl-select');
    
    // 设置初始值
    ownerInput.value = OWNER;
    
    // 处理关闭按钮
    const closeBtn = panel.querySelector('.close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        panel.style.display = 'none';
        toggleBtn.style.display = 'block';
      });
    }
    
    // 处理开关按钮
    toggleBtn.addEventListener('click', (e) => {
      // 如果是拖动，不要触发显示面板
      if (isDraggingToggle) return;
      
      panel.style.display = 'block';
      toggleBtn.style.display = 'none';
    });
    
    // 添加面板拖动功能
    const header = panel.querySelector('.header');
    if (header) {
      header.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('close-btn')) return;
        
        isDragging = true;
        const rect = panel.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        
        panel.style.cursor = 'grabbing';
      });
      
      document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const x = e.clientX - dragOffsetX;
        const y = e.clientY - dragOffsetY;
        
        // 确保面板不会移出视口
        const maxX = window.innerWidth - panel.offsetWidth;
        const maxY = window.innerHeight - panel.offsetHeight;
        
        const boundedX = Math.max(0, Math.min(x, maxX));
        const boundedY = Math.max(0, Math.min(y, maxY));
        
        panel.style.left = `${boundedX}px`;
        panel.style.top = `${boundedY}px`;
        panel.style.right = 'auto';
        
        saveFormState();
      });
      
      document.addEventListener('mouseup', () => {
        if (isDragging) {
          isDragging = false;
          panel.style.cursor = 'move';
        }
      });
    }
    
    // 添加面板大小调整功能
    const resizeHandle = panel.querySelector('.resize-handle');
    if (resizeHandle) {
      resizeHandle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        isResizing = true;
        initialWidth = panel.offsetWidth;
        initialX = e.clientX;
        
        // 获取面板的初始左侧位置
        const rect = panel.getBoundingClientRect();
        initialPanelLeft = rect.left;
        
        document.body.style.cursor = 'ew-resize';
        panel.style.transition = 'none';
      });
      
      document.addEventListener('mousemove', (e) => {
        if (!isResizing) return;
        
        // 计算鼠标移动的距离
        const deltaX = e.clientX - initialX;
        
        // 向左拖动(deltaX为负)时，面板宽度增加，同时左侧位置向左移动
        // 向右拖动(deltaX为正)时，面板宽度减少，同时左侧位置向右移动
        const newWidth = Math.max(500, initialWidth - deltaX);
        const newLeft = initialPanelLeft + deltaX;
        
        // 确保面板宽度不超过视口宽度的80%
        const maxWidth = window.innerWidth * 0.8;
        const boundedWidth = Math.min(newWidth, maxWidth);
        
        // 确保面板不会移出视口左侧
        const boundedLeft = Math.max(0, newLeft);
        
        panel.style.width = `${boundedWidth}px`;
        panel.style.left = `${boundedLeft}px`;
        panel.style.right = 'auto';
        
        saveFormState();
      });
      
      document.addEventListener('mouseup', () => {
        if (isResizing) {
          isResizing = false;
          document.body.style.cursor = '';
          
          // 保存面板大小
          saveFormState();
        }
      });
    }
    
    // 添加悬浮按钮拖动功能
    toggleBtn.addEventListener('mousedown', (e) => {
      e.preventDefault(); // 防止文本选择
      
      isDraggingToggle = true;
      const rect = toggleBtn.getBoundingClientRect();
      dragToggleOffsetX = e.clientX - rect.left;
      dragToggleOffsetY = e.clientY - rect.top;
      
      toggleBtn.style.cursor = 'grabbing';
      dragStartTime = Date.now();
    });
    
    document.addEventListener('mousemove', (e) => {
      if (!isDraggingToggle) return;
      
      const x = e.clientX - dragToggleOffsetX;
      const y = e.clientY - dragToggleOffsetY;
      
      // 确保按钮不会移出视口
      const maxX = window.innerWidth - toggleBtn.offsetWidth;
      const maxY = window.innerHeight - toggleBtn.offsetHeight;
      
      const boundedX = Math.max(0, Math.min(x, maxX));
      const boundedY = Math.max(0, Math.min(y, maxY));
      
      toggleBtn.style.left = `${boundedX}px`;
      toggleBtn.style.top = `${boundedY}px`;
      toggleBtn.style.right = 'auto';
      
      saveFormState();
    });
    
    document.addEventListener('mouseup', () => {
      if (isDraggingToggle) {
        isDraggingToggle = false;
        toggleBtn.style.cursor = 'move';
        
        // 如果拖动后立即释放，可能是点击意图
        if (Date.now() - dragStartTime < 200) {
          panel.style.display = 'block';
          toggleBtn.style.display = 'none';
        }
      }
    });
    
    // 设置事件监听
    setupEventListeners();
  }

  // 自动预加载数据
  async function preloadData() {
    const startTime = Date.now(); // 记录开始时间
    try {
      console.log('开始预加载数据...');
      
      // 1. 获取当前用户
      const ownerStartTime = Date.now();
      const owner = await getCurrentOwner();
      if (!owner) {
        console.log('无法获取当前用户，预加载中止');
        return;
      }
      const ownerEndTime = Date.now();
      console.log(`获取到当前用户: ${owner} (耗时: ${ownerEndTime - ownerStartTime}ms)`);
      
      // 2. 加载appIds
      const appIdsStartTime = Date.now();
      await loadAppIdsByOwner(owner, { force: false });
      const appIdsEndTime = Date.now();
      console.log(`加载appIds完成，数量: ${appIds.length} (耗时: ${appIdsEndTime - appIdsStartTime}ms)`);
      
      // 3. 根据初始化状态确定要加载的AppId
      let targetAppIds = 'ALL';
      if (selectedAppIds.length > 0) {
        console.log('使用已选择的AppId进行预加载:', selectedAppIds);
        targetAppIds = selectedAppIds.join(',');
      } else {
        console.log('没有选择AppId，使用ALL进行预加载');
      }
      
      // 4. 预加载配置
      const configStartTime = Date.now();
      const result = await fetchAllItems(owner, selectedEnvs, "", targetAppIds, "", "");
      const configEndTime = Date.now();
      console.log(`预加载配置完成，数量: ${result.length} (耗时: ${configEndTime - configStartTime}ms)`);
      
      const totalTime = Date.now() - startTime;
      console.log(`🎉 预加载数据完成！总耗时: ${totalTime}ms (${(totalTime / 1000).toFixed(2)}秒)`);
      return result;
    } catch (error) {
      const totalTime = Date.now() - startTime;
      console.error(`❌ 预加载数据失败，耗时: ${totalTime}ms:`, error);
      return [];
    }
  }

  // 设置自动刷新
  function setupAutoRefresh() {
    // 清除之前的定时器
    if (autoRefreshTimer) {
      clearTimeout(autoRefreshTimer);
      autoRefreshTimer = null;
    }
    
    // 获取当前配置的过期时间
    const ttlValue = parseInt(ttlSelect?.value || TTL_7D, 10);
    
    // 设置新的定时器，过期时间的一半时刷新一次
    const refreshInterval = Math.max(ttlValue / 2 + 100, TTL_1H); // 至少1小时刷新一次
    
    console.log(`设置自动刷新，间隔: ${refreshInterval}毫秒 (${refreshInterval / 3600000}小时)`);
    
    autoRefreshTimer = setTimeout(async () => {
      console.log('执行自动刷新...');
      
      // 如果面板可见，不执行自动刷新以避免干扰用户操作
      // const panel = document.getElementById('apollo-helper-panel');
      // if (panel && panel.style.display !== 'none') {
      //   console.log('面板可见，跳过自动刷新');
      //   setupAutoRefresh(); // 重新设置定时器
      //   return;
      // }
      
      // 执行预加载
      await preloadData();
      
      // 重新设置定时器
      setupAutoRefresh();
    }, refreshInterval);
  }

  // 监听过期时间变化
  function setupTTLChangeListener() {
    if (!ttlSelect) return;
    
    ttlSelect.addEventListener('change', () => {
      console.log('过期时间已更改，重新设置自动刷新');
      setupAutoRefresh();
    });
  }

  (async () => {
    console.log('Apollo 助手初始化...');
    await cache.init();
    await cache.cleanup();
    console.log('IndexedDB 初始化完成');
    
    // 初始化UI
    initUI();
    
    // 获取当前用户
    const auto = await getCurrentOwner();
    if (auto && ownerInput) {
      ownerInput.value = auto;
    }
    
    // 加载表单状态
    loadFormState();
    
    // 初始化AppId和环境显示
    updateSelectedAppIdsDisplay();
    updateSelectedEnvsDisplay();
    
    // 设置过期时间变化监听
    setupTTLChangeListener();
    
    // 启动自动刷新
    setupAutoRefresh();
    
    // 预加载数据
    preloadData().then(result => {
      console.log('预加载完成，可用数据条数:', result.length);
    });
  })();

  // 初始化UI完成后的事件处理
  function setupEventListeners() {
    if (!ownerInput || !searchBtn) return;
    
    // 加载 owner
    getCurrentOwner().then(owner => {
      if (owner && !ownerInput.value) {
        ownerInput.value = owner;
      }
    });
    
    // 复制键值对
    copyBtn.addEventListener('click', () => {
      copyKeyValuePairs();
    });
    
    // AppId多选功能事件监听
    appIdSelect.input.addEventListener('input', () => {
      showAppIdDropdown();
    });
    
    appIdSelect.input.addEventListener('focus', () => {
      showAppIdDropdown();
    });
    
    appIdSelect.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && appIdSelect.input.value.trim()) {
        e.preventDefault();
        addAppId(appIdSelect.input.value.trim());
      }
    });
    
    appIdSelect.selected.addEventListener('click', (e) => {
      if (e.target === appIdSelect.selected) {
        appIdSelect.input.focus();
      }
    });
    
    // 点击外部隐藏下拉框
    document.addEventListener('click', (e) => {
      if (!appIdSelect.selected.contains(e.target) && !appIdSelect.dropdown.contains(e.target)) {
        hideAppIdDropdown();
      }
    });
    
    // Key 输入框事件
    keyInput.addEventListener('input', () => {
      updateKeyDropdown(keyInput.value);
    });
    
    keyInput.addEventListener('focus', () => {
      updateKeyDropdown(keyInput.value);
    });
    
    keyInput.addEventListener('blur', () => {
      setTimeout(() => {
        hideKeyDropdown();
      }, 200);
    });
    
    // Value 输入框事件
    valueInput.addEventListener('input', () => {
      updateValueDropdown(valueInput.value);
    });
    
    valueInput.addEventListener('focus', () => {
      updateValueDropdown(valueInput.value);
    });
    
    valueInput.addEventListener('blur', () => {
      setTimeout(() => {
        hideValueDropdown();
      }, 200);
    });
    
    // 环境多选事件监听
    setupEnvEvents();

    // 添加按Enter键触发搜索的功能
    const handleEnterKey = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        searchBtn.click();
      }
    };
    
    // 为各个输入框添加Enter键监听
    ownerInput.addEventListener('keydown', handleEnterKey);
    keyInput.addEventListener('keydown', handleEnterKey);
    valueInput.addEventListener('keydown', handleEnterKey);
    namespaceInput.addEventListener('keydown', handleEnterKey);
    
    // 搜索按钮事件
    searchBtn.addEventListener('click', async () => {
      const owner = ownerInput.value.trim();
      // 环境使用多选值
      const keyPrefix = keyInput.value.trim();
      const appIdValue = selectedAppIds.length > 0 ? selectedAppIds.join(',') : 'ALL';
      const valueFilter = valueInput.value.trim();
      const namespaceFilter = namespaceInput.value.trim();
      const ttlValue = parseInt(ttlSelect.value, 10);
      
      if (!owner) {
        const errorDiv = document.getElementById('apollo-error');
        if (errorDiv) {
          errorDiv.textContent = '请输入 owner';
          errorDiv.style.display = 'block';
        }
        return;
      }
      
      // 保存表单状态
      saveFormState();
      
      const loadingDiv = document.getElementById('apollo-loading');
      const tableEl = document.getElementById('apollo-table');
      const errorDiv = document.getElementById('apollo-error');
      
      if (loadingDiv) loadingDiv.style.display = 'block';
      if (tableEl) tableEl.style.display = 'none';
      if (errorDiv) errorDiv.style.display = 'none';
      
      try {
        // 构建环境字符串用于缓存key
        const envKey = selectedEnvs.length > 0 ? selectedEnvs.sort().join('-') : 'ALL';
        
        // 使用缓存
        const cacheKey = `apollo_helper_rows_${owner}_${envKey}_${appIdValue}_${keyPrefix}_${valueFilter}_${namespaceFilter}`;
        let rows = null;
        
        if (!forceChk.checked) {
          rows = await cacheGet(cacheKey);
        }
        
        if (!rows) {
          console.log(`获取新数据: ${cacheKey}`);
          
          // 确保appIds已加载
          if (appIds.length === 0) {
            console.log('先加载appIds...');
            await loadAppIdsByOwner(owner);
            console.log('appIds加载完成, 长度:', appIds.length);
          }
          
          // 获取数据
          rows = await fetchAllItems(owner, selectedEnvs, keyPrefix, appIdValue, valueFilter, namespaceFilter);
  
          // 设置缓存
          await cacheSet(cacheKey, rows, ttlValue);
          console.log(`缓存已设置: ${cacheKey}, 数量: ${rows.length}, 过期时间: ${ttlValue}ms (${(ttlValue / (24*60*60*1000)).toFixed(1)}天)`);
        } else {
          console.log(`使用缓存数据: ${cacheKey}`, rows.length);
        }
        
        // 渲染结果
        renderRows(rows);
        
      } catch (error) {
        console.error('搜索失败:', error);
        if (errorDiv) {
          errorDiv.textContent = `搜索失败: ${error.message}`;
          errorDiv.style.display = 'block';
        }
        if (loadingDiv) loadingDiv.style.display = 'none';
      }
    });

    // 导出按钮事件处理
    exportBtn.addEventListener('click', () => {
      if (!tbody) return;
      
      // 收集表格数据
      const rows = [];
      const trs = tbody.querySelectorAll('tr');
      
      for (const tr of trs) {
        const cells = tr.querySelectorAll('td');
        const row = {
          appId: cells[0].textContent,
          environment: cells[1].textContent,
          namespace: cells[2].textContent,
          key: cells[3].textContent,
          value: cells[4].textContent
        };
        rows.push(row);
      }
      
      if (rows.length === 0) {
        alert('没有数据可导出');
        return;
      }
      
      // 生成CSV并下载
      const csv = toCsv(rows);
      downloadText(`apollo_config_${new Date().toISOString().split('T')[0]}.csv`, csv);
    });
    
    // 添加点击页面外部收起面板的功能
    document.addEventListener('click', (e) => {
      const panel = document.getElementById('apollo-helper-panel');
      const toggleBtn = document.getElementById('apollo-helper-toggle');
      
      // 如果面板存在且显示中，且点击不在面板内，也不是面板的调整手柄，也不是切换按钮
      if (panel && 
          panel.style.display !== 'none' && 
          !panel.contains(e.target) && 
          e.target !== toggleBtn &&
          !toggleBtn.contains(e.target) &&
          !isResizing && 
          !isDragging) {
        
        // 收起面板
        panel.style.display = 'none';
        toggleBtn.style.display = 'block';
        
        console.log('点击页面外部，收起面板');
      }
    }, true); // 使用捕获阶段，确保在其他点击事件之前处理
  }
})();