# Mitmproxy 快速启动脚本
# 使用方法: .\start_proxy.ps1

# 激活虚拟环境
conda activate mitmproxy-env

# 检查环境是否激活成功
if ($LASTEXITCODE -ne 0) {
    Write-Host "Failed to activate conda environment" -ForegroundColor Red
    exit 1
}

# 启动 mitmweb (Web界面)
Write-Host "Starting mitmproxy web interface..." -ForegroundColor Green
Write-Host "Web UI will be available at: http://127.0.0.1:8081" -ForegroundColor Cyan
Write-Host "Configure your browser proxy to: 127.0.0.1:8080" -ForegroundColor Cyan
Write-Host "Press Ctrl+C to stop" -ForegroundColor Yellow

mitmweb --set confdir="$PSScriptRoot"