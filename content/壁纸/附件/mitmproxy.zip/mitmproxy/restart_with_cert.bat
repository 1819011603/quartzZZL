@echo off
REM 安装证书并重启 mitmproxy 的完整流程

echo === 安装证书并重启 mitmproxy ===
echo.

cd /d "%~dp0"

echo 步骤1: 停止现有进程...
call stop_proxy.bat >nul 2>&1
timeout /t 2 /nobreak >nul

echo.
echo 步骤2: 安装 CA 证书...
call install_cert.bat
if %errorlevel% neq 0 (
    echo 证书安装可能有问题，继续启动代理...
)

echo.
echo 步骤3: 启动 mitmproxy...
echo 启动代理服务...
call quick_start.bat

echo.
echo === 完成 ===
echo 如果仍有证书错误，请：
echo 1. 重启浏览器/应用程序
echo 2. 清除浏览器缓存
echo 3. 检查防火墙设置
echo.
pause