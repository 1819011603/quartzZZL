# Cursor 账号接口重写演示脚本
# 展示如何修改 Cursor 账号 API 的返回结果

Write-Host "=== Cursor 账号接口重写演示 ===" -ForegroundColor Cyan
Write-Host ""

# 确保在正确的目录
cd "$PSScriptRoot"

# 检查并清理现有进程
Write-Host "检查并清理现有进程..." -ForegroundColor Yellow
$ports = @(8080, 8081)
foreach ($port in $ports) {
    $connections = netstat -ano 2>$null | findstr ":$port"
    if ($connections) {
        Write-Host "清理占用端口 $port 的进程..." -ForegroundColor Yellow
        foreach ($line in $connections) {
            if ($line -match "\s+(\d+)$") {
                $pid = $matches[1]
                if ($pid -and $pid -ne "0") {
                    try {
                        Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                        Write-Host "已停止进程 (PID: $pid)" -ForegroundColor Green
                    } catch {
                        # 忽略停止失败的进程
                    }
                }
            }
        }
    }
}

# 激活环境
Write-Host "激活 mitmproxy 环境..." -ForegroundColor Yellow
conda activate mitmproxy-env

if ($LASTEXITCODE -ne 0) {
    Write-Host "激活环境失败，请检查 conda 安装" -ForegroundColor Red
    Read-Host "按回车键退出"
    exit 1
}

# 启动 mitmweb 并加载 Cursor 重写脚本
Write-Host "启动 mitmproxy Web UI 并加载 Cursor 重写脚本..." -ForegroundColor Yellow
Write-Host "Web UI: http://127.0.0.1:8081" -ForegroundColor Green
Write-Host "代理: 127.0.0.1:8080" -ForegroundColor Green
Write-Host ""
Write-Host "脚本功能:" -ForegroundColor Magenta
Write-Host "- 自动拦截 Cursor 账号接口" -ForegroundColor White
Write-Host "- 修改账号数据和状态" -ForegroundColor White
Write-Host "- 添加代理处理标记" -ForegroundColor White
Write-Host ""
Write-Host "测试步骤:" -ForegroundColor Magenta
Write-Host "1. 在浏览器中访问需要 Cursor 账号的页面" -ForegroundColor White
Write-Host "2. 观察 Web UI 中的请求拦截" -ForegroundColor White
Write-Host "3. 查看修改后的响应数据" -ForegroundColor White
Write-Host ""
Write-Host "按 Ctrl+C 停止，或运行 stop_proxy.ps1 停止" -ForegroundColor Red
Write-Host ""

mitmweb -s cursor_rewrite.py --set confdir=.