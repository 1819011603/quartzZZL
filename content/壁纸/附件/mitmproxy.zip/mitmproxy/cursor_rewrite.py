"""
Cursor 账号接口重写脚本 - JSON 配置模式
所有规则配置都在 rewrite_rules.json 文件中

使用方法：
1. 编辑 rewrite_rules.json 文件添加/修改规则
2. 重启 mitmproxy 使配置生效
"""

from mitmproxy import http
import json
import os

# ============================================================
# 📋 从 JSON 文件加载配置
# ============================================================
def load_rules_from_json():
    """从 JSON 文件加载重写规则"""
    config_file = os.path.join(os.path.dirname(__file__), "rewrite_rules.json")
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
            rules = config.get("rules", [])
            print(f"[CONFIG] 成功加载 {len(rules)} 条重写规则")
            return rules
    except FileNotFoundError:
        print(f"[CONFIG] 错误: 配置文件 {config_file} 不存在")
        return []
    except json.JSONDecodeError as e:
        print(f"[CONFIG] 错误: JSON 解析失败 - {e}")
        return []
    except Exception as e:
        print(f"[CONFIG] 错误: 加载配置失败 - {e}")
        return []

# 加载规则
REWRITE_RULES = load_rules_from_json()

# ============================================================
# 🔧 核心处理逻辑 - 通常不需要修改
# ============================================================

def request(flow: http.HTTPFlow) -> None:
    """处理请求拦截"""
    # 检查是否匹配任何规则
    for rule in REWRITE_RULES:
        if rule["path_match"] in flow.request.path:
            print(f"[REQUEST] 拦截到 [{rule['name']}]: {flow.request.url}")
            print(f"[REQUEST] Method: {flow.request.method}")
            break

def response(flow: http.HTTPFlow) -> None:
    """处理响应拦截和修改"""
    if not flow.response:
        return
    
    # 遍历所有规则，查找匹配
    for rule in REWRITE_RULES:
        if rule["path_match"] in flow.request.path:
            print(f"[RESPONSE] *** 匹配到 [{rule['name']}] ***")
            print(f"[RESPONSE] URL: {flow.request.url}")
            print(f"[RESPONSE] 原始状态码: {flow.response.status_code}")
            print(f"[RESPONSE] 原始内容长度: {len(flow.response.content)} bytes")
            
            try:
                # 获取响应数据
                if rule["response"] is None:
                    # 使用特殊处理函数（如获取账号列表）
                    modified_data = get_cursor_accounts_response()
                else:
                    # 直接使用配置的响应
                    modified_data = rule["response"]
                
                # 转换为 JSON 字符串并设置响应
                modified_content = json.dumps(modified_data, indent=2, ensure_ascii=False)
                flow.response.content = modified_content.encode('utf-8')
                flow.response.headers["content-type"] = "application/json; charset=utf-8"
                
                print(f"[RESPONSE] 新内容长度: {len(flow.response.content)} bytes")
                print(f"[RESPONSE] *** [{rule['name']}] 响应修改成功! ***")
                
            except Exception as e:
                print(f"[RESPONSE] 修改 [{rule['name']}] 响应出错: {e}")
            
            break  # 找到匹配规则后退出循环


def get_cursor_accounts_response():
    """从 cursor_accounts.json 文件加载完整的响应数据"""
    accounts_file = os.path.join(os.path.dirname(__file__), "cursor_accounts.json")
    
    try:
        with open(accounts_file, 'r', encoding='utf-8') as f:
            response = json.load(f)
            account_count = len(response.get("data", []))
            print(f"[ACCOUNTS] 成功加载响应数据，包含 {account_count} 个账号")
            return response
    except FileNotFoundError:
        print(f"[ACCOUNTS] 错误: 账号文件 {accounts_file} 不存在")
        return {"code": -1, "data": [], "msg": "配置文件不存在"}
    except json.JSONDecodeError as e:
        print(f"[ACCOUNTS] 错误: JSON 解析失败 - {e}")
        return {"code": -1, "data": [], "msg": f"JSON解析错误: {e}"}
    except Exception as e:
        print(f"[ACCOUNTS] 错误: 加载账号失败 - {e}")
        return {"code": -1, "data": [], "msg": f"加载失败: {e}"}


# ============================================================
# 🚀 脚本加载提示
# ============================================================
print("=" * 60)
print("Cursor 接口重写脚本已加载!")
print("=" * 60)
print("已配置的重写规则:")
for i, rule in enumerate(REWRITE_RULES, 1):
    print(f"  {i}. {rule['name']} -> {rule['path_match']}")
print("=" * 60)