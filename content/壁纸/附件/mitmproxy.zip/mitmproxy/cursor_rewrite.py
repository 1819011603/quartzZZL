"""
Cursor 账号接口重写脚本 - 统一配置模式
支持通过配置来定义需要拦截的接口和返回结果

使用方法：在 REWRITE_RULES 中添加规则即可
"""

from mitmproxy import http
import json
import re

# ============================================================
# 📋 接口重写规则配置 - 只需在这里添加新规则
# ============================================================
REWRITE_RULES = [
    {
        "name": "绑定账号接口",
        "path_match": "/cursor/user/bindToAccount",
        "response": {
            "code": 0,
            "data": "更新绑定成功",
            "msg": ""
        }
    },
#         {
#         "name": "isValid",
#         "path_match": "/cursor/token/isValid",
#         "response": {
#     "code": 0,
#     "data": true,
#     "msg": ""
# }
#     },

#             {
#         "name": "/open/ideAccount",
#         "path_match": "/open/ideAccount",
#         "response": {
#     "data": {
#         "macMachineID": "bf1abdfc7acade06984f70d44f6bc5cd02dd64b2f6deb516026200323763d9920c6ad266f812f34e31759547541d66356eda9bd42da5ce2c7b87fa22acfbea16",
#         "machineID": "fcd703b358579f7ea9f5f3b8b395adbb9f25065d40082511afe760919856dd71",
#         "devDeviceID": "0ab6832a-e4ce-45e1-bcc6-1b9da8b51034",
#         "email": "gaotu-cursor-ultra15@baijiahulian.com",
#         "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0ZBNVc0Sk5RVEg5NzYyNzYzR0tWMk04IiwidGltZSI6IjE3Njg4MDE5OTEiLCJyYW5kb21uZXNzIjoiNTEzMzJlODMtMDFjYi00OWVjIiwiZXhwIjoxNzczOTg1OTkxLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.oDNP5mFnofAY11pTk8l0_VNTd-Tl_bqykZF3Tt7rmXs",
#         "code": 0
#     },
#     "code": 200,
#     "msg": "success"
# }
#     },  
    {
        "name": "用户列表接口",
        "path_match": "/cursor/user/pagelist",
        "response": {
            "code": 0,
            "data": {
                "pager": {
                    "total": 1,
                    "pageSize": 10,
                    "current": 1
                },
                "list": [
                    {
                        "id": 420,
                        "userName": "hanqiangqiang",
                        "departmentPathName": "高途-产品技术部-平台研发部-教学服务技术部",
                        "businessName": "平台研发部-教学服务技术部",
                        "includedSpendCents": 8488,
                        "currentCursorAccount": "jsb-cursor32@gaotu.cn",
                        "bindCursorAccount": "jsb-cursor32@gaotu.cn"
                    }
                ]
            },
            "msg": ""
        }
    },
    {
        "name": "获取可用账号接口",
        "path_match": "getAvailableAccountsByUserName",
        "response": None  # 使用特殊处理函数
    }
]

# ============================================================
# 🔧 核心处理逻辑 - 通常不需要修改
# ============================================================

def request(flow: http.HTTPFlow) -> None:
    """处理请求拦截"""
    # 检查是否匹配任何规则
    for rule in REWRITE_RULES:
        if rule["path_match"] in flow.request.path:
            print(f"[REQUEST] 拦截到 [{rule['name']}]: {flow.request.url}")
            print(f"[REQUEST] Method: {flow.request.method}")
            break

def response(flow: http.HTTPFlow) -> None:
    """处理响应拦截和修改"""
    if not flow.response:
        return
    
    # 遍历所有规则，查找匹配
    for rule in REWRITE_RULES:
        if rule["path_match"] in flow.request.path:
            print(f"[RESPONSE] *** 匹配到 [{rule['name']}] ***")
            print(f"[RESPONSE] URL: {flow.request.url}")
            print(f"[RESPONSE] 原始状态码: {flow.response.status_code}")
            print(f"[RESPONSE] 原始内容长度: {len(flow.response.content)} bytes")
            
            try:
                # 获取响应数据
                if rule["response"] is None:
                    # 使用特殊处理函数（如获取账号列表）
                    modified_data = get_cursor_accounts_response()
                else:
                    # 直接使用配置的响应
                    modified_data = rule["response"]
                
                # 转换为 JSON 字符串并设置响应
                modified_content = json.dumps(modified_data, indent=2, ensure_ascii=False)
                flow.response.content = modified_content.encode('utf-8')
                flow.response.headers["content-type"] = "application/json; charset=utf-8"
                
                print(f"[RESPONSE] 新内容长度: {len(flow.response.content)} bytes")
                print(f"[RESPONSE] *** [{rule['name']}] 响应修改成功! ***")
                
            except Exception as e:
                print(f"[RESPONSE] 修改 [{rule['name']}] 响应出错: {e}")
            
            break  # 找到匹配规则后退出循环


def get_cursor_accounts_response():
    """获取 Cursor 账号列表的固定响应"""
    return {
        "code": 0,
        "data": get_fixed_accounts(),
        "msg": "",
        "proxy_fixed_response": True,
        "response_time": "2026-01-22T12:30:00Z"
    }

def get_fixed_accounts():
    """
    获取固定的 Cursor 账号列表数据
    """
    print("[MODIFY] 返回固定的 Cursor 账号数据")

    # 固定的账号数据
    return [
        {
            "id": 266,
            "email": "gaotu-cursor-ultra09@baijiahulian.com",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0YyWVdDN1FIODUwSE40RzY0QjcyNEszIiwidGltZSI6IjE3Njg1NTU4MjciLCJyYW5kb21uZXNzIjoiYzNhZDY2ODYtYWZlNi00NmU1IiwiZXhwIjoxNzczNzM5ODI3LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.RGldDy62DLxu7W14hGUlUduaeyJwnbOERLKtRZJmsRo",
            "lastRefreshTime": "2026-01-16 17:30:48",
            "status": "success",
            "usageCount": 7,
            "includedSpendCents": 41500,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 268,
            "email": "gaotu-cursor-ultra11@baijiahulian.com",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0YyWkY0UkdTWEgwTlBKRkEyN0JENEJLIiwidGltZSI6IjE3Njg4Nzg3MDkiLCJyYW5kb21uZXNzIjoiYjQwY2FkOWUtYTJmZi00MDJiIiwiZXhwIjoxNzc0MDYyNzA5LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.XaCT4h7ti4tdb3rwxavTGsij0JFye80g6iLNirFrX5w",
            "lastRefreshTime": "2026-01-20 11:12:04",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 7,
            "includedSpendCents": 11576,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 269,
            "email": "gaotu-cursor-ultra12@baijiahulian.com",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0YyWlo3NFpFQ1A3U0RDQ1k2UVNINkIxIiwidGltZSI6IjE3NjkwNDY3NzAiLCJyYW5kb21uZXNzIjoiYTAyOTdlYTEtMGQxMi00MjlmIiwiZXhwIjoxNzc0MjMwNzcwLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.ItqQA-k9HCB3JuoWUJhe8YXousKpfPYYD6VVkxVUgjI",
            "lastRefreshTime": "2026-01-22 09:53:21",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 7,
            "includedSpendCents": 13969,
            "businessNameList": [
                "高途-H业务线",
                "高途-KA业务线",
                "平台研发部-电商平台部",
                "途途课堂-TT"
            ]
        },
        {
            "id": 271,
            "email": "gaotu-cursor-ultra15@baijiahulian.com",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0ZBNVc0Sk5RVEg5NzYyNzYzR0tWMk04IiwidGltZSI6IjE3Njg4MDE5OTEiLCJyYW5kb21uZXNzIjoiNTEzMzJlODMtMDFjYi00OWVjIiwiZXhwIjoxNzczOTg1OTkxLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.oDNP5mFnofAY11pTk8l0_VNTd-Tl_bqykZF3Tt7rmXs",
            "lastRefreshTime": "2026-01-19 13:53:26",
            "status": "success",
            "usageCount": 7,
            "includedSpendCents": 26488,
            "businessNameList": [
                "平台研发部-市销技术部",
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 282,
            "email": "gaotu-cursor-ultra26@baijiahulian.com",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0ZEN05YWUJSM1cxQTFFNDFIWTQ4VzREIiwidGltZSI6IjE3Njg5NTg5ODEiLCJyYW5kb21uZXNzIjoiYmY5ZWM2Y2YtZTZlYS00OWI5IiwiZXhwIjoxNzc0MTQyOTgxLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.XxEFhvpFmirr0Fc6jRupqzHoExNNtkt-TFLcdiC58cw",
            "lastRefreshTime": "2026-01-21 09:30:36",
            "status": "success",
            "usageCount": 6,
            "includedSpendCents": 2824,
            "businessNameList": [
                "平台研发部-电商平台部",
                "平台研发部-基础技术部-基础架构组"
            ]
        },
        {
            "id": 185,
            "email": "jsb-cursor127@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0NRWlgzVEtBTlNDNVk2NURISEhZNUdYIiwidGltZSI6IjE3NjYwMzY4NTgiLCJyYW5kb21uZXNzIjoiNzJjZGVlOTktYjU3Ny00ZDk0IiwiZXhwIjoxNzcxMjIwODU4LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.qy3BxG8OECQ4v97BQ6qZhu31o4r8rsD-_cqT8Uc3WMw",
            "lastRefreshTime": "2025-12-18 13:47:40",
            "status": "success",
            "usageCount": 0,
            "includedSpendCents": 8142,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 71,
            "email": "jsb-cursor13@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlNYNFJKU0tWOFhUTTdFTTdLWTRCUjVSIiwidGltZSI6IjE3NDU4MTkwOTAiLCJyYW5kb21uZXNzIjoiMmZkNjViZmQtYjUwOC00NDM5IiwiZXhwIjoxNzUxMDAzMDkwLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20ifQ.iB20XI-ZWC7KC7pq2gT3KVmXMUkWuQH9Su2-sbLeqFw",
            "lastRefreshTime": "2025-12-10 13:55:51",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8134,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 211,
            "email": "jsb-cursor153@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0QxVFlHUzBQQVo4ODdLNzc3UTU2MVA1IiwidGltZSI6IjE3NjYzNjcyMDUiLCJyYW5kb21uZXNzIjoiYTFkN2IzMGQtN2VmYS00Njk4IiwiZXhwIjoxNzcxNTUxMjA1LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.XKC97IZaN3m1hg1oLcNuK3A9U2kGX4EyaCJ4-uEYLZs",
            "lastRefreshTime": "2025-12-22 09:33:26",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8151,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 212,
            "email": "jsb-cursor154@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0QxVFRSRjdTTUMwR0FENkhINDhCWDZZIiwidGltZSI6IjE3NjYzNjcwODMiLCJyYW5kb21uZXNzIjoiYzFlOWJkNDgtMTVjNi00NWNlIiwiZXhwIjoxNzcxNTUxMDgzLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.rhmQ4pN2rbP4dFxh_t7bdlrva1CVjF3sJQpZYAaR5rI",
            "lastRefreshTime": "2025-12-23 10:35:42",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8030,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 229,
            "email": "jsb-cursor170@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0VWMU1IQ1kxVlY4MDFSOU1QQVRSME5ZIiwidGltZSI6IjE3NjgyODY4MjEiLCJyYW5kb21uZXNzIjoiMDk5MGNmZTItNjlkYS00NjRhIiwiZXhwIjoxNzczNDcwODIxLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.W6bSXklYJSxBgSoNvPeBmodZE1lXvM0CS-6zgi5GXv0",
            "lastRefreshTime": "2026-01-13 14:47:02",
            "status": "success",
            "usageCount": 2,
            "includedSpendCents": 8077,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 257,
            "email": "jsb-cursor198@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxS0YwNzU3MFFLQlkxSzFZVDcyOFFSMjUxIiwidGltZSI6IjE3Njg0NjAzODQiLCJyYW5kb21uZXNzIjoiMzNmMDE3NGYtZGY1Ni00NDFlIiwiZXhwIjoxNzczNjQ0Mzg0LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.AUnGxoPokooLuztPDrN3LUH22_IVVh5r1RDQQXN5buQ",
            "lastRefreshTime": "2026-01-15 14:59:46",
            "status": "success",
            "usageCount": 0,
            "includedSpendCents": 9589,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 112,
            "email": "jsb-cursor53@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlhDRjNRVFlWRDBHQzJFTTlYUkI0MTA3IiwidGltZSI6IjE3Njg4MDQ0MTgiLCJyYW5kb21uZXNzIjoiNGUwMjY2MjAtY2ZkYy00NzllIiwiZXhwIjoxNzczOTg4NDE4LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.CL1rknp-1D8WFBUQ14XazhsVhv2Tgok8cMUTzyxTsN4",
            "lastRefreshTime": "2026-01-19 14:33:40",
            "status": "success",
            "usageCount": 1,
            "includedSpendCents": 8090,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 114,
            "email": "jsb-cursor56@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlhWQTlWTldTVkRFQTJUTU5DNkRDN05EIiwidGltZSI6IjE3Njc3NzE4OTIiLCJyYW5kb21uZXNzIjoiNzIwYjBjMzktZDdkMC00ZDZmIiwiZXhwIjoxNzcyOTU1ODkyLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.-WlVrwsopZvrg9TlM1T9fa8_tUUO1QCS4sYxtYMzPQ0",
            "lastRefreshTime": "2026-01-07 15:44:54",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8322,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 123,
            "email": "jsb-cursor65@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSllOVjk2WVRTWFJORTEzR0JOQUcxREtYIiwidGltZSI6IjE3Njg1NDg0NjAiLCJyYW5kb21uZXNzIjoiZjI2MzhiNWUtNDQ0MS00YzdlIiwiZXhwIjoxNzczNzMyNDYwLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.DI6fs-JNuG5bSnN9grw8anKsVrnDp0tZA1C1l_5cknk",
            "lastRefreshTime": "2026-01-16 15:27:42",
            "status": "success",
            "usageCount": 0,
            "includedSpendCents": 8029,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 133,
            "email": "jsb-cursor75@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSzEwNzA2UDFEVFNYOE1OODU5Uk1UQ0pRIiwidGltZSI6IjE3NjgxOTk4ODEiLCJyYW5kb21uZXNzIjoiOWQyMTZlYTktZmNhMi00MDUwIiwiZXhwIjoxNzczMzgzODgxLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.PAM9BxFVNyzn06C7UG6t_XduDRaJm-VbqgBMbI3BWZU",
            "lastRefreshTime": "2026-01-12 14:38:02",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 1,
            "includedSpendCents": 8106,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 46,
            "email": "ptyfb-dsptb-cursor01@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlE2Q001OEI1NlpLREVCN0c4QThTRTEyIiwidGltZSI6IjE3NjU1NDc2NzkiLCJyYW5kb21uZXNzIjoiMjJiOTljODAtM2JlYS00NWQyIiwiZXhwIjoxNzcwNzMxNjc5LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.rFlhrqGwVApOhu8nEMHRN3uQwam6IAO8yaypPeUttLs",
            "lastRefreshTime": "2025-12-12 21:54:41",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 2,
            "includedSpendCents": 11880,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 47,
            "email": "ptyfb-dsptb-cursor02@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlE2Q1RaUDBNUTY0SENNOFIxVEtXWllZIiwidGltZSI6IjE3NDI4OTc3NzciLCJyYW5kb21uZXNzIjoiZjNkZWYxYzktNzU0Zi00NjEzIiwiZXhwIjo0MzM0ODk3Nzc3LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20ifQ.q192mYRP6iMAg1ORX0fZ0R_Q891bVpY8eR4CouTd4hs",
            "lastRefreshTime": "2025-03-25 18:17:17",
            "status": "success",
            "usageCount": 2,
            "includedSpendCents": 8194,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 48,
            "email": "ptyfb-dsptb-cursor03@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlE2RDZFNVRNMjNDNk4yWTBEMDhWU0dKIiwidGltZSI6IjE3NDI4OTgxNTMiLCJyYW5kb21uZXNzIjoiNDVmYmZhYjgtNjFjOS00ODJlIiwiZXhwIjo0MzM0ODk4MTUzLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20ifQ.ekrNBspOZOTHn1x9kKZJIH8ge5mz4_vXNjhOvc0moIw",
            "lastRefreshTime": "2025-03-25 18:23:33",
            "status": "success",
            "usageCount": 4,
            "includedSpendCents": 8042,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 51,
            "email": "ptyfb-dsptb-cursor04@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlFSNDcyNEgxNTA0UjM0WlRNVDJYNjRWIiwidGltZSI6IjE3Njg5NjU1MTciLCJyYW5kb21uZXNzIjoiMmZiNWYyNTMtMmYzZi00NTUzIiwiZXhwIjoxNzc0MTQ5NTE3LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.88AFTOsmoAZrPtZoz87-DCHoVhWEHSKdI_LW-DeYJdE",
            "lastRefreshTime": "2026-01-21 11:18:39",
            "status": "success",
            "usageCount": 0,
            "includedSpendCents": 8113,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 52,
            "email": "ptyfb-dsptb-cursor05@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlFSNEFEQ0FNOUQ4WTVONjIzN0tBS0ZDIiwidGltZSI6IjE3Njc5NDEzOTQiLCJyYW5kb21uZXNzIjoiYzA3ZGNjNjUtZWQ1Ni00NjUwIiwiZXhwIjoxNzczMTI1Mzk0LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.8da5aacH0VZMjVsbLo0-PcHNeSwjzrH7MwVIe80vkcI",
            "lastRefreshTime": "2026-01-09 14:49:55",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8210,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 53,
            "email": "ptyfb-dsptb-cursor06@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlFSNERSUTNGN1BSMEZHTVFXUVg4ODhaIiwidGltZSI6IjE3Njc1ODUwNDgiLCJyYW5kb21uZXNzIjoiYzdkZTIzMjUtZDE0NC00ZTY3IiwiZXhwIjoxNzcyNzY5MDQ4LCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.UiKYnvEAwFUOBI0glvxNRWGWySv6-ZiVmEkybfJrpSQ",
            "lastRefreshTime": "2026-01-05 11:50:50",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 1,
            "includedSpendCents": 8038,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        },
        {
            "id": 54,
            "email": "ptyfb-dsptb-cursor07@gaotu.cn",
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhdXRoMHx1c2VyXzAxSlFSNEdCWkFaWkVEQzYzUkhSNDNQSDE0IiwidGltZSI6IjE3Njc3NTIyOTIiLCJyYW5kb21uZXNzIjoiODM3YWQxYmEtYjIzNS00OGNmIiwiZXhwIjoxNzcyOTM2MjkyLCJpc3MiOiJodHRwczovL2F1dGhlbnRpY2F0aW9uLmN1cnNvci5zaCIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwgb2ZmbGluZV9hY2Nlc3MiLCJhdWQiOiJodHRwczovL2N1cnNvci5jb20iLCJ0eXBlIjoic2Vzc2lvbiJ9.6iNPp1VITPXRoYfKc7Ei_lwOrxX6FBNJJpwok-7g6pU",
            "lastRefreshTime": "2026-01-07 10:18:13",
            "status": "success",
            "failMessage": "获取失败，错误为:\nLogger initialized, log directory: /apps/srv/instance/cursor_token_adaptor/logs\ninit chrome...\nbrowser user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36\n\n=== start l",
            "usageCount": 0,
            "includedSpendCents": 8274,
            "businessNameList": [
                "平台研发部-电商平台部"
            ]
        }
    ]


# ============================================================
# 🚀 脚本加载提示
# ============================================================
print("=" * 60)
print("Cursor 接口重写脚本已加载!")
print("=" * 60)
print("已配置的重写规则:")
for i, rule in enumerate(REWRITE_RULES, 1):
    print(f"  {i}. {rule['name']} -> {rule['path_match']}")
print("=" * 60)