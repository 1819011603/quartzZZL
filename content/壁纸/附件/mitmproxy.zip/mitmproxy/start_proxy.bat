@echo off
REM Mitmproxy 启动批处理文件

echo === 检查并清理现有进程 ===
echo 停止可能占用端口的进程...
for %%p in (8080 8081) do (
    for /f "tokens=5" %%i in ('netstat -ano ^| findstr ":%%p" 2^>nul') do (
        if not "%%i"=="0" (
            echo 停止占用端口 %%p 的进程 (PID: %%i)
            taskkill /f /pid %%i 2>nul
        )
    )
)

echo.
echo Activating conda environment...
call conda activate mitmproxy-env

if %errorlevel% neq 0 (
    echo Failed to activate conda environment
    echo.
    pause
    exit /b 1
)

echo.
echo Starting mitmproxy web interface...
echo Web UI: http://127.0.0.1:8081
echo Proxy: 127.0.0.1:8080
echo Press Ctrl+C to stop
echo.

REM 使用当前目录作为配置目录
mitmweb -s cursor_rewrite.py --set confdir=C:\Users\Administrator\mitmproxy

echo.
echo 如果启动失败，请运行 stop_proxy.bat 清理进程后重试
pause