"""
Mitmproxy 重写示例脚本
支持 HTTP/HTTPS 请求和响应的拦截与修改

使用方法:
mitmweb -s rewrite_example.py --set confdir=C:\Users\Administrator\mitmproxy
"""

from mitmproxy import http
import json
import re

def request(flow: http.HTTPFlow) -> None:
    """
    处理请求拦截和修改
    """
    # 示例1: 修改请求头
    if "api.example.com" in flow.request.pretty_host:
        flow.request.headers["Authorization"] = "Bearer your-token-here"
        flow.request.headers["X-Custom-Header"] = "Modified by Mitmproxy"
        print(f"[REQUEST] Modified headers for {flow.request.pretty_host}")

    # 示例2: 修改请求参数 (GET)
    if flow.request.method == "GET" and "search" in flow.request.path:
        flow.request.query["limit"] = "100"
        print(f"[REQUEST] Modified query params for {flow.request.path}")

    # 示例3: 修改 POST 请求体
    if flow.request.method == "POST" and "login" in flow.request.path:
        if flow.request.content:
            try:
                data = json.loads(flow.request.content)
                data["auto_login"] = True
                flow.request.content = json.dumps(data).encode()
                print("[REQUEST] Modified login request body")
            except:
                pass

def response(flow: http.HTTPFlow) -> None:
    """
    处理响应拦截和修改
    """
    # 示例1: 修改响应头
    if flow.response:
        flow.response.headers["X-Proxy"] = "Mitmproxy"
        flow.response.headers["X-Response-Modified"] = "True"

    # 示例2: 修改 JSON 响应
    if flow.response and flow.response.content and "api.example.com" in flow.request.pretty_host:
        try:
            content_type = flow.response.headers.get("content-type", "")
            if "application/json" in content_type:
                data = json.loads(flow.response.content)

                # 修改响应数据
                if isinstance(data, dict):
                    data["modified_by_proxy"] = True
                    data["proxy_timestamp"] = "2024-01-01T00:00:00Z"

                flow.response.content = json.dumps(data, indent=2).encode()
                print(f"[RESPONSE] Modified JSON response for {flow.request.path}")
        except Exception as e:
            print(f"[RESPONSE] Failed to modify response: {e}")

    # 示例3: 替换响应内容
    if flow.response and "text/html" in flow.response.headers.get("content-type", ""):
        content = flow.response.content.decode('utf-8', errors='ignore')
        # 在 HTML 中添加标记
        if "</head>" in content:
            marker = '<meta name="proxy-modified" content="true">'
            content = content.replace("</head>", f"{marker}</head>")
            flow.response.content = content.encode()
            print("[RESPONSE] Added proxy marker to HTML")

def error(flow: http.HTTPFlow) -> None:
    """
    处理错误
    """
    print(f"[ERROR] {flow.error}")

# 拦截规则配置
# 可以通过命令行参数控制拦截行为
# mitmproxy -i "example\.com" -s rewrite_example.py

print("Mitmproxy rewrite script loaded!")
print("Available functions:")
print("- request(): 修改请求头、参数、请求体")
print("- response(): 修改响应头、响应体")
print("- error(): 处理错误")