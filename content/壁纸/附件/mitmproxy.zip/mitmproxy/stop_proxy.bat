@echo off
REM 停止 mitmproxy 代理进程的批处理脚本

echo === 停止 Mitmproxy 代理 ===
echo.

echo 查找并停止 mitmproxy 进程...
for /f "tokens=2" %%i in ('tasklist ^| findstr "python.exe"') do (
    taskkill /f /pid %%i 2>nul
    if %errorlevel% equ 0 (
        echo 已停止 python 进程 (PID: %%i)
    )
)

echo.
echo 检查并停止占用代理端口的进程...
for %%p in (8080 8081) do (
    echo 检查端口 %%p...
    for /f "tokens=5" %%i in ('netstat -ano ^| findstr ":%%p"') do (
        if not "%%i"=="0" (
            echo 停止占用端口 %%p 的进程 (PID: %%i)
            taskkill /f /pid %%i 2>nul
        )
    )
)

echo.
echo 重置系统代理设置...
netsh winhttp reset proxy

echo.
echo 代理已停止，可以重新启动！
echo 使用以下命令重新启动:
echo   start_proxy.bat
echo   或
echo   demo_cursor_modification.ps1
echo.
pause