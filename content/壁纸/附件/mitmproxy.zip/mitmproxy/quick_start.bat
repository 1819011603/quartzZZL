@echo off
cd /d C:\Users\Administrator\mitmproxy

echo Activating conda environment...
call conda activate mitmproxy-env

if %errorlevel% neq 0 (
    echo Failed to activate conda environment
    pause
    exit /b 1
)

echo Starting mitmweb with Cursor rewrite script...
mitmweb -s cursor_rewrite.py --set confdir=.

pause