# 测试 mitmproxy 代理是否工作的脚本

Write-Host "Testing mitmproxy proxy connection..." -ForegroundColor Cyan

try {
    $response = Invoke-WebRequest -Uri "http://mitm.it" -Proxy "http://127.0.0.1:8080" -TimeoutSec 10
    if ($response.StatusCode -eq 200) {
        Write-Host "✓ Proxy is working! Traffic is going through mitmproxy." -ForegroundColor Green
        Write-Host "Web UI: http://127.0.0.1:8081" -ForegroundColor Yellow
        Write-Host "Proxy: 127.0.0.1:8080" -ForegroundColor Yellow
    }
} catch {
    Write-Host "✗ Proxy test failed. Please check:" -ForegroundColor Red
    Write-Host "  1. mitmproxy is running" -ForegroundColor Red
    Write-Host "  2. Proxy settings are correct" -ForegroundColor Red
    Write-Host "  3. Firewall is not blocking connections" -ForegroundColor Red
}

Write-Host "`nTo stop proxy: netsh winhttp reset proxy" -ForegroundColor Gray