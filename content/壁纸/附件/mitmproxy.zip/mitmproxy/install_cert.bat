@echo off
REM 安装 mitmproxy CA 证书到系统信任库

echo === 安装 mitmproxy CA 证书 ===
echo.

cd /d "%~dp0"

REM 检查证书文件是否存在
if not exist "mitmproxy-ca-cert.cer" (
    echo 错误: 找不到证书文件 mitmproxy-ca-cert.cer
    echo 请确保 mitmproxy 已运行并生成了证书文件
    pause
    exit /b 1
)

echo 正在安装证书到系统信任库...
echo.

REM 使用 certutil 安装到本地计算机的根证书存储区
certutil -addstore "Root" "mitmproxy-ca-cert.cer"

if %errorlevel% equ 0 (
    echo.
    echo ✓ 证书安装成功！
    echo.
    echo 现在您可以正常使用 HTTPS 拦截功能了。
    echo 如遇到证书问题，请重启浏览器或应用程序。
) else (
    echo.
    echo ✗ 证书安装失败！
    echo 请尝试手动安装：
    echo 1. 双击 mitmproxy-ca-cert.cer 文件
    echo 2. 选择"安装证书"
    echo 3. 选择"本地计算机" - "将所有的证书都放入下列存储"
    echo 4. 浏览 - 选择"受信任的根证书颁发机构"
    echo 5. 完成安装
)

echo.
echo 证书位置: %~dp0mitmproxy-ca-cert.cer
echo.
pause