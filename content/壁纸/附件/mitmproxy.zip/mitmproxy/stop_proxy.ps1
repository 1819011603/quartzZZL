# 停止 mitmproxy 代理进程的脚本

Write-Host "=== 停止 Mitmproxy 代理 ===" -ForegroundColor Cyan

# 方法1: 停止特定的 mitmproxy 进程
Write-Host "查找并停止 mitmproxy 进程..." -ForegroundColor Yellow

$processes = Get-Process | Where-Object {
    $_.ProcessName -eq "python" -and
    ($_.CommandLine -like "*mitm*" -or $_.CommandLine -like "*mitmweb*" -or $_.CommandLine -like "*mitmproxy*")
}

if ($processes) {
    foreach ($process in $processes) {
        Write-Host "停止进程: $($process.ProcessName) (PID: $($process.Id))" -ForegroundColor Yellow
        try {
            Stop-Process -Id $process.Id -Force
            Write-Host "✓ 已停止进程 $($process.Id)" -ForegroundColor Green
        } catch {
            Write-Host "✗ 停止进程 $($process.Id) 失败: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
} else {
    Write-Host "未找到正在运行的 mitmproxy 进程" -ForegroundColor Yellow
}

# 方法2: 停止占用 8080 和 8081 端口的进程
Write-Host "检查并停止占用代理端口的进程..." -ForegroundColor Yellow

$ports = @(8080, 8081)
foreach ($port in $ports) {
    $connections = netstat -ano | findstr ":$port"
    if ($connections) {
        Write-Host "端口 $port 被占用，解析进程..." -ForegroundColor Yellow

        foreach ($line in $connections) {
            if ($line -match "\s+(\d+)$") {
                $pid = $matches[1]
                if ($pid -and $pid -ne "0") {
                    try {
                        $process = Get-Process -Id $pid -ErrorAction SilentlyContinue
                        if ($process) {
                            Write-Host "停止占用端口 $port 的进程: $($process.ProcessName) (PID: $pid)" -ForegroundColor Yellow
                            Stop-Process -Id $pid -Force
                            Write-Host "✓ 已停止进程 $pid" -ForegroundColor Green
                        }
                    } catch {
                        Write-Host "无法停止进程 $pid (可能已退出): $($_.Exception.Message)" -ForegroundColor Gray
                    }
                }
            }
        }
    }
}

# 方法3: 重置系统代理设置
Write-Host "重置系统代理设置..." -ForegroundColor Yellow
try {
    netsh winhttp reset proxy
    Write-Host "✓ 系统代理已重置" -ForegroundColor Green
} catch {
    Write-Host "✗ 重置系统代理失败: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "" -ForegroundColor White
Write-Host "代理已停止，可以重新启动！" -ForegroundColor Green
Write-Host "使用以下命令重新启动:" -ForegroundColor Cyan
Write-Host "  .\start_proxy.bat" -ForegroundColor White
Write-Host "  或" -ForegroundColor White
Write-Host "  .\demo_cursor_modification.ps1" -ForegroundColor White