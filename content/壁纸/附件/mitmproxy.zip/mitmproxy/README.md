# Mitmproxy 配置和使用指南

## 环境设置
- 已创建虚拟环境: `mitmproxy-env`
- Python 版本: 3.11.14
- Mitmproxy 版本: 11.0.2

## 激活环境
```powershell
conda activate mitmproxy-env
```

## 基本使用

### 1. 生成并信任证书
```bash
# 生成证书
mitmproxy --set confdir=C:\Users\Administrator\mitmproxy

# 或者使用 mitmweb 生成证书
mitmweb --set confdir=C:\Users\Administrator\mitmproxy
```

### 2. 启动代理
```bash
# 命令行界面
mitmproxy --set confdir=C:\Users\Administrator\mitmproxy

# Web界面 (推荐)
mitmweb --set confdir=C:\Users\Administrator\mitmproxy

# 透明代理模式
mitmdump --mode transparent --set confdir=C:\Users\Administrator\mitmproxy
```

### 3. 配置代理 (重要！)

#### 方法1：系统级代理（推荐）
```cmd
# 设置系统代理
netsh winhttp set proxy 127.0.0.1:8080

# 恢复默认代理
netsh winhttp reset proxy
```

#### 方法2：浏览器特定代理
**Chrome/Edge**:
- 设置 → 高级 → 系统 → 打开代理设置
- 或使用扩展：Proxy SwitchyOmega

**Firefox**:
- 设置 → 网络设置 → 设置手动代理

#### 方法3：命令行工具
```bash
# curl
curl --proxy http://127.0.0.1:8080 https://example.com

# wget
wget --proxy=http://127.0.0.1:8080 https://example.com
```

### 4. 安装证书
**自动安装（推荐）**：
```cmd
# 在 mitmproxy 目录中运行
install_cert.bat
```

**手动安装**：
- 双击 `mitmproxy-ca-cert.cer` 文件
- 选择"安装证书"
- 选择"本地计算机" → "将所有的证书都放入下列存储"
- 浏览 → 选择"受信任的根证书颁发机构"
- 完成安装

**或访问** `http://mitm.it` 下载证书

### 5. 测试代理
```powershell
# 运行测试脚本
.\test_proxy.ps1
```
如果看到 "If you can see this, traffic is not going through mitmproxy" 说明代理未配置正确。

### 6. 停止代理
```powershell
# 使用 PowerShell 脚本停止
.\stop_proxy.ps1

# 或使用批处理脚本停止
stop_proxy.bat
```

### 7. 故障排除
如果遇到端口占用错误：
1. 运行停止脚本清理进程：`.\stop_proxy.ps1`
2. 等待几秒钟
3. 重新启动代理

端口冲突时，启动脚本会自动清理现有进程。

## HTTP/HTTPS 重写功能

### 拦截和修改请求
```bash
# 拦截所有请求
mitmproxy -i ".*" --set confdir=C:\Users\Administrator\mitmproxy

# 只拦截特定域名
mitmproxy -i "example.com" --set confdir=C:\Users\Administrator\mitmproxy
```

### 使用 Python 脚本进行高级重写

#### 通用重写示例
创建 `rewrite.py`:
```python
from mitmproxy import http

def request(flow: http.HTTPFlow) -> None:
    # 修改请求头
    if "example.com" in flow.request.pretty_host:
        flow.request.headers["X-Custom-Header"] = "Modified"

def response(flow: http.HTTPFlow) -> None:
    # 修改响应
    if flow.response and "example.com" in flow.request.pretty_host:
        flow.response.headers["X-Response-Modified"] = "True"
```

#### Cursor 账号接口专用重写
专门处理 Cursor 账号 API 的脚本已创建：`cursor_rewrite.py`

**当前功能特性（固定返回模式）：**
- 自动拦截 `getAvailableAccountsByUserName` 接口
- **忽略原始响应，直接返回固定的 22 个账号数据**
- 包含完整的账号信息（id、email、token、status 等）
- 添加代理处理标记和时间戳

**注意：** 脚本目前设置为固定返回模式，如需动态修改请编辑 `cursor_rewrite.py` 中的 `modify_cursor_accounts` 函数

**使用方法：**
```bash
# 使用专用脚本
mitmweb -s cursor_rewrite.py --set confdir=C:\Users\Administrator\mitmproxy

# 或在已有会话中使用
# 在 Web UI 中：Options -> Scripts -> Add -> cursor_rewrite.py
```

**修改示例：**
- 只保留成功状态的账号
- 增加所有账号的消费额度
- 添加代理处理时间戳
- 按使用次数排序（最少使用的优先）

## 常用命令

- `i`: 设置拦截模式
- `a`: 接受拦截的请求
- `d`: 删除流
- `r`: 重放请求
- `q`: 退出

## 快捷启动脚本

创建 `start_proxy.ps1`:
```powershell
conda activate mitmproxy-env
mitmweb --set confdir=C:\Users\Administrator\mitmproxy
```