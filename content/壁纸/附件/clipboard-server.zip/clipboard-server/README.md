# Clipboard Server - 本地剪贴板 HTTP 服务

一个轻量级的本地 HTTP 服务，提供剪贴板读写接口，支持 Windows、macOS、Linux 系统。主要用于 Apifox、Postman 等 API 测试工具的前置/后置脚本调用。

## 快速开始

### 安装依赖

```bash
# 无需安装额外依赖，使用 Node.js 原生模块
```

### 启动服务

```bash
cd clipboard-server
node server.js
```

服务默认运行在 `http://127.0.0.1:9527`

---

## API 接口文档

### 基础信息

| 项目 | 值 |
|------|-----|
| Base URL | `http://127.0.0.1:9527` |
| 数据格式 | JSON |
| 编码 | UTF-8 |

---

### 1. 获取剪贴板内容

**请求**

```
GET /clipboard
```

**响应**

```json
{
  "success": true,
  "data": "剪贴板中的文本内容"
}
```

**错误响应**

```json
{
  "success": false,
  "error": "读取剪贴板失败: 错误信息"
}
```

**curl 示例**

```bash
curl http://127.0.0.1:9527/clipboard
```

---

### 2. 设置剪贴板内容

**请求**

```
POST /clipboard
Content-Type: application/json

{
  "text": "要复制到剪贴板的内容"
}
```

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| text | string | 是 | 要设置的剪贴板内容（也可用 `data` 字段） |

**响应**

```json
{
  "success": true,
  "message": "剪贴板设置成功"
}
```

**错误响应**

```json
{
  "success": false,
  "error": "请提供 text 或 data 参数"
}
```

**curl 示例**

```bash
curl -X POST http://127.0.0.1:9527/clipboard \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello World"}'
```

---

### 3. 健康检查

**请求**

```
GET /health
```

**响应**

```json
{
  "success": true,
  "message": "服务运行正常",
  "platform": "win32",
  "port": 9527
}
```

**curl 示例**

```bash
curl http://127.0.0.1:9527/health
```

---

## Apifox 使用示例

### 前置脚本 - 获取剪贴板内容作为变量

```javascript
// 获取剪贴板内容并设置为环境变量
pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'GET'
}, function (err, res) {
    if (err) {
        console.error('获取剪贴板失败:', err);
        return;
    }
    const response = res.json();
    if (response.success) {
        // 设置为环境变量，可在请求中使用 {{clipboard_content}}
        pm.environment.set('clipboard_content', response.data);
        console.log('剪贴板内容:', response.data);
    }
});
```

### 前置脚本 - 获取剪贴板中的 Token

```javascript
// 场景：从剪贴板获取 Token 用于认证
pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'GET'
}, function (err, res) {
    if (!err && res.json().success) {
        const token = res.json().data.trim();
        pm.environment.set('auth_token', token);
        // 请求头中使用: Authorization: Bearer {{auth_token}}
    }
});
```

### 后置脚本 - 复制响应内容到剪贴板

```javascript
// 将响应中的 token 复制到剪贴板
const responseData = pm.response.json();
const token = responseData.data.token; // 根据实际响应结构调整

pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'POST',
    header: {
        'Content-Type': 'application/json'
    },
    body: {
        mode: 'raw',
        raw: JSON.stringify({ text: token })
    }
}, function (err, res) {
    if (!err) {
        console.log('已复制到剪贴板:', token);
    }
});
```

### 后置脚本 - 复制整个响应到剪贴板

```javascript
// 将整个响应 JSON 复制到剪贴板
const responseText = JSON.stringify(pm.response.json(), null, 2);

pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'POST',
    header: { 'Content-Type': 'application/json' },
    body: {
        mode: 'raw',
        raw: JSON.stringify({ text: responseText })
    }
}, function (err, res) {
    console.log('响应已复制到剪贴板');
});
```

---

## 常见使用场景

### 场景1：自动填充验证码

1. 手动复制短信验证码到剪贴板
2. 前置脚本自动读取并设置为变量
3. 请求体中使用 `{{verify_code}}`

```javascript
pm.sendRequest('http://127.0.0.1:9527/clipboard', (err, res) => {
    pm.environment.set('verify_code', res.json().data);
});
```

### 场景2：复制登录后的 Token

```javascript
// 后置脚本
const token = pm.response.json().data.access_token;
pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'POST',
    header: { 'Content-Type': 'application/json' },
    body: { mode: 'raw', raw: JSON.stringify({ text: token }) }
}, () => console.log('Token 已复制'));
```

### 场景3：批量测试时传递数据

```javascript
// 接口A后置脚本：保存结果到剪贴板
pm.sendRequest({
    url: 'http://127.0.0.1:9527/clipboard',
    method: 'POST',
    header: { 'Content-Type': 'application/json' },
    body: { mode: 'raw', raw: JSON.stringify({ text: pm.response.json().data.id }) }
}, () => {});

// 接口B前置脚本：从剪贴板读取
pm.sendRequest('http://127.0.0.1:9527/clipboard', (err, res) => {
    pm.environment.set('prev_id', res.json().data);
});
```

---

## 配置说明

### 修改端口

编辑 `server.js` 文件，修改以下常量：

```javascript
const PORT = 9527;  // 修改为其他端口
const HOST = '127.0.0.1';  // 默认仅本地访问
```

### 支持的操作系统

| 操作系统 | 剪贴板实现 | 备注 |
|----------|-----------|------|
| Windows | PowerShell Get-Clipboard/Set-Clipboard | 原生支持 |
| macOS | pbcopy/pbpaste | 原生支持 |
| Linux | xclip | 需安装: `sudo apt install xclip` |

---

## 错误处理

### 常见错误及解决方案

| 错误信息 | 原因 | 解决方案 |
|----------|------|----------|
| `EADDRINUSE` | 端口被占用 | 修改 PORT 或关闭占用进程 |
| `读取剪贴板失败` | 系统权限问题 | Windows: 确保 PowerShell 可用 |
| `connect ECONNREFUSED` | 服务未启动 | 先运行 `node server.js` |

### 检查服务状态

```bash
curl http://127.0.0.1:9527/health
```

---

## 安全说明

- 服务仅监听 `127.0.0.1`，只能本机访问
- 不会暴露到公网，安全性有保障
- 建议仅在开发/测试环境使用

---

## 技术栈

- Node.js (v14+)
- 无第三方依赖，使用原生 `http` 模块
