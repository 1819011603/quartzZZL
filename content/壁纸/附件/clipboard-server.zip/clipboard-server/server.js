const http = require('http');
const { exec } = require('child_process');
const { promisify } = require('util');
const os = require('os');

const execAsync = promisify(exec);

const PORT = 9527;
const HOST = '127.0.0.1';
const platform = os.platform();

// 跨平台剪贴板操作
async function getClipboard() {
    try {
        let command;
        if (platform === 'darwin') {
            // macOS
            command = 'pbpaste';
        } else if (platform === 'win32') {
            // Windows - 强制使用 UTF-8 编码输出
            command = 'powershell -command "$OutputEncoding = [System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8; Get-Clipboard"';
        } else {
            // Linux (需要安装 xclip)
            command = 'xclip -selection clipboard -o';
        }

        const { stdout } = await execAsync(command, {
            encoding: 'utf8',
            maxBuffer: 10 * 1024 * 1024
        });
        return stdout.replace(/\r?\n$/, ''); // 移除末尾换行
    } catch (error) {
        throw new Error('读取剪贴板失败: ' + error.message);
    }
}

async function setClipboard(text) {
    try {
        if (platform === 'darwin') {
            // macOS - 使用 pbcopy
            const { exec } = require('child_process');
            return new Promise((resolve, reject) => {
                const proc = exec('pbcopy', (err) => {
                    if (err) reject(new Error('设置剪贴板失败: ' + err.message));
                    else resolve(true);
                });
                proc.stdin.write(text);
                proc.stdin.end();
            });
        } else if (platform === 'win32') {
            // Windows - 使用 PowerShell
            const escapedText = text
                .replace(/`/g, '``')
                .replace(/"/g, '`"')
                .replace(/\$/g, '`$');
            await execAsync(`powershell -command "Set-Clipboard -Value \\"${escapedText}\\""`, {
                encoding: 'utf8'
            });
            return true;
        } else {
            // Linux - 使用 xclip
            const { exec } = require('child_process');
            return new Promise((resolve, reject) => {
                const proc = exec('xclip -selection clipboard', (err) => {
                    if (err) reject(new Error('设置剪贴板失败: ' + err.message));
                    else resolve(true);
                });
                proc.stdin.write(text);
                proc.stdin.end();
            });
        }
    } catch (error) {
        throw new Error('设置剪贴板失败: ' + error.message);
    }
}

// 解析请求体
function parseBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            try {
                resolve(body ? JSON.parse(body) : {});
            } catch (e) {
                resolve({ text: body });
            }
        });
        req.on('error', reject);
    });
}

// 创建服务器
const server = http.createServer(async (req, res) => {
    // 设置 CORS 头，允许跨域访问
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Content-Type', 'application/json; charset=utf-8');

    // 处理预检请求
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    const url = new URL(req.url, `http://${HOST}:${PORT}`);
    const pathname = url.pathname;

    try {
        // GET /clipboard - 获取剪贴板内容
        if (req.method === 'GET' && pathname === '/clipboard') {
            const content = await getClipboard();
            res.writeHead(200);
            res.end(JSON.stringify({
                success: true,
                data: content
            }));
            console.log(`[${new Date().toLocaleString()}] GET /clipboard - 成功`);
            return;
        }

        // POST /clipboard - 设置剪贴板内容
        if (req.method === 'POST' && pathname === '/clipboard') {
            const body = await parseBody(req);
            const text = body.text || body.data || '';

            if (!text) {
                res.writeHead(400);
                res.end(JSON.stringify({
                    success: false,
                    error: '请提供 text 或 data 参数'
                }));
                return;
            }

            await setClipboard(text);
            res.writeHead(200);
            res.end(JSON.stringify({
                success: true,
                message: '剪贴板设置成功'
            }));
            console.log(`[${new Date().toLocaleString()}] POST /clipboard - 成功`);
            return;
        }

        // GET /health - 健康检查
        if (req.method === 'GET' && pathname === '/health') {
            res.writeHead(200);
            res.end(JSON.stringify({
                success: true,
                message: '服务运行正常',
                platform: platform,
                port: PORT
            }));
            return;
        }

        // 404 - 未找到
        res.writeHead(404);
        res.end(JSON.stringify({
            success: false,
            error: '接口不存在'
        }));

    } catch (error) {
        console.error('错误:', error);
        res.writeHead(500);
        res.end(JSON.stringify({
            success: false,
            error: error.message
        }));
    }
});

server.listen(PORT, HOST, () => {
    const platformName = {
        'darwin': 'macOS',
        'win32': 'Windows',
        'linux': 'Linux'
    }[platform] || platform;

    console.log('==========================================');
    console.log('    剪贴板服务已启动');
    console.log('==========================================');
    console.log(`  系统: ${platformName}`);
    console.log(`  地址: http://${HOST}:${PORT}`);
    console.log('');
    console.log('  可用接口:');
    console.log('  GET  /clipboard  - 获取剪贴板内容');
    console.log('  POST /clipboard  - 设置剪贴板 {"text": "内容"}');
    console.log('  GET  /health     - 健康检查');
    console.log('==========================================');
});

// 优雅退出
process.on('SIGINT', () => {
    console.log('\n服务已停止');
    process.exit(0);
});
